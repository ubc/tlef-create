import { describe, it, expect, beforeAll, afterEach, afterAll } from 'vitest';
import express from 'express';
import session from 'express-session';
import request from 'supertest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createAuthRouter } from '../src/providers/canvas/router';
import type { Config, Tokens } from '../src/providers/canvas/types';
import type { TokenStore } from '../src/core/types';

// 'bypass' (not 'error') because supertest's own requests to the local test
// server go through the same network layer msw intercepts — only requests
// matching an explicit handler below (the real Canvas domain) should be mocked.
const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'bypass' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

class FakeTokenStore implements TokenStore<Tokens> {
  private store = new Map<string, Tokens>();
  async get(userKey: string) {
    return this.store.get(userKey) ?? null;
  }
  async set(userKey: string, tokens: Tokens) {
    this.store.set(userKey, tokens);
  }
  async delete(userKey: string) {
    this.store.delete(userKey);
  }
}

function makeApp(config: Config) {
  const app = express();
  app.use(session({ secret: 'test-secret', resave: false, saveUninitialized: false }));
  app.use('/canvas/auth', createAuthRouter(config));
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    res.status(500).json({ error: err.message });
  });
  return app;
}

function extractState(location: string): string {
  return new URL(location).searchParams.get('state') ?? '';
}

function baseConfig(tokenStore: TokenStore<Tokens>, overrides: Partial<Config> = {}): Config {
  return {
    canvasDomain: 'ubc.instructure.com',
    clientId: 'client-id',
    clientSecret: 'client-secret',
    redirectUri: 'http://localhost/canvas/auth/callback',
    tokenStore,
    getUserKey: () => 'user-1',
    ...overrides,
  };
}

describe('createCanvasAuthRouter', () => {
  it('redirects /login to the Canvas authorize URL and stashes a state value', async () => {
    const app = makeApp(baseConfig(new FakeTokenStore()));

    const res = await request(app).get('/canvas/auth/login');
    expect(res.status).toBe(302);
    const location = new URL(res.headers.location);
    expect(location.origin + location.pathname).toBe('https://ubc.instructure.com/login/oauth2/auth');
    expect(location.searchParams.get('state')).toBeTruthy();
  });

  it('exchanges the code on /callback, stores tokens by getUserKey, and redirects to returnTo', async () => {
    server.use(
      http.post('https://ubc.instructure.com/login/oauth2/token', () =>
        HttpResponse.json({
          access_token: 'access-1',
          refresh_token: 'refresh-1',
          expires_in: 3600,
          user: { id: 42 },
        })
      )
    );
    const tokenStore = new FakeTokenStore();
    const app = makeApp(baseConfig(tokenStore));
    const agent = request.agent(app);

    const loginRes = await agent.get('/canvas/auth/login?returnTo=/dashboard');
    const state = extractState(loginRes.headers.location);

    const callbackRes = await agent.get(`/canvas/auth/callback?code=the-code&state=${state}`);
    expect(callbackRes.status).toBe(302);
    expect(callbackRes.headers.location).toBe('/dashboard');

    const stored = await tokenStore.get('user-1');
    expect(stored?.accessToken).toBe('access-1');
    expect(stored?.canvasUserId).toBe('42');
  });

  // `/login` is a public GET, so `returnTo` is attacker-controllable even though
  // ensureAuth only ever passes req.originalUrl. Each of these, unfiltered, would
  // make the post-authorization redirect send the user off-site.
  it.each([
    ['an absolute URL', 'https://evil.example.com/phish'],
    ['a scheme-relative URL', '//evil.example.com/phish'],
    ['a backslash-escaped host', '/\\evil.example.com/phish'],
    ['a non-http scheme', 'javascript:alert(1)'],
  ])('ignores %s in returnTo and falls back to /', async (_label, hostileReturnTo) => {
    server.use(
      http.post('https://ubc.instructure.com/login/oauth2/token', () =>
        HttpResponse.json({
          access_token: 'access-1',
          refresh_token: 'refresh-1',
          expires_in: 3600,
          user: { id: 42 },
        })
      )
    );
    const app = makeApp(baseConfig(new FakeTokenStore()));
    const agent = request.agent(app);

    const loginRes = await agent.get(
      `/canvas/auth/login?returnTo=${encodeURIComponent(hostileReturnTo)}`
    );
    const state = extractState(loginRes.headers.location);

    const callbackRes = await agent.get(`/canvas/auth/callback?code=the-code&state=${state}`);
    expect(callbackRes.status).toBe(302);
    expect(callbackRes.headers.location).toBe('/');
  });

  it('keeps a same-site path with a query string and fragment intact', async () => {
    server.use(
      http.post('https://ubc.instructure.com/login/oauth2/token', () =>
        HttpResponse.json({
          access_token: 'access-1',
          refresh_token: 'refresh-1',
          expires_in: 3600,
          user: { id: 42 },
        })
      )
    );
    const app = makeApp(baseConfig(new FakeTokenStore()));
    const agent = request.agent(app);

    const returnTo = '/courses/7/sections?tab=lms#linked';
    const loginRes = await agent.get(`/canvas/auth/login?returnTo=${encodeURIComponent(returnTo)}`);
    const state = extractState(loginRes.headers.location);

    const callbackRes = await agent.get(`/canvas/auth/callback?code=the-code&state=${state}`);
    expect(callbackRes.headers.location).toBe(returnTo);
  });

  it('supports an async getUserKey (e.g. a session-store lookup)', async () => {
    server.use(
      http.post('https://ubc.instructure.com/login/oauth2/token', () =>
        HttpResponse.json({ access_token: 'access-1', refresh_token: 'refresh-1', expires_in: 3600, user: { id: 42 } })
      )
    );
    const tokenStore = new FakeTokenStore();
    const getUserKey = async (): Promise<string> => {
      await new Promise((resolve) => setTimeout(resolve, 0));
      return 'async-resolved-user';
    };
    const app = makeApp(baseConfig(tokenStore, { getUserKey }));
    const agent = request.agent(app);

    const loginRes = await agent.get('/canvas/auth/login');
    const state = extractState(loginRes.headers.location);
    const callbackRes = await agent.get(`/canvas/auth/callback?code=the-code&state=${state}`);

    expect(callbackRes.status).toBe(302);
    expect(await tokenStore.get('async-resolved-user')).not.toBeNull();
    expect(await tokenStore.get('user-1')).toBeNull();
  });

  it('keeps the previously-stored refresh token when Canvas omits it on re-authorization', async () => {
    server.use(
      http.post('https://ubc.instructure.com/login/oauth2/token', () =>
        // Re-authorization response: no refresh_token, matching real Canvas behavior.
        HttpResponse.json({ access_token: 'access-2', expires_in: 3600, user: { id: 42 } })
      )
    );
    const tokenStore = new FakeTokenStore();
    await tokenStore.set('user-1', {
      accessToken: 'stale-access',
      refreshToken: 'original-refresh-token',
      expiresAt: Date.now() - 1000,
      canvasUserId: '42',
    });
    const app = makeApp(baseConfig(tokenStore));
    const agent = request.agent(app);

    const loginRes = await agent.get('/canvas/auth/login');
    const state = extractState(loginRes.headers.location);
    const callbackRes = await agent.get(`/canvas/auth/callback?code=the-code&state=${state}`);

    expect(callbackRes.status).toBe(302);
    const stored = await tokenStore.get('user-1');
    expect(stored?.accessToken).toBe('access-2');
    expect(stored?.refreshToken).toBe('original-refresh-token');
  });

  it('fails the callback when Canvas omits refresh_token and none is on file', async () => {
    server.use(
      http.post('https://ubc.instructure.com/login/oauth2/token', () =>
        HttpResponse.json({ access_token: 'access-1', expires_in: 3600, user: { id: 42 } })
      )
    );
    const tokenStore = new FakeTokenStore();
    const app = makeApp(baseConfig(tokenStore));
    const agent = request.agent(app);

    const loginRes = await agent.get('/canvas/auth/login');
    const state = extractState(loginRes.headers.location);
    const callbackRes = await agent.get(`/canvas/auth/callback?code=the-code&state=${state}`);

    expect(callbackRes.status).toBe(500);
    expect(await tokenStore.get('user-1')).toBeNull();
  });

  it('rejects a callback whose state does not match the session', async () => {
    const app = makeApp(baseConfig(new FakeTokenStore()));
    const agent = request.agent(app);
    await agent.get('/canvas/auth/login');

    const res = await agent.get('/canvas/auth/callback?code=the-code&state=wrong-state');
    expect(res.status).toBe(400);
  });

  it('rejects a callback missing the authorization code', async () => {
    const app = makeApp(baseConfig(new FakeTokenStore()));
    const agent = request.agent(app);
    const loginRes = await agent.get('/canvas/auth/login');
    const state = extractState(loginRes.headers.location);

    const res = await agent.get(`/canvas/auth/callback?state=${state}`);
    expect(res.status).toBe(400);
  });

  it('revokes and deletes tokens on /logout', async () => {
    let revoked = false;
    server.use(
      http.delete('https://ubc.instructure.com/login/oauth2/token', () => {
        revoked = true;
        return HttpResponse.json({});
      })
    );
    const tokenStore = new FakeTokenStore();
    await tokenStore.set('user-1', {
      accessToken: 'access-1',
      refreshToken: 'refresh-1',
      expiresAt: Date.now() + 100_000,
      canvasUserId: '42',
    });
    const app = makeApp(baseConfig(tokenStore));

    const res = await request(app).post('/canvas/auth/logout');
    expect(res.status).toBe(204);
    expect(revoked).toBe(true);
    expect(await tokenStore.get('user-1')).toBeNull();
  });

  // The user most likely to click "disconnect" is one whose token is already
  // broken — expired, or revoked from Canvas's own settings page — and Canvas
  // answers a revoke of a dead token with a non-2xx. Disconnecting must still
  // work locally, or that user can never clear their stored tokens.
  it('still deletes tokens and returns 204 when Canvas rejects the revoke', async () => {
    server.use(
      http.delete('https://ubc.instructure.com/login/oauth2/token', () =>
        HttpResponse.json({ error: 'access_denied' }, { status: 401 })
      )
    );
    const tokenStore = new FakeTokenStore();
    await tokenStore.set('user-1', {
      accessToken: 'access-1',
      refreshToken: 'refresh-1',
      expiresAt: Date.now() + 100_000,
      canvasUserId: '42',
    });
    const app = makeApp(baseConfig(tokenStore));

    const res = await request(app).post('/canvas/auth/logout');
    expect(res.status).toBe(204);
    expect(await tokenStore.get('user-1')).toBeNull();
  });

  it('still deletes tokens when the revoke request fails outright', async () => {
    server.use(
      http.delete('https://ubc.instructure.com/login/oauth2/token', () => HttpResponse.error())
    );
    const tokenStore = new FakeTokenStore();
    await tokenStore.set('user-1', {
      accessToken: 'access-1',
      refreshToken: 'refresh-1',
      expiresAt: Date.now() + 100_000,
      canvasUserId: '42',
    });
    const app = makeApp(baseConfig(tokenStore));

    const res = await request(app).post('/canvas/auth/logout');
    expect(res.status).toBe(204);
    expect(await tokenStore.get('user-1')).toBeNull();
  });

  it('/logout is a no-op when the user has no stored tokens', async () => {
    const app = makeApp(baseConfig(new FakeTokenStore()));
    const res = await request(app).post('/canvas/auth/logout');
    expect(res.status).toBe(204);
  });
});
