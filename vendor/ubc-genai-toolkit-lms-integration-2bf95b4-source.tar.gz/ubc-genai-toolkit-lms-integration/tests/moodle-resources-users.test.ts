import { afterAll, afterEach, beforeAll, describe, expect, it } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createApiClient } from '../src/providers/moodle/api-client';
import { getCourseUsers } from '../src/providers/moodle/resources/users';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const REST_URL = 'https://moodle.example.ubc.ca/webservice/rest/server.php';
const client = () => createApiClient({ moodleDomain: 'moodle.example.ubc.ca', token: 'tok-1', userId: '42' });

const student = (id: number, overrides: Record<string, unknown> = {}) => ({
  id,
  fullname: `Student ${id}`,
  username: `student${id}`,
  email: `student${id}@student.ubc.ca`,
  idnumber: `1000000${id}`,
  roles: [{ roleid: 5, shortname: 'student' }],
  ...overrides,
});

describe('Moodle course users', () => {
  it('normalizes the identity fields a roster match relies on', async () => {
    server.use(http.post(REST_URL, () => HttpResponse.json([student(9)])));
    await expect(getCourseUsers(client(), 55)).resolves.toEqual([
      expect.objectContaining({
        id: '9',
        name: 'Student 9',
        email: 'student9@student.ubc.ca',
        loginId: 'student9',
        sisId: '10000009',
      }),
    ]);
  });

  it('never reports an integrationId, since Moodle has no equivalent field', async () => {
    server.use(http.post(REST_URL, () => HttpResponse.json([student(9, { integration_id: 'PUID-0001' })])));
    const [user] = await getCourseUsers(client(), 55);
    expect(user.integrationId).toBeUndefined();
  });

  it('filters to students, since Moodle returns every enrolled user', async () => {
    server.use(
      http.post(REST_URL, () =>
        HttpResponse.json([
          student(1),
          student(2, { roles: [{ roleid: 3, shortname: 'editingteacher' }] }),
          student(3, { roles: [{ roleid: 4, shortname: 'teacher' }] }),
        ])
      )
    );
    const users = await getCourseUsers(client(), 55);
    expect(users.map((user) => user.id)).toEqual(['1']);
  });

  it('honours a caller-supplied role filter', async () => {
    server.use(
      http.post(REST_URL, () =>
        HttpResponse.json([student(1), student(2, { roles: [{ roleid: 4, shortname: 'teacher' }] })])
      )
    );
    const users = await getCourseUsers(client(), 55, { roleShortnames: ['student', 'teacher'] });
    expect(users.map((user) => user.id)).toEqual(['1', '2']);
  });

  it('keeps users whose roles are hidden, rather than shrinking the roster on a permission gap', async () => {
    server.use(
      http.post(REST_URL, () => HttpResponse.json([student(1, { roles: [] }), student(2, { roles: undefined })]))
    );
    const users = await getCourseUsers(client(), 55);
    expect(users.map((user) => user.id)).toEqual(['1', '2']);
  });

  it('leaves identity fields undefined when the token cannot see them', async () => {
    server.use(
      http.post(REST_URL, () =>
        HttpResponse.json([{ id: 9, fullname: 'Student 9', roles: [{ shortname: 'student' }] }])
      )
    );
    const [user] = await getCourseUsers(client(), 55);
    expect(user.email).toBeUndefined();
    expect(user.sisId).toBeUndefined();
    expect(user.loginId).toBeUndefined();
  });

  it('sends the course id to core_enrol_get_enrolled_users', async () => {
    let params = new URLSearchParams();
    server.use(
      http.post(REST_URL, async ({ request }) => {
        params = new URLSearchParams(await request.text());
        return HttpResponse.json([]);
      })
    );

    await getCourseUsers(client(), 55);
    expect(params.get('wsfunction')).toBe('core_enrol_get_enrolled_users');
    expect(params.get('courseid')).toBe('55');
  });
});
