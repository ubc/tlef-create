import { describe, it, expect, vi } from 'vitest';
import { createMongoTokenStore } from '../src/adapters/mongo-token-store';
import type { MongoCollectionLike, MongoDbLike } from '../src/adapters/mongo-token-store';
interface SampleTokens {
  accessToken: string;
  refreshToken: string;
  expiresAt: number;
  canvasUserId: string;
}

// A minimal hand-rolled fake of the MongoDB driver's Db/Collection shape —
// deliberately not the real `mongodb` package, matching the adapter's own
// duck-typed interfaces so no extra dependency is needed to test it.
class FakeCollection implements MongoCollectionLike {
  docs = new Map<string, Record<string, unknown>>();
  createIndexCalls: unknown[] = [];

  async createIndex(indexSpec: Record<string, unknown>, options?: Record<string, unknown>) {
    this.createIndexCalls.push({ indexSpec, options });
    return 'userKey_1';
  }
  async findOne(filter: Record<string, unknown>) {
    return this.docs.get(filter.userKey as string) ?? null;
  }
  async updateOne(filter: Record<string, unknown>, update: Record<string, unknown>) {
    const existing = this.docs.get(filter.userKey as string) ?? { userKey: filter.userKey };
    const set = (update.$set as Record<string, unknown>) ?? {};
    this.docs.set(filter.userKey as string, { ...existing, ...set });
    return { acknowledged: true };
  }
  async deleteOne(filter: Record<string, unknown>) {
    this.docs.delete(filter.userKey as string);
    return { acknowledged: true };
  }
}

class FakeDb implements MongoDbLike {
  collections = new Map<string, FakeCollection>();
  collectionCalls: string[] = [];

  collection(name: string): FakeCollection {
    this.collectionCalls.push(name);
    if (!this.collections.has(name)) this.collections.set(name, new FakeCollection());
    return this.collections.get(name)!;
  }
}

const sampleTokens: SampleTokens = {
  accessToken: 'access-1',
  refreshToken: 'refresh-1',
  expiresAt: Date.now() + 3_600_000,
  canvasUserId: '42',
};

describe('createMongoTokenStore', () => {
  it('uses the default collection name and creates a unique index on userKey', async () => {
    const db = new FakeDb();
    const store = createMongoTokenStore<SampleTokens>(db);

    await store.get('user-1');

    expect(db.collectionCalls.every((name) => name === 'canvas_tokens')).toBe(true);
    const collection = db.collection('canvas_tokens');
    expect(collection.createIndexCalls).toEqual([{ indexSpec: { userKey: 1 }, options: { unique: true } }]);
  });

  it('honors a custom collection name', async () => {
    const db = new FakeDb();
    const store = createMongoTokenStore<SampleTokens>(db, { collectionName: 'my_canvas_tokens' });

    await store.get('user-1');

    expect(db.collectionCalls.every((name) => name === 'my_canvas_tokens')).toBe(true);
    expect(db.collections.has('my_canvas_tokens')).toBe(true);
  });

  it('stores, retrieves, and deletes tokens by userKey', async () => {
    const db = new FakeDb();
    const store = createMongoTokenStore<SampleTokens>(db);

    expect(await store.get('user-1')).toBeNull();

    await store.set('user-1', sampleTokens);
    expect(await store.get('user-1')).toEqual(sampleTokens);

    await store.delete('user-1');
    expect(await store.get('user-1')).toBeNull();
  });

  it('only creates the index once across repeated calls', async () => {
    const db = new FakeDb();
    const store = createMongoTokenStore<SampleTokens>(db);

    await store.set('user-1', sampleTokens);
    await store.get('user-1');
    await store.get('user-2');
    await store.delete('user-1');

    const collection = db.collection('canvas_tokens');
    expect(collection.createIndexCalls).toHaveLength(1);
  });

  it('accepts a lazy db provider function, invoked once on first use', async () => {
    const db = new FakeDb();
    const getDb = vi.fn().mockResolvedValue(db);
    const store = createMongoTokenStore<SampleTokens>(getDb);

    expect(getDb).not.toHaveBeenCalled();

    await store.set('user-1', sampleTokens);
    await store.get('user-1');

    expect(getDb).toHaveBeenCalledTimes(1);
    expect(await store.get('user-1')).toEqual(sampleTokens);
  });

  it('retries on the next call after a transient failure, instead of staying broken', async () => {
    const db = new FakeDb();
    const getDb = vi.fn().mockRejectedValueOnce(new Error('DB not reachable yet')).mockResolvedValue(db);
    const store = createMongoTokenStore<SampleTokens>(getDb);

    await expect(store.get('user-1')).rejects.toThrow('DB not reachable yet');
    // A second call should retry the provider, not replay the same cached rejection.
    expect(await store.get('user-1')).toBeNull();
    expect(getDb).toHaveBeenCalledTimes(2);
  });
});
