import { afterAll, afterEach, beforeAll, describe, expect, it, vi } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createApiClient } from '../src/providers/canvas/api-client';
import {
  postSubmissionFeedbackPdfs,
  preflightSubmissionFeedbackExport,
  resolveSubmissionFeedbackWrites,
} from '../src/providers/canvas/resources/submission-feedback';
import type {
  CanvasSubmissionFeedbackBatch,
  SubmissionFeedbackPdfInput,
} from '../src/providers/canvas/resources/submission-feedback';
import { CanvasSubmissionFeedbackError } from '../src/providers/canvas/errors';
import { matchRosterByIntegrationId } from '../src/core/roster';
import type { LmsRosterUser } from '../src/core/types';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const client = () => createApiClient({ canvasDomain: 'ubc.instructure.com', accessToken: 'token-1' });

const API = 'https://ubc.instructure.com/api/v1';
const ASSIGNMENT_URL = `${API}/courses/7/assignments/8`;
const submissionUrl = (userId: string | number) => `${ASSIGNMENT_URL}/submissions/${userId}`;
const UPLOAD_URL = 'https://files.inscloudgate.net/upload';

function student(id: number, integrationId?: string): LmsRosterUser {
  return { id: String(id), name: `Student ${id}`, integrationId, raw: {} };
}

const report = (courseId: string | number = 7) =>
  matchRosterByIntegrationId(
    courseId,
    [student(2, 'PUID-0001'), student(3, 'PUID-0002')],
    ['PUID-0001', 'PUID-0002']
  );

function pdf(text = 'feedback'): Uint8Array {
  return new TextEncoder().encode(`%PDF-1.7\n${text}\n%%EOF\n`);
}

function input(overrides: Partial<SubmissionFeedbackPdfInput> = {}): SubmissionFeedbackPdfInput {
  return {
    feedbackId: 'fb-1',
    key: 'PUID-0001',
    attempt: 1,
    filename: 'feedback.pdf',
    data: pdf(),
    ...overrides,
  };
}

const LIMIT = { maxBytesPerFile: 10 * 1024 * 1024 };

function batchOf(...inputs: SubmissionFeedbackPdfInput[]): CanvasSubmissionFeedbackBatch {
  return resolveSubmissionFeedbackWrites(report(), 8, inputs, LIMIT);
}

/** The assignment read by every preflight. */
function assignment(overrides: Record<string, unknown> = {}) {
  return http.get(ASSIGNMENT_URL, () =>
    HttpResponse.json({ id: 8, name: 'Lab 1', post_manually: true, ...overrides })
  );
}

/** A student whose submission has the requested attempt and accepts a comment. */
function workingStudent(
  userId: number,
  options: { attempt?: number; fileId?: number; onComment?: (body: unknown) => void } = {}
) {
  const attempt = options.attempt ?? 1;
  const fileId = options.fileId ?? 4000 + userId;
  return [
    http.get(submissionUrl(userId), () =>
      HttpResponse.json({
        assignment_id: 8,
        user_id: userId,
        attempt,
        submission_history: [{ assignment_id: 8, user_id: userId, attempt }],
      })
    ),
    http.post(`${submissionUrl(userId)}/comments/files`, () =>
      HttpResponse.json({ upload_url: UPLOAD_URL, upload_params: { key: `k-${userId}` } })
    ),
    http.post(UPLOAD_URL, () => HttpResponse.json({ id: fileId }, { status: 201 })),
    http.put(submissionUrl(userId), async ({ request }) => {
      options.onComment?.(await request.json());
      return HttpResponse.json({ id: 900 + userId, user_id: userId });
    }),
  ];
}

describe('resolveSubmissionFeedbackWrites', () => {
  it('translates application keys into Canvas user ids and keeps both stamps', () => {
    const first = pdf('one');
    const second = pdf('two');
    const batch = batchOf(
      input({ feedbackId: 'fb-1', key: 'PUID-0001', data: first, textComment: 'See attached' }),
      input({ feedbackId: 'fb-2', key: 'PUID-0002', data: second, attempt: 2 })
    );

    expect(batch.courseId).toBe('7');
    expect(batch.gradeItemId).toBe('8');
    expect(batch.maxBytesPerFile).toBe(LIMIT.maxBytesPerFile);
    expect(batch.writes).toEqual([
      {
        feedbackId: 'fb-1',
        userId: '2',
        attempt: 1,
        filename: 'feedback.pdf',
        data: first,
        textComment: 'See attached',
      },
      { feedbackId: 'fb-2', userId: '3', attempt: 2, filename: 'feedback.pdf', data: second },
    ]);
    expect(batch.unresolved).toEqual([]);
  });

  it('sets aside feedback whose student is not on the roster', () => {
    const batch = batchOf(
      input({ feedbackId: 'fb-1', key: 'PUID-0001' }),
      input({ feedbackId: 'fb-2', key: 'PUID-0404' })
    );

    expect(batch.writes).toHaveLength(1);
    expect(batch.unresolved).toEqual([
      { feedbackId: 'fb-2', key: 'PUID-0404', reason: 'no-roster-match' },
    ]);
  });

  it('sets aside an ambiguous application key', () => {
    const ambiguous = matchRosterByIntegrationId(
      7,
      [student(2, 'PUID-0001'), student(3, 'PUID-0001')],
      ['PUID-0001']
    );
    const batch = resolveSubmissionFeedbackWrites(ambiguous, 8, [input()], LIMIT);

    expect(batch.writes).toEqual([]);
    expect(batch.unresolved).toEqual([
      { feedbackId: 'fb-1', key: 'PUID-0001', reason: 'ambiguous-key' },
    ]);
  });

  it('sends neither file when the application supplies two for one student', () => {
    const batch = batchOf(
      input({ feedbackId: 'fb-1', key: 'PUID-0001' }),
      input({ feedbackId: 'fb-2', key: 'PUID-0001' })
    );

    expect(batch.writes).toEqual([]);
    expect(batch.unresolved).toEqual([
      { feedbackId: 'fb-1', key: 'PUID-0001', reason: 'duplicate-key' },
      { feedbackId: 'fb-2', key: 'PUID-0001', reason: 'duplicate-key' },
    ]);
  });

  it('refuses a repeated feedback id, which would make both outcomes unreadable', () => {
    expect(() =>
      batchOf(input({ feedbackId: 'fb-1', key: 'PUID-0001' }), input({ feedbackId: 'fb-1', key: 'PUID-0002' }))
    ).toThrowError(
      expect.objectContaining({ name: 'CanvasSubmissionFeedbackError', reason: 'invalid-feedback' })
    );
  });

  it('refuses a roster that exposed no integration_id at all', () => {
    const blind = matchRosterByIntegrationId(7, [student(2, undefined)], ['PUID-0001']);

    expect(() => resolveSubmissionFeedbackWrites(blind, 8, [input()], LIMIT)).toThrowError(
      expect.objectContaining({ reason: 'roster-coverage' })
    );
  });

  it.each([
    ['no id', { feedbackId: '' }],
    ['a blank id', { feedbackId: '   ' }],
    ['a missing attempt', { attempt: undefined as unknown as number }],
    ['attempt zero', { attempt: 0 }],
    ['a negative attempt', { attempt: -1 }],
    ['a fractional attempt', { attempt: 1.5 }],
    ['an unsafe attempt', { attempt: Number.MAX_SAFE_INTEGER + 2 }],
    ['an empty filename', { filename: '' }],
    ['a path in the filename', { filename: '../../etc/feedback.pdf' }],
    ['a backslash in the filename', { filename: 'reports\\feedback.pdf' }],
    ['a control character in the filename', { filename: 'feed\u0000back.pdf' }],
    ['the wrong extension', { filename: 'feedback.docx' }],
    ['no bytes', { data: new Uint8Array() }],
    ['bytes that are not a PDF', { data: new TextEncoder().encode('Dear student,') }],
    ['a non-string text comment', { textComment: 42 as unknown as string }],
  ])('refuses feedback with %s', (_label, overrides) => {
    expect(() => batchOf(input(overrides as Partial<SubmissionFeedbackPdfInput>))).toThrowError(
      expect.objectContaining({ reason: 'invalid-feedback' })
    );
  });

  it('accepts a PDF signature that is not at byte zero, but not one past the window', () => {
    const late = new Uint8Array(1100);
    late.set(new TextEncoder().encode('%PDF-1.7'), 1000);
    expect(() => batchOf(input({ data: late }))).not.toThrow();

    const tooLate = new Uint8Array(1100);
    tooLate.set(new TextEncoder().encode('%PDF-1.7'), 1030);
    expect(() => batchOf(input({ data: tooLate }))).toThrowError(
      expect.objectContaining({ reason: 'invalid-feedback' })
    );
  });

  it('accepts a file at exactly the limit and refuses one byte more', () => {
    const exact = new Uint8Array(2048);
    exact.set(new TextEncoder().encode('%PDF-1.7'), 0);
    expect(() =>
      resolveSubmissionFeedbackWrites(report(), 8, [input({ data: exact })], { maxBytesPerFile: 2048 })
    ).not.toThrow();

    expect(() =>
      resolveSubmissionFeedbackWrites(report(), 8, [input({ data: exact })], { maxBytesPerFile: 2047 })
    ).toThrowError(expect.objectContaining({ reason: 'invalid-feedback' }));
  });

  it.each([0, -1, 1.5, Number.NaN])('refuses the byte limit %s', (maxBytesPerFile) => {
    expect(() =>
      resolveSubmissionFeedbackWrites(report(), 8, [input()], { maxBytesPerFile })
    ).toThrowError(expect.objectContaining({ reason: 'invalid-feedback' }));
  });

  it('accepts a Node Buffer through its Uint8Array inheritance', () => {
    const buffer = Buffer.from('%PDF-1.7\nfeedback\n');
    const batch = batchOf(input({ data: buffer }));

    expect(batch.writes[0].data).toBe(buffer);
  });

  it('does not mutate the caller-supplied inputs or their bytes', () => {
    const data = pdf();
    const snapshot = Uint8Array.from(data);
    const original = input({ data, textComment: 'See attached' });
    const copy = { ...original };

    batchOf(original);

    expect(original).toEqual(copy);
    expect(data).toEqual(snapshot);
  });
});

describe('preflightSubmissionFeedbackExport', () => {
  const options = (batch: CanvasSubmissionFeedbackBatch, extra = {}) => ({
    courseId: 7,
    gradeItemId: 8,
    batch,
    ...extra,
  });

  it('summarizes the export and reports the posting policy without writing', async () => {
    server.use(assignment({ post_manually: false }));
    const batch = batchOf(input({ feedbackId: 'fb-1' }), input({ feedbackId: 'fb-2', key: 'PUID-0002' }));

    const preflight = await preflightSubmissionFeedbackExport(client(), options(batch));

    expect(preflight).toMatchObject({
      courseId: '7',
      gradeItemId: '8',
      assignmentName: 'Lab 1',
      postManually: false,
      fileCount: 2,
      totalBytes: batch.writes[0].data.byteLength + batch.writes[1].data.byteLength,
    });
    expect(preflight.batchFingerprint).toMatch(/^[0-9a-f]{64}$/);
  });

  it('refuses a batch resolved against another course', async () => {
    const batch = resolveSubmissionFeedbackWrites(report(9), 8, [input()], LIMIT);

    await expect(
      preflightSubmissionFeedbackExport(client(), options(batch))
    ).rejects.toMatchObject({ reason: 'course-mismatch' });
  });

  it('refuses a batch written for another assignment in the same course', async () => {
    const batch = resolveSubmissionFeedbackWrites(report(), 9, [input()], LIMIT);

    await expect(
      preflightSubmissionFeedbackExport(client(), options(batch))
    ).rejects.toMatchObject({ reason: 'assignment-mismatch' });
  });

  it('refuses an empty batch, which would otherwise report as a successful export', async () => {
    const batch = batchOf(input({ key: 'PUID-0404' }));

    await expect(
      preflightSubmissionFeedbackExport(client(), options(batch))
    ).rejects.toMatchObject({ reason: 'empty-batch' });
  });

  it('refuses a partial batch unless partial export is asked for explicitly', async () => {
    const batch = batchOf(input({ feedbackId: 'fb-1' }), input({ feedbackId: 'fb-2', key: 'PUID-0404' }));

    await expect(
      preflightSubmissionFeedbackExport(client(), options(batch))
    ).rejects.toMatchObject({ reason: 'partial-export' });

    server.use(assignment());
    await expect(
      preflightSubmissionFeedbackExport(client(), options(batch, { allowPartial: true }))
    ).resolves.toMatchObject({ fileCount: 1 });
  });

  it.each([
    ['anonymous grading', { anonymous_grading: true }, 'unsupported-grading'],
    ['moderated grading', { moderated_grading: true }, 'unsupported-grading'],
    ['a group assignment', { group_category_id: 12 }, 'unsupported-group-assignment'],
  ])('refuses %s', async (_label, overrides, reason) => {
    server.use(assignment(overrides));

    await expect(
      preflightSubmissionFeedbackExport(client(), options(batchOf(input())))
    ).rejects.toMatchObject({ reason });
  });

  it('re-validates a batch that was edited after resolution', async () => {
    const batch = batchOf(input());
    batch.writes[0].data = new TextEncoder().encode('not a pdf at all');

    await expect(
      preflightSubmissionFeedbackExport(client(), options(batch))
    ).rejects.toMatchObject({ reason: 'invalid-feedback' });
  });

  it('re-enforces the per-file limit against a batch whose limit was raised', async () => {
    const batch = resolveSubmissionFeedbackWrites(report(), 8, [input()], { maxBytesPerFile: 4096 });
    batch.maxBytesPerFile = 4;

    await expect(
      preflightSubmissionFeedbackExport(client(), options(batch))
    ).rejects.toMatchObject({ reason: 'invalid-feedback' });
  });

  it('changes the fingerprint when the reviewed bytes or metadata change', async () => {
    server.use(assignment());
    const batch = batchOf(input());
    const original = await preflightSubmissionFeedbackExport(client(), options(batch));

    server.use(assignment());
    batch.writes[0].data = pdf('rewritten');
    const afterBytes = await preflightSubmissionFeedbackExport(client(), options(batch));
    expect(afterBytes.batchFingerprint).not.toBe(original.batchFingerprint);

    server.use(assignment());
    batch.writes[0].textComment = 'Something else entirely';
    const afterText = await preflightSubmissionFeedbackExport(client(), options(batch));
    expect(afterText.batchFingerprint).not.toBe(afterBytes.batchFingerprint);
  });
});

describe('postSubmissionFeedbackPdfs', () => {
  const options = (batch: CanvasSubmissionFeedbackBatch, extra = {}) => ({
    courseId: 7,
    gradeItemId: 8,
    batch,
    ...extra,
  });

  it('attaches one PDF and its text to the requested attempt in a single comment', async () => {
    let comment: unknown;
    let includedHistory = '';
    server.use(
      assignment(),
      http.get(submissionUrl(2), ({ request }) => {
        includedHistory = new URL(request.url).searchParams.getAll('include[]').join(',');
        return HttpResponse.json({
          assignment_id: 8,
          user_id: 2,
          attempt: 3,
          submission_history: [
            { assignment_id: 8, user_id: 2, attempt: 1 },
            { assignment_id: 8, user_id: 2, attempt: 2 },
            { assignment_id: 8, user_id: 2, attempt: 3 },
          ],
        });
      }),
      http.post(`${submissionUrl(2)}/comments/files`, () =>
        HttpResponse.json({ upload_url: UPLOAD_URL, upload_params: { key: 'k' } })
      ),
      http.post(UPLOAD_URL, () => HttpResponse.json({ id: 4242 }, { status: 201 })),
      http.put(submissionUrl(2), async ({ request }) => {
        comment = await request.json();
        return HttpResponse.json({ id: 902 });
      })
    );

    const batch = batchOf(input({ attempt: 2, textComment: 'Your feedback is attached.' }));
    const result = await postSubmissionFeedbackPdfs(client(), options(batch));

    expect(includedHistory).toBe('submission_history');
    expect(comment).toEqual({
      comment: {
        file_ids: ['4242'],
        attempt: 2,
        text_comment: 'Your feedback is attached.',
      },
    });
    expect(result).toMatchObject({ courseId: '7', gradeItemId: '8', postManually: true });
    expect(result.results).toEqual([
      {
        feedbackId: 'fb-1',
        userId: '2',
        attempt: 2,
        status: 'attached',
        fileId: '4242',
        filename: 'feedback.pdf',
        raw: { id: 902 },
      },
    ]);
  });

  it('omits text_comment when the host supplied none', async () => {
    let comment: Record<string, Record<string, unknown>> = {};
    server.use(
      assignment(),
      ...workingStudent(2, { onComment: (body) => { comment = body as typeof comment; } })
    );

    await postSubmissionFeedbackPdfs(client(), options(batchOf(input())));

    expect(comment.comment).not.toHaveProperty('text_comment');
    expect(comment.comment).not.toHaveProperty('group_comment');
  });

  it('fails an item before uploading when the requested attempt does not exist', async () => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch');
    server.use(
      assignment(),
      http.get(submissionUrl(2), () =>
        HttpResponse.json({
          assignment_id: 8,
          user_id: 2,
          attempt: 3,
          submission_history: [{ assignment_id: 8, user_id: 2, attempt: 3 }],
        })
      )
    );

    const result = await postSubmissionFeedbackPdfs(client(), options(batchOf(input({ attempt: 1 }))));

    expect(result.results[0]).toMatchObject({
      feedbackId: 'fb-1',
      status: 'failed',
      stage: 'verify-submission',
    });
    // The assignment read and the submission read, and nothing else.
    expect(fetchSpy.mock.calls).toHaveLength(2);
    fetchSpy.mockRestore();
  });

  it('fails an item when Canvas answers with a different student', async () => {
    server.use(
      assignment(),
      http.get(submissionUrl(2), () =>
        HttpResponse.json({ assignment_id: 8, user_id: 5, attempt: 1 })
      )
    );

    const result = await postSubmissionFeedbackPdfs(client(), options(batchOf(input())));

    expect(result.results[0]).toMatchObject({ status: 'failed', stage: 'verify-submission' });
  });

  it('does not verify an attempt using a history row for another student', async () => {
    server.use(
      assignment(),
      http.get(submissionUrl(2), () =>
        HttpResponse.json({
          assignment_id: 8,
          user_id: 2,
          attempt: 2,
          submission_history: [
            { assignment_id: 8, user_id: 99, attempt: 1 },
            { assignment_id: 8, user_id: 2, attempt: 2 },
          ],
        })
      )
    );

    const result = await postSubmissionFeedbackPdfs(
      client(),
      options(batchOf(input({ attempt: 1 })))
    );

    expect(result.results[0]).toMatchObject({ status: 'failed', stage: 'verify-submission' });
  });

  it('refuses a stale preflight before anything is uploaded', async () => {
    server.use(assignment());
    const batch = batchOf(input());
    const preflight = await preflightSubmissionFeedbackExport(client(), options(batch));

    // The instructor reviewed one PDF; a different one is in the batch now.
    batch.writes[0].data = pdf('swapped after review');
    server.use(assignment());

    await expect(
      postSubmissionFeedbackPdfs(client(), options(batch, { preflight }))
    ).rejects.toMatchObject({ reason: 'preflight-stale' });
  });

  it('refuses when the assignment changed during review', async () => {
    server.use(assignment({ post_manually: true }));
    const batch = batchOf(input());
    const preflight = await preflightSubmissionFeedbackExport(client(), options(batch));

    server.use(assignment({ post_manually: false }));

    await expect(
      postSubmissionFeedbackPdfs(client(), options(batch, { preflight }))
    ).rejects.toMatchObject({ reason: 'preflight-stale' });
  });

  it('accepts a preflight that still matches', async () => {
    server.use(assignment());
    const batch = batchOf(input());
    const preflight = await preflightSubmissionFeedbackExport(client(), options(batch));

    server.use(assignment(), ...workingStudent(2));
    const result = await postSubmissionFeedbackPdfs(client(), options(batch, { preflight }));

    expect(result.results[0].status).toBe('attached');
  });

  it.each([0, 11, 2.5])('refuses concurrency %s', async (concurrency) => {
    await expect(
      postSubmissionFeedbackPdfs(client(), options(batchOf(input()), { concurrency }))
    ).rejects.toMatchObject({ name: 'CanvasApiError', statusCode: 400 });
  });

  it('keeps results in batch order under concurrency, and one failure does not erase the rest', async () => {
    const roster = matchRosterByIntegrationId(
      7,
      [student(2, 'PUID-0001'), student(3, 'PUID-0002'), student(4, 'PUID-0003')],
      ['PUID-0001', 'PUID-0002', 'PUID-0003']
    );
    const batch = resolveSubmissionFeedbackWrites(
      roster,
      8,
      [
        input({ feedbackId: 'fb-1', key: 'PUID-0001' }),
        input({ feedbackId: 'fb-2', key: 'PUID-0002' }),
        input({ feedbackId: 'fb-3', key: 'PUID-0003' }),
      ],
      LIMIT
    );

    server.use(
      assignment(),
      // The first student is slow, so completion order is not batch order.
      http.get(submissionUrl(2), async () => {
        await new Promise((resolve) => setTimeout(resolve, 25));
        return HttpResponse.json({ assignment_id: 8, user_id: 2, attempt: 1 });
      }),
      http.post(`${submissionUrl(2)}/comments/files`, () =>
        HttpResponse.json({ upload_url: UPLOAD_URL, upload_params: { key: 'k' } })
      ),
      http.post(UPLOAD_URL, () => HttpResponse.json({ id: 4002 }, { status: 201 })),
      http.put(submissionUrl(2), () => HttpResponse.json({ id: 902 })),
      // The second student's submission read fails outright.
      http.get(submissionUrl(3), () => new HttpResponse(null, { status: 404 })),
      ...workingStudent(4, { fileId: 4004 })
    );

    const completionOrder: string[] = [];
    const result = await postSubmissionFeedbackPdfs(
      client(),
      options(batch, { concurrency: 3, onItemComplete: (item: { feedbackId: string }) => completionOrder.push(item.feedbackId) })
    );

    expect(result.results.map((item) => item.feedbackId)).toEqual(['fb-1', 'fb-2', 'fb-3']);
    expect(result.results.map((item) => item.status)).toEqual(['attached', 'failed', 'attached']);
    expect(result.results[1]).toMatchObject({ stage: 'verify-submission', statusCode: 404 });
    expect(completionOrder[completionOrder.length - 1]).toBe('fb-1');
  });

  it('stops scheduling and marks the rest not-attempted when authorization is lost', async () => {
    const roster = matchRosterByIntegrationId(
      7,
      [student(2, 'PUID-0001'), student(3, 'PUID-0002')],
      ['PUID-0001', 'PUID-0002']
    );
    const batch = resolveSubmissionFeedbackWrites(
      roster,
      8,
      [input({ feedbackId: 'fb-1', key: 'PUID-0001' }), input({ feedbackId: 'fb-2', key: 'PUID-0002' })],
      LIMIT
    );

    let secondStudentRead = false;
    server.use(
      assignment(),
      http.get(submissionUrl(2), () => new HttpResponse(null, { status: 401 })),
      http.get(submissionUrl(3), () => {
        secondStudentRead = true;
        return HttpResponse.json({ assignment_id: 8, user_id: 3, attempt: 1 });
      })
    );

    const result = await postSubmissionFeedbackPdfs(client(), options(batch, { concurrency: 1 }));

    expect(result.results[0]).toMatchObject({ status: 'failed', statusCode: 401 });
    expect(result.results[1]).toMatchObject({ status: 'not-attempted', stage: 'verify-submission' });
    expect(secondStudentRead).toBe(false);
  });

  it('reports the uploaded file id when the comment write is rejected', async () => {
    server.use(
      assignment(),
      http.get(submissionUrl(2), () => HttpResponse.json({ assignment_id: 8, user_id: 2, attempt: 1 })),
      http.post(`${submissionUrl(2)}/comments/files`, () =>
        HttpResponse.json({ upload_url: UPLOAD_URL, upload_params: { key: 'k' } })
      ),
      http.post(UPLOAD_URL, () => HttpResponse.json({ id: 4242 }, { status: 201 })),
      http.put(submissionUrl(2), () => new HttpResponse(null, { status: 500 }))
    );

    const result = await postSubmissionFeedbackPdfs(client(), options(batchOf(input())));

    expect(result.results[0]).toMatchObject({
      status: 'failed',
      stage: 'attach-comment',
      statusCode: 500,
      fileId: '4242',
    });
  });

  it('reports an interrupted comment write as unknown rather than failed', async () => {
    server.use(
      assignment(),
      http.get(submissionUrl(2), () => HttpResponse.json({ assignment_id: 8, user_id: 2, attempt: 1 })),
      http.post(`${submissionUrl(2)}/comments/files`, () =>
        HttpResponse.json({ upload_url: UPLOAD_URL, upload_params: { key: 'k' } })
      ),
      http.post(UPLOAD_URL, () => HttpResponse.json({ id: 4242 }, { status: 201 })),
      http.put(submissionUrl(2), () => HttpResponse.error())
    );

    const result = await postSubmissionFeedbackPdfs(client(), options(batchOf(input())));

    expect(result.results[0]).toMatchObject({
      status: 'unknown',
      stage: 'attach-comment',
      fileId: '4242',
    });
  });

  it('records the upload stage that failed and does not retry it', async () => {
    let uploadAttempts = 0;
    server.use(
      assignment(),
      http.get(submissionUrl(2), () => HttpResponse.json({ assignment_id: 8, user_id: 2, attempt: 1 })),
      http.post(`${submissionUrl(2)}/comments/files`, () =>
        HttpResponse.json({ upload_url: UPLOAD_URL, upload_params: { key: 'k' } })
      ),
      http.post(UPLOAD_URL, () => {
        uploadAttempts += 1;
        return new HttpResponse(null, { status: 500 });
      })
    );

    const result = await postSubmissionFeedbackPdfs(client(), options(batchOf(input())));

    expect(result.results[0]).toMatchObject({ status: 'failed', stage: 'upload-bytes', statusCode: 500 });
    expect(uploadAttempts).toBe(1);
  });

  it('never puts a PUID, PDF content, or feedback text in a refusal message', async () => {
    server.use(assignment());
    const batch = batchOf(input({ key: 'PUID-0001', textComment: 'A private remark' }));
    batch.writes[0].filename = 'feedback.docx';

    const failure = await preflightSubmissionFeedbackExport(client(), options(batch)).then(
      () => null,
      (error: unknown) => error as CanvasSubmissionFeedbackError
    );

    expect(failure).toBeInstanceOf(CanvasSubmissionFeedbackError);
    expect(failure?.message).toContain('fb-1');
    expect(failure?.message).not.toContain('PUID');
    expect(failure?.message).not.toContain('A private remark');
    expect(failure?.message).not.toContain('%PDF');
  });

  it('exports a 300-student course with bounded concurrency and one result per item', async () => {
    const roster = matchRosterByIntegrationId(
      7,
      Array.from({ length: 300 }, (_, index) => student(1000 + index, `PUID-${index}`)),
      Array.from({ length: 300 }, (_, index) => `PUID-${index}`)
    );
    const batch = resolveSubmissionFeedbackWrites(
      roster,
      8,
      Array.from({ length: 300 }, (_, index) =>
        input({ feedbackId: `fb-${index}`, key: `PUID-${index}` })
      ),
      LIMIT
    );

    let inFlight = 0;
    let peakInFlight = 0;
    server.use(
      assignment(),
      http.get(`${ASSIGNMENT_URL}/submissions/:userId`, async ({ params }) => {
        inFlight += 1;
        peakInFlight = Math.max(peakInFlight, inFlight);
        await new Promise((resolve) => setTimeout(resolve, 1));
        inFlight -= 1;
        return HttpResponse.json({
          assignment_id: 8,
          user_id: Number(params.userId),
          attempt: 1,
        });
      }),
      http.post(`${ASSIGNMENT_URL}/submissions/:userId/comments/files`, () =>
        HttpResponse.json({ upload_url: UPLOAD_URL, upload_params: { key: 'k' } })
      ),
      http.post(UPLOAD_URL, () => HttpResponse.json({ id: 4242 }, { status: 201 })),
      http.put(`${ASSIGNMENT_URL}/submissions/:userId`, () => HttpResponse.json({ id: 1 }))
    );

    const result = await postSubmissionFeedbackPdfs(client(), options(batch, { concurrency: 4 }));

    expect(result.results).toHaveLength(300);
    expect(result.results.every((item) => item.status === 'attached')).toBe(true);
    expect(result.results.map((item) => item.feedbackId)).toEqual(
      Array.from({ length: 300 }, (_, index) => `fb-${index}`)
    );
    expect(peakInFlight).toBeLessThanOrEqual(4);
  });
});
