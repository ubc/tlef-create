import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { loadConfigFromEnv } from '../src/providers/canvas/env-config';

const ENV_KEYS = ['CANVAS_DOMAIN', 'CANVAS_CLIENT_ID', 'CANVAS_CLIENT_SECRET', 'CANVAS_REDIRECT_URI'] as const;
const originalEnv: Record<string, string | undefined> = {};

beforeEach(() => {
  for (const key of ENV_KEYS) originalEnv[key] = process.env[key];
});

afterEach(() => {
  for (const key of ENV_KEYS) {
    if (originalEnv[key] === undefined) delete process.env[key];
    else process.env[key] = originalEnv[key];
  }
});

function setEnv(overrides: Partial<Record<(typeof ENV_KEYS)[number], string>>) {
  for (const key of ENV_KEYS) delete process.env[key];
  Object.assign(process.env, overrides);
}

describe('loadCanvasConfigFromEnv', () => {
  it('builds a config from process.env merged with the provided overrides', () => {
    setEnv({
      CANVAS_DOMAIN: 'ubc.instructure.com',
      CANVAS_CLIENT_ID: 'id',
      CANVAS_CLIENT_SECRET: 'secret',
      CANVAS_REDIRECT_URI: 'http://localhost/canvas/auth/callback',
    });

    const tokenStore = { get: async () => null, set: async () => {}, delete: async () => {} };
    const getUserKey = () => 'user-1';
    const config = loadConfigFromEnv({ tokenStore, getUserKey, scopes: ['url:GET|/api/v1/courses'] });

    expect(config).toEqual({
      canvasDomain: 'ubc.instructure.com',
      clientId: 'id',
      clientSecret: 'secret',
      redirectUri: 'http://localhost/canvas/auth/callback',
      tokenStore,
      getUserKey,
      scopes: ['url:GET|/api/v1/courses'],
    });
  });

  it('throws listing every missing env var by name', () => {
    setEnv({ CANVAS_DOMAIN: 'ubc.instructure.com' });

    expect(() =>
      loadConfigFromEnv({ tokenStore: {} as never, getUserKey: () => 'x' })
    ).toThrowError(/CANVAS_CLIENT_ID.*CANVAS_CLIENT_SECRET.*CANVAS_REDIRECT_URI/s);
  });

  it('does not throw when all four vars are set, even if empty overrides are given', () => {
    setEnv({
      CANVAS_DOMAIN: 'ubc.instructure.com',
      CANVAS_CLIENT_ID: 'id',
      CANVAS_CLIENT_SECRET: 'secret',
      CANVAS_REDIRECT_URI: 'http://localhost/canvas/auth/callback',
    });

    expect(() =>
      loadConfigFromEnv({ tokenStore: {} as never, getUserKey: () => 'x' })
    ).not.toThrow();
  });
});
