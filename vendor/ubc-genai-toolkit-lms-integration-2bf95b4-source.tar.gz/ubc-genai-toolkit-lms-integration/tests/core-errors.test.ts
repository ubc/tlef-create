import { describe, it, expect } from 'vitest';
import { LmsError } from '../src/core/errors';

describe('LmsError', () => {
  it('carries the provider and sets name/message', () => {
    const err = new LmsError('something broke', 'moodle');
    expect(err).toBeInstanceOf(Error);
    expect(err.name).toBe('LmsError');
    expect(err.message).toBe('something broke');
    expect(err.provider).toBe('moodle');
  });
});
