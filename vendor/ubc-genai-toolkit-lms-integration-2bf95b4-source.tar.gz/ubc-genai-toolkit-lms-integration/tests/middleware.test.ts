import { describe, it, expect, beforeAll, afterEach, afterAll } from 'vitest';
import express from 'express';
import request from 'supertest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { ensureAuth, requireAuth } from '../src/providers/canvas/middleware';
import type { Config, Tokens } from '../src/providers/canvas/types';
import type { TokenStore } from '../src/core/types';

// 'bypass' (not 'error') because supertest's own requests to the local test
// server go through the same network layer msw intercepts — only requests
// matching an explicit handler below (the real Canvas domain) should be mocked.
const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'bypass' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

class FakeTokenStore implements TokenStore<Tokens> {
  private store = new Map<string, Tokens>();
  async get(userKey: string) {
    return this.store.get(userKey) ?? null;
  }
  async set(userKey: string, tokens: Tokens) {
    this.store.set(userKey, tokens);
  }
  async delete(userKey: string) {
    this.store.delete(userKey);
  }
}

function makeApp(config: Config) {
  const app = express();
  app.get('/protected', ensureAuth(config), async (req, res) => {
    const courses = await req.canvasApi!.get('/courses');
    res.json({ courses });
  });
  return app;
}

function makeJsonApp(config: Config) {
  const app = express();
  app.get('/protected', requireAuth(config), async (req, res) => {
    const courses = await req.canvasApi!.get('/courses');
    res.json({ courses });
  });
  return app;
}

function baseConfig(tokenStore: TokenStore<Tokens>, overrides: Partial<Config> = {}): Config {
  return {
    canvasDomain: 'ubc.instructure.com',
    clientId: 'client-id',
    clientSecret: 'client-secret',
    redirectUri: 'http://localhost/canvas/auth/callback',
    tokenStore,
    getUserKey: () => 'user-1',
    ...overrides,
  };
}

describe('ensureCanvasAuth', () => {
  it('redirects to login (preserving the original URL) when no tokens are stored', async () => {
    const app = makeApp(baseConfig(new FakeTokenStore()));

    const res = await request(app).get('/protected?x=1');
    expect(res.status).toBe(302);
    const location = new URL(res.headers.location, 'http://localhost');
    expect(location.pathname).toBe('/canvas/auth/login');
    expect(location.searchParams.get('returnTo')).toBe('/protected?x=1');
  });

  it('uses a custom basePath for the login redirect', async () => {
    const app = makeApp(baseConfig(new FakeTokenStore(), { basePath: '/integrations/canvas' }));

    const res = await request(app).get('/protected');
    const location = new URL(res.headers.location, 'http://localhost');
    expect(location.pathname).toBe('/integrations/canvas/login');
  });

  it('supports an async getUserKey (e.g. a session-store lookup)', async () => {
    server.use(http.get('https://ubc.instructure.com/api/v1/courses', () => HttpResponse.json([{ id: 1 }])));
    const tokenStore = new FakeTokenStore();
    await tokenStore.set('async-resolved-user', {
      accessToken: 'access-1',
      refreshToken: 'refresh-1',
      expiresAt: Date.now() + 3_600_000,
      canvasUserId: '42',
    });
    const getUserKey = async (): Promise<string> => {
      await new Promise((resolve) => setTimeout(resolve, 0));
      return 'async-resolved-user';
    };
    const app = makeApp(baseConfig(tokenStore, { getUserKey }));

    const res = await request(app).get('/protected');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ courses: [{ id: 1 }] });
  });

  it('attaches req.canvasApi when a valid, unexpired token exists', async () => {
    server.use(http.get('https://ubc.instructure.com/api/v1/courses', () => HttpResponse.json([{ id: 1 }])));
    const tokenStore = new FakeTokenStore();
    await tokenStore.set('user-1', {
      accessToken: 'access-1',
      refreshToken: 'refresh-1',
      expiresAt: Date.now() + 3_600_000,
      canvasUserId: '42',
    });
    const app = makeApp(baseConfig(tokenStore));

    const res = await request(app).get('/protected');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ courses: [{ id: 1 }] });
  });

  it('transparently refreshes an expired token before calling next()', async () => {
    server.use(
      http.post('https://ubc.instructure.com/login/oauth2/token', () =>
        HttpResponse.json({ access_token: 'access-2', expires_in: 3600 })
      ),
      http.get('https://ubc.instructure.com/api/v1/courses', ({ request }) => {
        expect(request.headers.get('Authorization')).toBe('Bearer access-2');
        return HttpResponse.json([{ id: 1 }]);
      })
    );
    const tokenStore = new FakeTokenStore();
    await tokenStore.set('user-1', {
      accessToken: 'access-1',
      refreshToken: 'refresh-1',
      expiresAt: Date.now() - 1000,
      canvasUserId: '42',
    });
    const app = makeApp(baseConfig(tokenStore));

    const res = await request(app).get('/protected');
    expect(res.status).toBe(200);

    const updated = await tokenStore.get('user-1');
    expect(updated?.accessToken).toBe('access-2');
    // Canvas didn't rotate the refresh token in this response, so the old one must be kept.
    expect(updated?.refreshToken).toBe('refresh-1');
  });

  it('redirects to login and clears the store when refresh fails', async () => {
    server.use(
      http.post('https://ubc.instructure.com/login/oauth2/token', () =>
        HttpResponse.json({ error: 'invalid_grant' }, { status: 400 })
      )
    );
    const tokenStore = new FakeTokenStore();
    await tokenStore.set('user-1', {
      accessToken: 'access-1',
      refreshToken: 'revoked-refresh-token',
      expiresAt: Date.now() - 1000,
      canvasUserId: '42',
    });
    const app = makeApp(baseConfig(tokenStore));

    const res = await request(app).get('/protected');
    expect(res.status).toBe(302);
    expect(await tokenStore.get('user-1')).toBeNull();
  });
});

describe('requireCanvasAuth', () => {
  it('responds 401 with connected:false and a connectUrl when no tokens are stored', async () => {
    const app = makeJsonApp(baseConfig(new FakeTokenStore()));

    const res = await request(app).get('/protected?x=1');
    expect(res.status).toBe(401);
    expect(res.body.success).toBe(false);
    expect(res.body.connected).toBe(false);
    const connectUrl = new URL(res.body.connectUrl, 'http://localhost');
    expect(connectUrl.pathname).toBe('/canvas/auth/login');
    expect(connectUrl.searchParams.get('returnTo')).toBe('/protected?x=1');
  });

  it('uses a custom basePath when building connectUrl', async () => {
    const app = makeJsonApp(baseConfig(new FakeTokenStore(), { basePath: '/integrations/canvas' }));

    const res = await request(app).get('/protected');
    const connectUrl = new URL(res.body.connectUrl, 'http://localhost');
    expect(connectUrl.pathname).toBe('/integrations/canvas/login');
  });

  it('attaches req.canvasApi and calls next() when a valid token exists', async () => {
    server.use(http.get('https://ubc.instructure.com/api/v1/courses', () => HttpResponse.json([{ id: 1 }])));
    const tokenStore = new FakeTokenStore();
    await tokenStore.set('user-1', {
      accessToken: 'access-1',
      refreshToken: 'refresh-1',
      expiresAt: Date.now() + 3_600_000,
      canvasUserId: '42',
    });
    const app = makeJsonApp(baseConfig(tokenStore));

    const res = await request(app).get('/protected');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ courses: [{ id: 1 }] });
  });

  it('responds 401 (not a redirect) when refresh fails', async () => {
    server.use(
      http.post('https://ubc.instructure.com/login/oauth2/token', () =>
        HttpResponse.json({ error: 'invalid_grant' }, { status: 400 })
      )
    );
    const tokenStore = new FakeTokenStore();
    await tokenStore.set('user-1', {
      accessToken: 'access-1',
      refreshToken: 'revoked-refresh-token',
      expiresAt: Date.now() - 1000,
      canvasUserId: '42',
    });
    const app = makeJsonApp(baseConfig(tokenStore));

    const res = await request(app).get('/protected');
    expect(res.status).toBe(401);
    expect(res.body.connected).toBe(false);
    expect(await tokenStore.get('user-1')).toBeNull();
  });
});
