import { afterAll, afterEach, beforeAll, describe, expect, it } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createApiClient } from '../src/providers/canvas/api-client';
import { getGradeItems, getGrades } from '../src/providers/canvas/resources/grades';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const client = () => createApiClient({ canvasDomain: 'ubc.instructure.com', accessToken: 'token-1' });

describe('Canvas grades', () => {
  it('normalizes assignments as grade items', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/assignments', () =>
        HttpResponse.json([{ id: 8, name: 'Lab 1', points_possible: 20, due_at: '2026-09-01T00:00:00Z' }])
      )
    );
    await expect(getGradeItems(client(), 7)).resolves.toEqual([
      expect.objectContaining({ id: '8', courseId: '7', name: 'Lab 1', maxScore: 20 }),
    ]);
  });

  it('normalizes overall enrollment grades', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/enrollments', () =>
        HttpResponse.json([{ user_id: 2, grades: { current_score: 88.5, current_grade: 'A' } }])
      )
    );
    await expect(getGrades(client(), { courseId: 7 })).resolves.toEqual([
      expect.objectContaining({ courseId: '7', userId: '2', score: 88.5, grade: 'A' }),
    ]);
  });

  it('returns every assignment across pages, not just Canvas\'s first page', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/assignments', ({ request }) => {
        const page = Number(new URL(request.url).searchParams.get('page') ?? '1');
        return HttpResponse.json([{ id: page, name: `Lab ${page}`, points_possible: 20 }], {
          headers: page < 3
            ? { Link: `<https://ubc.instructure.com/api/v1/courses/7/assignments?page=${page + 1}>; rel="next"` }
            : {},
        });
      })
    );

    const items = await getGradeItems(client(), 7);
    expect(items.map((item) => item.name)).toEqual(['Lab 1', 'Lab 2', 'Lab 3']);
  });

  it('returns every enrolled student across pages', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/enrollments', ({ request }) => {
        const page = Number(new URL(request.url).searchParams.get('page') ?? '1');
        return HttpResponse.json([{ user_id: page, grades: { current_score: 70 + page } }], {
          headers: page < 2
            ? { Link: `<https://ubc.instructure.com/api/v1/courses/7/enrollments?page=${page + 1}>; rel="next"` }
            : {},
        });
      })
    );

    const grades = await getGrades(client(), { courseId: 7 });
    expect(grades.map((grade) => grade.userId)).toEqual(['1', '2']);
  });

  it('normalizes assignment submissions and filters requested users', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/assignments/8', () =>
        HttpResponse.json({ id: 8, name: 'Lab 1', points_possible: 20 })
      ),
      http.get('https://ubc.instructure.com/api/v1/courses/7/assignments/8/submissions', () =>
        HttpResponse.json([
          { assignment_id: 8, user_id: 2, score: 18, grade: '18', graded_at: '2026-09-02T00:00:00Z' },
          { assignment_id: 8, user_id: 3, score: 15, grade: '15' },
        ])
      )
    );
    await expect(getGrades(client(), { courseId: 7, gradeItemId: 8, userIds: [2] })).resolves.toEqual([
      expect.objectContaining({ gradeItemId: '8', userId: '2', score: 18, maxScore: 20 }),
    ]);
  });
});
