import { describe, it, expect } from 'vitest';
import { parseLinkHeader } from '../src/providers/canvas/link-header';

describe('parseLinkHeader', () => {
  it('maps every rel to its URL', () => {
    const header = [
      '<https://ubc.instructure.com/api/v1/courses?page=2&per_page=100>; rel="current"',
      '<https://ubc.instructure.com/api/v1/courses?page=3&per_page=100>; rel="next"',
      '<https://ubc.instructure.com/api/v1/courses?page=1&per_page=100>; rel="first"',
      '<https://ubc.instructure.com/api/v1/courses?page=9&per_page=100>; rel="last"',
    ].join(',');

    expect(parseLinkHeader(header)).toEqual({
      current: 'https://ubc.instructure.com/api/v1/courses?page=2&per_page=100',
      next: 'https://ubc.instructure.com/api/v1/courses?page=3&per_page=100',
      first: 'https://ubc.instructure.com/api/v1/courses?page=1&per_page=100',
      last: 'https://ubc.instructure.com/api/v1/courses?page=9&per_page=100',
    });
  });

  it('keeps bookmark cursors intact', () => {
    const header = '<https://ubc.instructure.com/api/v1/courses?page=bookmark:WyIxMCJd&per_page=100>; rel="next"';
    expect(parseLinkHeader(header).next).toBe(
      'https://ubc.instructure.com/api/v1/courses?page=bookmark:WyIxMCJd&per_page=100'
    );
  });

  it('accepts an unquoted rel', () => {
    expect(parseLinkHeader('<https://host/api/v1/courses?page=2>; rel=next').next)
      .toBe('https://host/api/v1/courses?page=2');
  });

  it('returns nothing for a missing or unparseable header', () => {
    expect(parseLinkHeader(null)).toEqual({});
    expect(parseLinkHeader(undefined)).toEqual({});
    expect(parseLinkHeader('')).toEqual({});
    expect(parseLinkHeader('garbage')).toEqual({});
  });

  it('ignores an entry with no rel', () => {
    const header = '<https://host/api/v1/courses?page=2>; title="second", <https://host/api/v1/courses?page=3>; rel="next"';
    expect(parseLinkHeader(header)).toEqual({ next: 'https://host/api/v1/courses?page=3' });
  });
});
