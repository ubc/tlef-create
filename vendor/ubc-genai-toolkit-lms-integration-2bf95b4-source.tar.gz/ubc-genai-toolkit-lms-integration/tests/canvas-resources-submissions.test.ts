import { afterAll, afterEach, beforeAll, describe, expect, it } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createApiClient } from '../src/providers/canvas/api-client';
import {
  downloadSubmissionAttachment,
  getSubmissions,
  resolveSubmissions,
} from '../src/providers/canvas/resources/submissions';
import { matchRosterByIntegrationId } from '../src/core/roster';
import type { LmsSubmission } from '../src/core/types';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const client = () => createApiClient({ canvasDomain: 'ubc.instructure.com', accessToken: 'token-1' });
const SUBMISSIONS_URL = 'https://ubc.instructure.com/api/v1/courses/7/assignments/8/submissions';

describe('Canvas submissions', () => {
  it('normalizes submitted work, including attachments and text entries', async () => {
    server.use(
      http.get(SUBMISSIONS_URL, () =>
        HttpResponse.json([
          {
            assignment_id: 8,
            user_id: 2,
            attempt: 2,
            workflow_state: 'submitted',
            submitted_at: '2026-09-10T18:00:00Z',
            late: true,
            missing: false,
            body: '<p>My answer</p>',
            score: null,
            attachments: [
              {
                id: 44,
                filename: 'lab1.pdf',
                display_name: 'Lab 1.pdf',
                'content-type': 'application/pdf',
                size: 2048,
                url: 'https://ubc.instructure.com/files/44/download?verifier=abc',
              },
            ],
          },
        ])
      )
    );

    const [submission] = await getSubmissions(client(), { courseId: 7, gradeItemId: 8 });
    expect(submission).toMatchObject({
      courseId: '7',
      gradeItemId: '8',
      userId: '2',
      attempt: 2,
      workflowState: 'submitted',
      submittedAt: '2026-09-10T18:00:00Z',
      late: true,
      missing: false,
      body: '<p>My answer</p>',
    });
    expect(submission.attachments).toEqual([
      {
        id: '44',
        filename: 'lab1.pdf',
        displayName: 'Lab 1.pdf',
        mimeType: 'application/pdf',
        size: 2048,
        url: 'https://ubc.instructure.com/files/44/download?verifier=abc',
      },
    ]);
  });

  it('excludes the placeholders Canvas returns for students who never submitted', async () => {
    server.use(
      http.get(SUBMISSIONS_URL, () =>
        HttpResponse.json([
          { assignment_id: 8, user_id: 2, workflow_state: 'submitted' },
          { assignment_id: 8, user_id: 3, workflow_state: 'unsubmitted' },
        ])
      )
    );

    const submitted = await getSubmissions(client(), { courseId: 7, gradeItemId: 8 });
    expect(submitted.map((submission) => submission.userId)).toEqual(['2']);

    const everyone = await getSubmissions(client(), {
      courseId: 7,
      gradeItemId: 8,
      includeUnsubmitted: true,
    });
    expect(everyone.map((submission) => submission.userId)).toEqual(['2', '3']);
  });

  it('narrows to the requested Canvas user ids', async () => {
    server.use(
      http.get(SUBMISSIONS_URL, () =>
        HttpResponse.json([
          { assignment_id: 8, user_id: 2, workflow_state: 'submitted' },
          { assignment_id: 8, user_id: 3, workflow_state: 'submitted' },
        ])
      )
    );

    const submissions = await getSubmissions(client(), {
      courseId: 7,
      gradeItemId: 8,
      userIds: ['3'],
    });
    expect(submissions.map((submission) => submission.userId)).toEqual(['3']);
  });

  it('reads every page, so cut-off students never look unsubmitted', async () => {
    server.use(
      http.get(SUBMISSIONS_URL, ({ request }) => {
        const page = Number(new URL(request.url).searchParams.get('page') ?? '1');
        return HttpResponse.json([{ assignment_id: 8, user_id: page, workflow_state: 'submitted' }], {
          headers: page < 3 ? { Link: `<${SUBMISSIONS_URL}?page=${page + 1}>; rel="next"` } : {},
        });
      })
    );

    const submissions = await getSubmissions(client(), { courseId: 7, gradeItemId: 8 });
    expect(submissions.map((submission) => submission.userId)).toEqual(['1', '2', '3']);
  });

  it('drops attachments Canvas gave no URL for rather than failing later', async () => {
    server.use(
      http.get(SUBMISSIONS_URL, () =>
        HttpResponse.json([
          {
            assignment_id: 8,
            user_id: 2,
            workflow_state: 'submitted',
            attachments: [{ id: 44, filename: 'lab1.pdf' }],
          },
        ])
      )
    );

    const [submission] = await getSubmissions(client(), { courseId: 7, gradeItemId: 8 });
    expect(submission.attachments).toEqual([]);
  });
});

describe('downloadSubmissionAttachment', () => {
  const SUBMISSION_URL = `${SUBMISSIONS_URL}/2`;
  const target = { courseId: 7, gradeItemId: 8, userId: 2, attachmentId: 44, maxBytes: 1_000 };

  function submissionHandler(attachments: unknown[]) {
    return http.get(SUBMISSION_URL, () =>
      HttpResponse.json({ assignment_id: 8, user_id: 2, workflow_state: 'submitted', attachments })
    );
  }

  const attachment = {
    id: 44,
    filename: 'lab1.pdf',
    display_name: 'Lab 1.pdf',
    'content-type': 'application/pdf',
    size: 5,
    url: 'https://ubc.instructure.com/files/44/download?verifier=abc',
  };

  it('resolves the attachment through the course and assignment before downloading', async () => {
    server.use(
      submissionHandler([attachment]),
      http.get('https://ubc.instructure.com/files/44/download', ({ request }) => {
        expect(request.headers.get('authorization')).toBe('Bearer token-1');
        // Canvas sends no content-disposition here, so the name has to come
        // from the attachment metadata rather than the download response.
        return new HttpResponse(new Uint8Array([1, 2, 3, 4, 5]), {
          headers: { 'content-type': 'application/pdf' },
        });
      })
    );

    const download = await downloadSubmissionAttachment(client(), target);
    expect(download.size).toBe(5);
    expect(download.filename).toBe('lab1.pdf');
    expect(download.contentType).toBe('application/pdf');
  });

  it('refuses an attachment that is not on this student submission', async () => {
    server.use(submissionHandler([attachment]));

    await expect(
      downloadSubmissionAttachment(client(), { ...target, attachmentId: 45 })
    ).rejects.toThrow(/not on user 2's submission/);
  });

  it('rejects a download that came back short of the advertised size', async () => {
    server.use(
      submissionHandler([attachment]),
      http.get('https://ubc.instructure.com/files/44/download', () =>
        new HttpResponse(new Uint8Array([1, 2]), { headers: { 'content-type': 'application/pdf' } })
      )
    );

    await expect(downloadSubmissionAttachment(client(), target)).rejects.toThrow(/incomplete/);
  });

  it('will not follow an attachment URL pointing away from Canvas', async () => {
    server.use(submissionHandler([{ ...attachment, url: 'https://evil.example.com/x' }]));

    await expect(downloadSubmissionAttachment(client(), target)).rejects.toThrow(
      /unexpected file download URL/
    );
  });

  it('enforces the byte ceiling the caller had to choose', async () => {
    server.use(
      submissionHandler([{ ...attachment, size: undefined }]),
      http.get('https://ubc.instructure.com/files/44/download', () =>
        new HttpResponse(new Uint8Array([1, 2, 3, 4, 5]), {
          headers: { 'content-type': 'application/pdf' },
        })
      )
    );

    await expect(
      downloadSubmissionAttachment(client(), { ...target, maxBytes: 2 })
    ).rejects.toThrow(/download limit/);
  });

  it.each([undefined, 0, -1, Number.NaN, Number.POSITIVE_INFINITY])(
    'rejects an invalid runtime byte ceiling (%s) before reading Canvas',
    async (maxBytes) => {
      await expect(
        downloadSubmissionAttachment(client(), { ...target, maxBytes } as typeof target)
      ).rejects.toThrow(/positive safe integer/);
    }
  );
});

describe('resolveSubmissions', () => {
  const roster = [
    { id: '2', name: 'Ada Lovelace', integrationId: 'PUID-0001', raw: {} },
    { id: '3', name: 'Grace Hopper', integrationId: 'PUID-0002', raw: {} },
  ];

  const submission = (userId: string, courseId = '7'): LmsSubmission => ({
    courseId,
    gradeItemId: '8',
    userId,
    workflowState: 'submitted',
    attachments: [],
    raw: {},
  });

  it('keys submissions by the application identifier instead of the Canvas one', () => {
    const report = matchRosterByIntegrationId(7, roster, ['PUID-0001', 'PUID-0002']);
    const resolved = resolveSubmissions(report, 8, [submission('2'), submission('3')]);

    expect(resolved).toMatchObject({ courseId: '7', gradeItemId: '8' });
    expect(resolved.matched.map((entry) => entry.key)).toEqual(['PUID-0001', 'PUID-0002']);
    expect(resolved.unresolved).toEqual([]);
  });

  it('reports a submission whose student has no application account', () => {
    const report = matchRosterByIntegrationId(7, roster, ['PUID-0001']);
    const resolved = resolveSubmissions(report, 8, [submission('2'), submission('3')]);

    expect(resolved.matched).toHaveLength(1);
    expect(resolved.unresolved).toEqual([{ lmsUserId: '3', reason: 'no-app-account' }]);
  });

  it('distinguishes an ambiguous student from one who simply never signed up', () => {
    const report = matchRosterByIntegrationId(
      7,
      [...roster, { id: '4', name: 'Second Ada', integrationId: 'PUID-0001', raw: {} }],
      ['PUID-0001', 'PUID-0002']
    );
    const resolved = resolveSubmissions(report, 8, [submission('2'), submission('4')]);

    expect(resolved.unresolved).toEqual([
      { lmsUserId: '2', reason: 'ambiguous-key' },
      { lmsUserId: '4', reason: 'ambiguous-key' },
    ]);
  });

  it('refuses submissions from a course the report was not built from', () => {
    const report = matchRosterByIntegrationId(7, roster, ['PUID-0001']);

    expect(() => resolveSubmissions(report, 8, [submission('2', '9')])).toThrow(/course 9/);
  });

  it('refuses submissions from another assignment in the same course', () => {
    const report = matchRosterByIntegrationId(7, roster, ['PUID-0001']);
    const wrongAssignment = { ...submission('2'), gradeItemId: '9' };

    expect(() => resolveSubmissions(report, 8, [wrongAssignment])).toThrow(/assignment 9/);
  });

  it('retains the requested assignment when Canvas returns no submissions', () => {
    const report = matchRosterByIntegrationId(7, roster, ['PUID-0001']);

    expect(resolveSubmissions(report, 8, [])).toMatchObject({
      courseId: '7',
      gradeItemId: '8',
      matched: [],
      unresolved: [],
    });
  });

  it('refuses when the roster exposed no integration_id at all', () => {
    const report = matchRosterByIntegrationId(
      7,
      [{ id: '2', name: 'Ada Lovelace', raw: {} }],
      ['PUID-0001']
    );

    expect(() => resolveSubmissions(report, 8, [submission('2')])).toThrow(/no integration_id/);
  });
});
