import { describe, it, expect, beforeAll, afterEach, afterAll } from 'vitest';
import express from 'express';
import request from 'supertest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { requireAuth } from '../src/providers/moodle/middleware';
import type { Config, Tokens } from '../src/providers/moodle/types';
import type { TokenStore } from '../src/core/types';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'bypass' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const REST_URL = 'https://moodle.example.ubc.ca/webservice/rest/server.php';

class FakeTokenStore implements TokenStore<Tokens> {
  private store = new Map<string, Tokens>();
  async get(userKey: string) {
    return this.store.get(userKey) ?? null;
  }
  async set(userKey: string, tokens: Tokens) {
    this.store.set(userKey, tokens);
  }
  async delete(userKey: string) {
    this.store.delete(userKey);
  }
}

function makeApp(config: Config) {
  const app = express();
  app.get('/protected', requireAuth(config), async (req, res) => {
    const courses = await req.moodleApi!.call('core_enrol_get_users_courses', { userid: req.moodleApi!.userId });
    res.json({ courses });
  });
  return app;
}

function baseConfig(tokenStore: TokenStore<Tokens>, overrides: Partial<Config> = {}): Config {
  return {
    moodleDomain: 'moodle.example.ubc.ca',
    tokenStore,
    getUserKey: () => 'user-1',
    ...overrides,
  };
}

describe('requireAuth', () => {
  it('responds 401 with connected:false and a connectUrl when no token is stored', async () => {
    const app = makeApp(baseConfig(new FakeTokenStore()));

    const res = await request(app).get('/protected');
    expect(res.status).toBe(401);
    expect(res.body.success).toBe(false);
    expect(res.body.connected).toBe(false);
    expect(res.body.connectUrl).toBe('/moodle/auth/connect');
  });

  it('uses a custom basePath when building connectUrl', async () => {
    const app = makeApp(baseConfig(new FakeTokenStore(), { basePath: '/integrations/moodle' }));

    const res = await request(app).get('/protected');
    expect(res.body.connectUrl).toBe('/integrations/moodle/connect');
  });

  it('attaches req.moodleApi and calls next() when a token exists', async () => {
    server.use(http.post(REST_URL, () => HttpResponse.json([{ id: 55, shortname: 'CPSC310' }])));
    const tokenStore = new FakeTokenStore();
    await tokenStore.set('user-1', { token: 'tok-1', moodleUserId: '4821' });
    const app = makeApp(baseConfig(tokenStore));

    const res = await request(app).get('/protected');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ courses: [{ id: 55, shortname: 'CPSC310' }] });
  });

  it('supports an async getUserKey', async () => {
    server.use(http.post(REST_URL, () => HttpResponse.json([])));
    const tokenStore = new FakeTokenStore();
    await tokenStore.set('async-resolved-user', { token: 'tok-1', moodleUserId: '4821' });
    const getUserKey = async (): Promise<string> => {
      await new Promise((resolve) => setTimeout(resolve, 0));
      return 'async-resolved-user';
    };
    const app = makeApp(baseConfig(tokenStore, { getUserKey }));

    const res = await request(app).get('/protected');
    expect(res.status).toBe(200);
  });

  it('deletes the stored token and a later request 401s when a call reports invalidtoken', async () => {
    server.use(
      http.post(REST_URL, () =>
        HttpResponse.json({ exception: 'moodle_exception', errorcode: 'invalidtoken', message: 'bad token' })
      )
    );
    const tokenStore = new FakeTokenStore();
    await tokenStore.set('user-1', { token: 'revoked-tok', moodleUserId: '4821' });
    const app = makeApp(baseConfig(tokenStore));

    const firstRes = await request(app).get('/protected');
    expect(firstRes.status).toBe(500); // the route's own call() rejects; error propagates via next(err)
    expect(await tokenStore.get('user-1')).toBeNull();

    const secondRes = await request(app).get('/protected');
    expect(secondRes.status).toBe(401);
  });
});
