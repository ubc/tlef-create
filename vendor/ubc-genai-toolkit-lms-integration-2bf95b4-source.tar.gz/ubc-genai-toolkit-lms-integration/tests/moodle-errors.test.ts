import { describe, it, expect } from 'vitest';
import { MoodleApiError } from '../src/providers/moodle/errors';
import { LmsError } from '../src/core/errors';

describe('MoodleApiError', () => {
  it('carries the errorcode and extends LmsError with provider moodle', () => {
    const err = new MoodleApiError('Invalid token - token not found', 'invalidtoken');
    expect(err).toBeInstanceOf(LmsError);
    expect(err.name).toBe('MoodleApiError');
    expect(err.provider).toBe('moodle');
    expect(err.errorcode).toBe('invalidtoken');
  });

  it('allows an undefined errorcode', () => {
    const err = new MoodleApiError('something failed');
    expect(err.errorcode).toBeUndefined();
  });
});
