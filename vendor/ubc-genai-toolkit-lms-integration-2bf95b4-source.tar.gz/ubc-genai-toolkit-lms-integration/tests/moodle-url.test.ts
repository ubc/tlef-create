import { describe, it, expect } from 'vitest';
import { baseUrl } from '../src/providers/moodle/moodle-url';

describe('baseUrl', () => {
  it('defaults a bare domain to https', () => {
    expect(baseUrl('moodle.example.ubc.ca')).toBe('https://moodle.example.ubc.ca');
  });

  it('keeps an explicit http:// scheme for local/dev Moodle instances', () => {
    expect(baseUrl('http://localhost:8090')).toBe('http://localhost:8090');
  });

  it('strips a trailing slash', () => {
    expect(baseUrl('http://localhost:8090/')).toBe('http://localhost:8090');
  });
});
