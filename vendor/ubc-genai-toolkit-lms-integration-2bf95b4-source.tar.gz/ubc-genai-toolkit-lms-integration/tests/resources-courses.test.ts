import { describe, it, expect, beforeAll, afterEach, afterAll } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createApiClient } from '../src/providers/canvas/api-client';
import { getCourses, getCourseSections } from '../src/providers/canvas/resources/courses';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

function makeClient() {
  return createApiClient({ canvasDomain: 'ubc.instructure.com', accessToken: 'token-1' });
}

describe('getCourses', () => {
  it('fetches /api/v1/courses and returns the normalized list', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', () =>
        HttpResponse.json([
          { id: 1, name: 'Math', course_code: 'MATH100' },
          { id: 2, name: 'Chemistry', course_code: 'CHEM101' },
        ])
      )
    );

    const courses = await getCourses(makeClient());
    expect(courses).toEqual([
      {
        id: '1',
        name: 'Math',
        code: 'MATH100',
        raw: { id: 1, name: 'Math', course_code: 'MATH100' },
      },
      {
        id: '2',
        name: 'Chemistry',
        code: 'CHEM101',
        raw: { id: 2, name: 'Chemistry', course_code: 'CHEM101' },
      },
    ]);
  });

  it('passes query params through, e.g. filtering to taught courses', async () => {
    let search = '';
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', ({ request }) => {
        search = new URL(request.url).search;
        return HttpResponse.json([]);
      })
    );

    await getCourses(makeClient(), { enrollment_type: 'teacher' });
    expect(search).toContain('enrollment_type=teacher');
  });
});

describe('getCourseSections', () => {
  it('fetches /api/v1/courses/:id/sections and returns the normalized list', async () => {
    let path = '';
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/2/sections', ({ request }) => {
        path = new URL(request.url).pathname;
        return HttpResponse.json([
          { id: 10, name: 'CHEM 101-001', course_id: 2 },
          { id: 11, name: 'CHEM 101-002', course_id: 2 },
        ]);
      })
    );

    const sections = await getCourseSections(makeClient(), 2);
    expect(path).toBe('/api/v1/courses/2/sections');
    expect(sections).toEqual([
      {
        id: '10',
        name: 'CHEM 101-001',
        courseId: '2',
        raw: { id: 10, name: 'CHEM 101-001', course_id: 2 },
      },
      {
        id: '11',
        name: 'CHEM 101-002',
        courseId: '2',
        raw: { id: 11, name: 'CHEM 101-002', course_id: 2 },
      },
    ]);
  });

  it('accepts a string course id (e.g. a getCourses result\'s .id) without a cast', async () => {
    let path = '';
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/2/sections', ({ request }) => {
        path = new URL(request.url).pathname;
        return HttpResponse.json([
          { id: 10, name: 'CHEM 101-001', course_id: 2 },
          { id: 11, name: 'CHEM 101-002', course_id: 2 },
        ]);
      })
    );

    const sections = await getCourseSections(makeClient(), '2');
    expect(path).toBe('/api/v1/courses/2/sections');
    expect(sections).toEqual([
      {
        id: '10',
        name: 'CHEM 101-001',
        courseId: '2',
        raw: { id: 10, name: 'CHEM 101-001', course_id: 2 },
      },
      {
        id: '11',
        name: 'CHEM 101-002',
        courseId: '2',
        raw: { id: 11, name: 'CHEM 101-002', course_id: 2 },
      },
    ]);
  });

  it('preserves Canvas-only fields like sis_section_id on .raw', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/1/sections', () =>
        HttpResponse.json([{ id: 5, name: 'Math', course_id: 1, sis_section_id: 'MATH100-001' }])
      )
    );

    const sections = await getCourseSections(makeClient(), 1);
    expect(sections).toHaveLength(1);
    expect(sections[0].raw).toMatchObject({ sis_section_id: 'MATH100-001' });
  });
});
