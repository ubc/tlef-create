import { describe, expect, it } from 'vitest';
import { matchRosterByIntegrationId } from '../src/core/roster';
import type { LmsRosterUser } from '../src/core/types';

function student(id: number, integrationId?: string, name = `Student ${id}`): LmsRosterUser {
  return { id: String(id), name, integrationId, raw: {} };
}

describe('matchRosterByIntegrationId', () => {
  it('pairs application keys with roster entries and stamps the course', () => {
    const report = matchRosterByIntegrationId(
      7,
      [student(2, 'PUID-0001', 'Ada Lovelace'), student(3, 'PUID-0002')],
      ['PUID-0001', 'PUID-0002']
    );

    expect(report.courseId).toBe('7');
    expect(report.matched).toEqual([
      { key: 'PUID-0001', lmsUserId: '2', name: 'Ada Lovelace', matchedBy: 'integrationId' },
      { key: 'PUID-0002', lmsUserId: '3', name: 'Student 3', matchedBy: 'integrationId' },
    ]);
    expect(report.appOnly).toEqual([]);
    expect(report.rosterOnly).toEqual([]);
  });

  it('reports application users with no roster entry as unexplained, not as errors', () => {
    const report = matchRosterByIntegrationId(7, [student(2, 'PUID-0001')], ['PUID-0001', 'PUID-0404']);

    expect(report.matched).toHaveLength(1);
    expect(report.appOnly).toEqual([{ key: 'PUID-0404', reason: 'unknown' }]);
  });

  it('reports roster students with no application account separately', () => {
    const report = matchRosterByIntegrationId(
      7,
      [student(2, 'PUID-0001'), student(3, 'PUID-0002', 'Grace Hopper')],
      ['PUID-0001']
    );

    expect(report.rosterOnly).toEqual([{ lmsUserId: '3', name: 'Grace Hopper', key: 'PUID-0002' }]);
    expect(report.appOnly).toEqual([]);
  });

  it('matches case-insensitively, since the two systems can disagree on casing alone', () => {
    const report = matchRosterByIntegrationId(7, [student(2, 'puid-0001')], ['PUID-0001']);

    expect(report.matched).toEqual([
      expect.objectContaining({ key: 'PUID-0001', lmsUserId: '2' }),
    ]);
  });

  it('matches nothing when two Canvas accounts claim the same key', () => {
    const report = matchRosterByIntegrationId(
      7,
      [student(2, 'PUID-0001'), student(3, 'PUID-0001')],
      ['PUID-0001']
    );

    expect(report.matched).toEqual([]);
    expect(report.appOnly).toEqual([]);
    expect(report.ambiguous).toEqual([
      { key: 'PUID-0001', lmsUserIds: ['2', '3'], appKeys: ['PUID-0001'] },
    ]);
  });

  it('matches nothing when two application keys fold to the same value', () => {
    const report = matchRosterByIntegrationId(7, [student(2, 'PUID-0001')], ['PUID-0001', 'puid-0001']);

    expect(report.matched).toEqual([]);
    expect(report.ambiguous).toEqual([
      { key: 'PUID-0001', lmsUserIds: ['2'], appKeys: ['PUID-0001', 'puid-0001'] },
    ]);
  });

  it('treats a repeated identical key as one person when given no account ids', () => {
    const report = matchRosterByIntegrationId(7, [student(2, 'PUID-0001')], ['PUID-0001', 'PUID-0001']);

    expect(report.ambiguous).toEqual([]);
    expect(report.matched).toHaveLength(1);
  });

  it('matches nothing when two application accounts hold the same key', () => {
    const report = matchRosterByIntegrationId(
      7,
      [student(2, 'PUID-0001')],
      [
        { appUserId: 'user-a', key: 'PUID-0001' },
        { appUserId: 'user-b', key: 'PUID-0001' },
      ]
    );

    expect(report.matched).toEqual([]);
    expect(report.ambiguous).toEqual([
      {
        key: 'PUID-0001',
        lmsUserIds: ['2'],
        appKeys: ['PUID-0001'],
        appUserIds: ['user-a', 'user-b'],
      },
    ]);
  });

  it('still treats one account listed twice as one person', () => {
    const report = matchRosterByIntegrationId(
      7,
      [student(2, 'PUID-0001')],
      [
        { appUserId: 'user-a', key: 'PUID-0001' },
        { appUserId: 'user-a', key: 'PUID-0001' },
      ]
    );

    expect(report.ambiguous).toEqual([]);
    expect(report.matched).toEqual([
      {
        key: 'PUID-0001',
        appUserId: 'user-a',
        lmsUserId: '2',
        name: 'Student 2',
        matchedBy: 'integrationId',
      },
    ]);
  });

  it('carries the account id through to an unmatched entry', () => {
    const report = matchRosterByIntegrationId(
      7,
      [student(2, 'PUID-0001')],
      [{ appUserId: 'user-z', key: 'PUID-0404' }]
    );

    expect(report.appOnly).toEqual([
      { key: 'PUID-0404', appUserId: 'user-z', reason: 'unknown' },
    ]);
  });

  it('ignores blank keys on both sides rather than matching them to each other', () => {
    const report = matchRosterByIntegrationId(
      7,
      [student(2, '   '), student(3, undefined)],
      ['', '   ']
    );

    expect(report.matched).toEqual([]);
    expect(report.ambiguous).toEqual([]);
    expect(report.appOnly).toEqual([]);
    expect(report.rosterOnly).toHaveLength(2);
  });

  it('carries coverage so a permissions failure is distinguishable from an unmatched class', () => {
    const report = matchRosterByIntegrationId(
      7,
      [student(2, undefined), student(3, undefined)],
      ['PUID-0001', 'PUID-0002']
    );

    expect(report.coverage).toMatchObject({ total: 2, integrationId: 0 });
    expect(report.appOnly).toHaveLength(2);
  });

  it('keeps matched, appOnly and ambiguous disjoint so a UI cannot double-count anyone', () => {
    const report = matchRosterByIntegrationId(
      7,
      [student(2, 'PUID-0001'), student(3, 'PUID-0002'), student(4, 'PUID-0002')],
      ['PUID-0001', 'PUID-0002', 'PUID-0404']
    );

    const counted = [
      ...report.matched.map((match) => match.key),
      ...report.appOnly.map((entry) => entry.key),
      ...report.ambiguous.flatMap((entry) => entry.appKeys),
    ];
    expect(counted.sort()).toEqual(['PUID-0001', 'PUID-0002', 'PUID-0404']);
  });
});
