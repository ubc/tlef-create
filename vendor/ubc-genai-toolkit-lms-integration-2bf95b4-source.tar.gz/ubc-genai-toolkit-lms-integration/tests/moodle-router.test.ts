import { describe, it, expect, beforeAll, afterEach, afterAll } from 'vitest';
import express from 'express';
import request from 'supertest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createAuthRouter } from '../src/providers/moodle/router';
import type { Config, Tokens } from '../src/providers/moodle/types';
import type { TokenStore } from '../src/core/types';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'bypass' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const REST_URL = 'https://moodle.example.ubc.ca/webservice/rest/server.php';

class FakeTokenStore implements TokenStore<Tokens> {
  private store = new Map<string, Tokens>();
  async get(userKey: string) {
    return this.store.get(userKey) ?? null;
  }
  async set(userKey: string, tokens: Tokens) {
    this.store.set(userKey, tokens);
  }
  async delete(userKey: string) {
    this.store.delete(userKey);
  }
}

function makeApp(config: Config) {
  const app = express();
  app.use(express.json());
  app.use('/moodle/auth', createAuthRouter(config));
  return app;
}

function baseConfig(tokenStore: TokenStore<Tokens>, overrides: Partial<Config> = {}): Config {
  return {
    moodleDomain: 'moodle.example.ubc.ca',
    tokenStore,
    getUserKey: () => 'user-1',
    ...overrides,
  };
}

describe('createAuthRouter', () => {
  it('validates the token, stores it, and returns site info on /connect', async () => {
    server.use(
      http.post(REST_URL, () => HttpResponse.json({ sitename: 'UBC Moodle', username: 'jsmith', userid: 4821 }))
    );
    const tokenStore = new FakeTokenStore();
    const app = makeApp(baseConfig(tokenStore));

    const res = await request(app).post('/moodle/auth/connect').send({ token: 'tok-1' });

    expect(res.status).toBe(200);
    expect(res.body).toEqual({ success: true, sitename: 'UBC Moodle', username: 'jsmith' });
    const stored = await tokenStore.get('user-1');
    expect(stored).toEqual({ token: 'tok-1', moodleUserId: '4821' });
  });

  it('responds 400 without calling Moodle when token is missing from the body', async () => {
    const app = makeApp(baseConfig(new FakeTokenStore()));
    const res = await request(app).post('/moodle/auth/connect').send({});
    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
  });

  it('responds 400 with a friendly message when Moodle rejects the token', async () => {
    server.use(
      http.post(REST_URL, () =>
        HttpResponse.json({ exception: 'moodle_exception', errorcode: 'invalidtoken', message: 'Invalid token - token not found' })
      )
    );
    const app = makeApp(baseConfig(new FakeTokenStore()));

    const res = await request(app).post('/moodle/auth/connect').send({ token: 'bad-token' });
    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toBe(
      "That token isn't valid — check you copied the whole key from Moodle's Security keys page."
    );
  });

  it('responds 400 with a distinct message when Moodle rejects the token for a non-invalidtoken reason', async () => {
    server.use(
      http.post(REST_URL, () =>
        HttpResponse.json({ exception: 'moodle_exception', errorcode: 'accessexception', message: 'Access control exception' })
      )
    );
    const app = makeApp(baseConfig(new FakeTokenStore()));

    const res = await request(app).post('/moodle/auth/connect').send({ token: 'tok-1' });
    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toBe(
      "Your Moodle site rejected this request — ask your Moodle admin to check the web service configuration (REST protocol enabled, required functions whitelisted)."
    );
  });

  it('supports an async getUserKey', async () => {
    server.use(
      http.post(REST_URL, () => HttpResponse.json({ sitename: 'UBC Moodle', username: 'jsmith', userid: 4821 }))
    );
    const tokenStore = new FakeTokenStore();
    const getUserKey = async (): Promise<string> => {
      await new Promise((resolve) => setTimeout(resolve, 0));
      return 'async-resolved-user';
    };
    const app = makeApp(baseConfig(tokenStore, { getUserKey }));

    await request(app).post('/moodle/auth/connect').send({ token: 'tok-1' });

    expect(await tokenStore.get('async-resolved-user')).not.toBeNull();
    expect(await tokenStore.get('user-1')).toBeNull();
  });

  it('deletes the stored token on /disconnect', async () => {
    const tokenStore = new FakeTokenStore();
    await tokenStore.set('user-1', { token: 'tok-1', moodleUserId: '4821' });
    const app = makeApp(baseConfig(tokenStore));

    const res = await request(app).post('/moodle/auth/disconnect');
    expect(res.status).toBe(204);
    expect(await tokenStore.get('user-1')).toBeNull();
  });

  it('/disconnect is a no-op when the user has no stored token', async () => {
    const app = makeApp(baseConfig(new FakeTokenStore()));
    const res = await request(app).post('/moodle/auth/disconnect');
    expect(res.status).toBe(204);
  });
});
