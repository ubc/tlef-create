import { afterAll, afterEach, beforeAll, describe, expect, it } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createApiClient } from '../src/providers/moodle/api-client';
import { getGradeItems, getGrades } from '../src/providers/moodle/resources/grades';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const REST_URL = 'https://moodle.example.ubc.ca/webservice/rest/server.php';
const client = () => createApiClient({ moodleDomain: 'moodle.example.ubc.ca', token: 'tok-1', userId: '42' });

const gradeResponse = {
  usergrades: [
    {
      courseid: 55,
      userid: 9,
      gradeitems: [
        { id: 1, itemname: 'Course total', itemtype: 'course', graderaw: 88, gradeformatted: '88.00' },
        { id: 2, itemname: 'Lab 1', itemtype: 'mod', graderaw: 18, gradeformatted: '18.00', grademax: 20 },
        { id: 3, itemname: 'Labs', itemtype: 'category', graderaw: 90, gradeformatted: '90.00' },
      ],
    },
  ],
  warnings: [],
};

describe('Moodle grades', () => {
  it('normalizes and deduplicates gradebook items', async () => {
    let params = new URLSearchParams();
    server.use(
      http.post(REST_URL, async ({ request }) => {
        params = new URLSearchParams(await request.text());
        return HttpResponse.json(gradeResponse);
      })
    );
    await expect(getGradeItems(client(), 55)).resolves.toEqual([
      expect.objectContaining({ id: '2', courseId: '55', name: 'Lab 1', maxScore: 20 }),
    ]);
    expect(params.get('wsfunction')).toBe('gradereport_user_get_grade_items');
    expect(params.get('userid')).toBe('0');
  });

  it('returns course totals and grade-item scores but not category rollups', async () => {
    server.use(http.post(REST_URL, () => HttpResponse.json(gradeResponse)));
    const grades = await getGrades(client(), { courseId: 55, userIds: [9] });
    expect(grades).toHaveLength(2);
    expect(grades[0]).toMatchObject({ userId: '9', score: 88, gradeItemId: undefined });
    expect(grades[1]).toMatchObject({ userId: '9', score: 18, gradeItemId: '2', maxScore: 20 });
  });
});
