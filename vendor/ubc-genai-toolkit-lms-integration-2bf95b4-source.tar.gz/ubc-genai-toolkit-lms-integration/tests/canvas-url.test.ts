import { describe, it, expect } from 'vitest';
import { baseUrl } from '../src/providers/canvas/canvas-url';

describe('baseUrl', () => {
  it('defaults a bare domain to https', () => {
    expect(baseUrl('ubc.instructure.com')).toBe('https://ubc.instructure.com');
  });

  it('keeps an explicit https:// scheme as-is', () => {
    expect(baseUrl('https://ubc.instructure.com')).toBe('https://ubc.instructure.com');
  });

  it('keeps an explicit http:// scheme for local/dev Canvas instances', () => {
    expect(baseUrl('http://localhost:9100')).toBe('http://localhost:9100');
  });

  it('strips a trailing slash', () => {
    expect(baseUrl('http://localhost:9100/')).toBe('http://localhost:9100');
    expect(baseUrl('ubc.instructure.com/')).toBe('https://ubc.instructure.com');
  });
});
