import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { loadConfigFromEnv } from '../src/providers/moodle/env-config';

const originalEnv: Record<string, string | undefined> = {};

beforeEach(() => {
  originalEnv.MOODLE_DOMAIN = process.env.MOODLE_DOMAIN;
});

afterEach(() => {
  if (originalEnv.MOODLE_DOMAIN === undefined) delete process.env.MOODLE_DOMAIN;
  else process.env.MOODLE_DOMAIN = originalEnv.MOODLE_DOMAIN;
});

describe('loadConfigFromEnv', () => {
  it('builds a config from process.env merged with the provided overrides', () => {
    process.env.MOODLE_DOMAIN = 'moodle.example.ubc.ca';
    const tokenStore = { get: async () => null, set: async () => {}, delete: async () => {} };
    const getUserKey = () => 'user-1';

    const config = loadConfigFromEnv({ tokenStore, getUserKey });

    expect(config).toEqual({
      moodleDomain: 'moodle.example.ubc.ca',
      tokenStore,
      getUserKey,
    });
  });

  it('throws naming MOODLE_DOMAIN when it is unset', () => {
    delete process.env.MOODLE_DOMAIN;

    expect(() =>
      loadConfigFromEnv({ tokenStore: {} as never, getUserKey: () => 'x' })
    ).toThrowError(/MOODLE_DOMAIN/);
  });
});
