import { describe, expect, it } from 'vitest';
import { rosterFieldCoverage } from '../src/core/roster';
import type { LmsRosterUser } from '../src/core/types';

const user = (overrides: Partial<LmsRosterUser> = {}): LmsRosterUser => ({
  id: '1',
  name: 'Student',
  raw: {},
  ...overrides,
});

describe('rosterFieldCoverage', () => {
  it('counts how many entries carried each identity field', () => {
    expect(
      rosterFieldCoverage([
        user({ integrationId: 'PUID-1', sisId: '1', email: 'a@ubc.ca', loginId: 'a' }),
        user({ integrationId: 'PUID-2', email: 'b@ubc.ca' }),
        user({ email: 'c@ubc.ca' }),
      ])
    ).toEqual({ total: 3, integrationId: 2, sisId: 1, email: 3, loginId: 1 });
  });

  it('reports zero coverage for a roster whose identity fields were all withheld', () => {
    expect(rosterFieldCoverage([user(), user()])).toEqual({
      total: 2,
      integrationId: 0,
      sisId: 0,
      email: 0,
      loginId: 0,
    });
  });

  it('does not count empty strings as coverage', () => {
    expect(rosterFieldCoverage([user({ integrationId: '', email: '' })])).toMatchObject({
      total: 1,
      integrationId: 0,
      email: 0,
    });
  });

  it('reports an empty roster without dividing by zero', () => {
    expect(rosterFieldCoverage([])).toEqual({
      total: 0,
      integrationId: 0,
      sisId: 0,
      email: 0,
      loginId: 0,
    });
  });
});
