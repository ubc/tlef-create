import { afterAll, afterEach, beforeAll, describe, expect, it } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createApiClient } from '../src/providers/canvas/api-client';
import {
  postGrades,
  preflightGradeExport,
  resolveGradeWrites,
  waitForProgress,
} from '../src/providers/canvas/resources/grades';
import { CanvasGradeExportError } from '../src/providers/canvas/errors';
import { matchRosterByIntegrationId } from '../src/core/roster';
import type { LmsRosterUser } from '../src/core/types';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const client = () => createApiClient({ canvasDomain: 'ubc.instructure.com', accessToken: 'token-1' });
const ASSIGNMENT_URL = 'https://ubc.instructure.com/api/v1/courses/7/assignments/8';
const UPDATE_GRADES_URL = `${ASSIGNMENT_URL}/submissions/update_grades`;

function student(id: number, integrationId?: string): LmsRosterUser {
  return { id: String(id), name: `Student ${id}`, integrationId, raw: {} };
}

const report = (courseId: string | number = 7) =>
  matchRosterByIntegrationId(
    courseId,
    [student(2, 'PUID-0001'), student(3, 'PUID-0002')],
    ['PUID-0001', 'PUID-0002']
  );

describe('resolveGradeWrites', () => {
  it('translates application keys into Canvas user ids and keeps the course stamp', () => {
    const batch = resolveGradeWrites(report(), 8, [
      { key: 'PUID-0001', postedGrade: 85, comment: 'Nice work' },
      { key: 'PUID-0002', postedGrade: '72%' },
    ]);

    expect(batch.courseId).toBe('7');
    expect(batch.writes).toEqual([
      { userId: '2', postedGrade: 85, comment: 'Nice work', excuse: undefined },
      { userId: '3', postedGrade: '72%', comment: undefined, excuse: undefined },
    ]);
    expect(batch.unresolved).toEqual([]);
  });

  it('sets aside grades whose student is not on the roster', () => {
    const batch = resolveGradeWrites(report(), 8, [
      { key: 'PUID-0001', postedGrade: 85 },
      { key: 'PUID-0404', postedGrade: 91 },
    ]);

    expect(batch.writes).toHaveLength(1);
    expect(batch.unresolved).toEqual([{ key: 'PUID-0404', reason: 'no-roster-match' }]);
  });

  it('writes neither row when the application supplies two grades for one student', () => {
    const batch = resolveGradeWrites(report(), 8, [
      { key: 'PUID-0001', postedGrade: 85 },
      { key: 'PUID-0001', postedGrade: 40 },
    ]);

    expect(batch.writes).toEqual([]);
    expect(batch.unresolved).toEqual([
      { key: 'PUID-0001', reason: 'duplicate-key' },
      { key: 'PUID-0001', reason: 'duplicate-key' },
    ]);
  });

  it('sets aside grades for a key two Canvas accounts claim', () => {
    const ambiguousReport = matchRosterByIntegrationId(
      7,
      [student(2, 'PUID-0001'), student(4, 'PUID-0001')],
      ['PUID-0001']
    );
    const batch = resolveGradeWrites(ambiguousReport, 8, [{ key: 'PUID-0001', postedGrade: 85 }]);

    expect(batch.writes).toEqual([]);
    expect(batch.unresolved).toEqual([{ key: 'PUID-0001', reason: 'ambiguous-key' }]);
  });

  it('refuses outright when the roster exposed no integration_id at all', () => {
    const blindReport = matchRosterByIntegrationId(
      7,
      [student(2, undefined), student(3, undefined)],
      ['PUID-0001']
    );

    expect(() => resolveGradeWrites(blindReport, 8, [{ key: 'PUID-0001', postedGrade: 85 }])).toThrow(
      CanvasGradeExportError
    );
    try {
      resolveGradeWrites(blindReport, 8, [{ key: 'PUID-0001', postedGrade: 85 }]);
    } catch (err) {
      expect((err as CanvasGradeExportError).reason).toBe('roster-coverage');
    }
  });

  it('does not refuse an empty course, where zero coverage means nothing', () => {
    const emptyReport = matchRosterByIntegrationId(7, [], ['PUID-0001']);
    expect(() => resolveGradeWrites(emptyReport, 8, [{ key: 'PUID-0001', postedGrade: 85 }])).not.toThrow();
  });

  it('refuses a grade row that contains no operation', () => {
    expect(() => resolveGradeWrites(report(), 8, [{ key: 'PUID-0001' }])).toThrowError(
      expect.objectContaining({ reason: 'invalid-grade' })
    );
  });

  it.each([Number.NaN, Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY])(
    'refuses a non-finite numeric grade (%s)',
    (postedGrade) => {
      expect(() =>
        resolveGradeWrites(report(), 8, [{ key: 'PUID-0001', postedGrade }])
      ).toThrowError(expect.objectContaining({ reason: 'invalid-grade' }));
    }
  );
});

describe('postGrades', () => {
  function assignmentHandler(overrides: Record<string, unknown> = {}) {
    return http.get(ASSIGNMENT_URL, () =>
      HttpResponse.json({ id: 8, name: 'Lab 1', points_possible: 100, ...overrides })
    );
  }

  it('sends one grade_data request and reports the queued job', async () => {
    let body: Record<string, unknown> = {};
    server.use(
      assignmentHandler(),
      http.post(UPDATE_GRADES_URL, async ({ request }) => {
        body = (await request.json()) as Record<string, unknown>;
        return HttpResponse.json({ id: 99, workflow_state: 'queued', completion: 0 });
      })
    );

    const batch = resolveGradeWrites(report(), 8, [
      { key: 'PUID-0001', postedGrade: 85, comment: 'Nice work' },
      { key: 'PUID-0002', excuse: true },
    ]);
    const result = await postGrades(client(), { courseId: 7, gradeItemId: 8, batch });

    expect(body).toEqual({
      grade_data: {
        '2': { posted_grade: 85, text_comment: 'Nice work' },
        '3': { excuse: true },
      },
    });
    expect(result).toMatchObject({ progressId: '99', workflowState: 'queued', postManually: false });
  });

  it('reports the posting policy, so nobody has to guess whether students can see it', async () => {
    server.use(
      assignmentHandler({ post_manually: true }),
      http.post(UPDATE_GRADES_URL, () => HttpResponse.json({ id: 99, workflow_state: 'queued' }))
    );

    const batch = resolveGradeWrites(report(), 8, [{ key: 'PUID-0001', postedGrade: 85 }]);
    const result = await postGrades(client(), { courseId: 7, gradeItemId: 8, batch });
    expect(result.postManually).toBe(true);
  });

  it('refuses a batch matched against a different course', async () => {
    const batch = resolveGradeWrites(report(9), 8, [{ key: 'PUID-0001', postedGrade: 85 }]);

    await expect(postGrades(client(), { courseId: 7, gradeItemId: 8, batch })).rejects.toMatchObject({
      name: 'CanvasGradeExportError',
      reason: 'course-mismatch',
    });
  });

  it('refuses an empty batch rather than letting Canvas report success on nothing', async () => {
    const batch = resolveGradeWrites(report(), 8, [{ key: 'PUID-0404', postedGrade: 85 }]);

    await expect(postGrades(client(), { courseId: 7, gradeItemId: 8, batch })).rejects.toMatchObject({
      reason: 'empty-batch',
    });
  });

  it('revalidates structural batch writes before any Canvas request', async () => {
    const batch = resolveGradeWrites(report(), 8, [{ key: 'PUID-0001', postedGrade: 85 }]);
    batch.writes = [{ userId: '2' }];

    await expect(
      postGrades(client(), { courseId: 7, gradeItemId: 8, batch })
    ).rejects.toMatchObject({ reason: 'invalid-grade' });
  });

  it('refuses an anonymously graded assignment, which Canvas cannot address by user id', async () => {
    server.use(assignmentHandler({ anonymous_grading: true }));

    const batch = resolveGradeWrites(report(), 8, [{ key: 'PUID-0001', postedGrade: 85 }]);
    await expect(postGrades(client(), { courseId: 7, gradeItemId: 8, batch })).rejects.toMatchObject({
      reason: 'unsupported-grading',
    });
  });

  it('refuses a batch computed for a different assignment in the same course', async () => {
    const batch = resolveGradeWrites(report(), 8, [{ key: 'PUID-0001', postedGrade: 85 }]);

    await expect(
      postGrades(client(), { courseId: 7, gradeItemId: 9, batch })
    ).rejects.toMatchObject({ reason: 'assignment-mismatch' });
  });

  it('refuses a partial export unless the caller asks for one', async () => {
    server.use(
      assignmentHandler(),
      http.post(UPDATE_GRADES_URL, () => HttpResponse.json({ id: 99, workflow_state: 'queued' }))
    );

    const batch = resolveGradeWrites(report(), 8, [
      { key: 'PUID-0001', postedGrade: 85 },
      { key: 'PUID-0404', postedGrade: 91 },
    ]);

    await expect(postGrades(client(), { courseId: 7, gradeItemId: 8, batch })).rejects.toMatchObject({
      reason: 'partial-export',
    });

    const result = await postGrades(client(), {
      courseId: 7,
      gradeItemId: 8,
      batch,
      allowPartial: true,
    });
    expect(result.progressId).toBe('99');
  });

  it('will not let a permissive preflight carry allowPartial into a write that did not ask', async () => {
    server.use(
      assignmentHandler(),
      http.post(UPDATE_GRADES_URL, () => HttpResponse.json({ id: 99, workflow_state: 'queued' }))
    );

    const batch = resolveGradeWrites(report(), 8, [
      { key: 'PUID-0001', postedGrade: 85 },
      { key: 'PUID-0404', postedGrade: 91 },
    ]);
    const preflight = await preflightGradeExport(client(), {
      courseId: 7,
      gradeItemId: 8,
      batch,
      allowPartial: true,
    });

    await expect(
      postGrades(client(), { courseId: 7, gradeItemId: 8, batch, preflight })
    ).rejects.toMatchObject({ reason: 'partial-export' });
  });

  it('revalidates a matching preflight immediately before writing', async () => {
    let assignmentReads = 0;
    server.use(
      http.get(ASSIGNMENT_URL, () => {
        assignmentReads += 1;
        return HttpResponse.json({ id: 8, name: 'Lab 1', post_manually: true });
      }),
      http.post(UPDATE_GRADES_URL, () => HttpResponse.json({ id: 99, workflow_state: 'queued' }))
    );

    const batch = resolveGradeWrites(report(), 8, [{ key: 'PUID-0001', postedGrade: 85 }]);
    const preflight = await preflightGradeExport(client(), { courseId: 7, gradeItemId: 8, batch });
    const result = await postGrades(client(), { courseId: 7, gradeItemId: 8, batch, preflight });

    expect(assignmentReads).toBe(2);
    expect(result.postManually).toBe(true);
  });

  it('refuses when the posting policy changed after instructor review', async () => {
    let assignmentReads = 0;
    server.use(
      http.get(ASSIGNMENT_URL, () => {
        assignmentReads += 1;
        return HttpResponse.json({
          id: 8,
          name: 'Lab 1',
          post_manually: assignmentReads === 1,
        });
      })
    );

    const batch = resolveGradeWrites(report(), 8, [{ key: 'PUID-0001', comment: 'Feedback' }]);
    const preflight = await preflightGradeExport(client(), { courseId: 7, gradeItemId: 8, batch });

    await expect(
      postGrades(client(), { courseId: 7, gradeItemId: 8, batch, preflight })
    ).rejects.toMatchObject({ reason: 'preflight-stale' });
  });

  it('does not let a supplied preflight bypass current moderated grading', async () => {
    server.use(assignmentHandler({ moderated_grading: true }));
    const batch = resolveGradeWrites(report(), 8, [{ key: 'PUID-0001', postedGrade: 85 }]);
    const supplied = {
      courseId: '7',
      gradeItemId: '8',
      postManually: false,
      assignmentName: 'Lab 1',
      raw: {},
    };

    await expect(
      postGrades(client(), { courseId: 7, gradeItemId: 8, batch, preflight: supplied })
    ).rejects.toMatchObject({ reason: 'unsupported-grading' });
  });
});

describe('preflightGradeExport', () => {
  it('reports the posting policy before anything is written', async () => {
    let writes = 0;
    server.use(
      http.get(ASSIGNMENT_URL, () =>
        HttpResponse.json({
          id: 8,
          name: 'Lab 1',
          points_possible: 100,
          grading_type: 'points',
          post_manually: false,
        })
      ),
      http.post(UPDATE_GRADES_URL, () => {
        writes += 1;
        return HttpResponse.json({ id: 99, workflow_state: 'queued' });
      })
    );

    const batch = resolveGradeWrites(report(), 8, [{ key: 'PUID-0001', postedGrade: 85 }]);
    const preflight = await preflightGradeExport(client(), { courseId: 7, gradeItemId: 8, batch });

    expect(preflight).toMatchObject({
      courseId: '7',
      gradeItemId: '8',
      postManually: false,
      maxScore: 100,
      gradingType: 'points',
      assignmentName: 'Lab 1',
    });
    expect(writes).toBe(0);
  });

  it('applies the same refusals as the write itself', async () => {
    const batch = resolveGradeWrites(report(9), 8, [{ key: 'PUID-0001', postedGrade: 85 }]);

    await expect(
      preflightGradeExport(client(), { courseId: 7, gradeItemId: 8, batch })
    ).rejects.toMatchObject({ reason: 'course-mismatch' });
  });
});

describe('waitForProgress', () => {
  it('polls until Canvas finishes applying the batch', async () => {
    const states = ['queued', 'running', 'completed'];
    let call = 0;
    server.use(
      http.get('https://ubc.instructure.com/api/v1/progress/99', () =>
        HttpResponse.json({ id: 99, workflow_state: states[call++] ?? 'completed', completion: 100 })
      )
    );

    const result = await waitForProgress(client(), '99', { pollIntervalMs: 1, timeoutMs: 5_000 });
    expect(result).toMatchObject({ progressId: '99', workflowState: 'completed' });
    expect(call).toBe(3);
  });

  it('returns a failed job instead of throwing, because the failure list is the point', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/progress/99', () =>
        HttpResponse.json({ id: 99, workflow_state: 'failed', message: 'invalid grade for user 3' })
      )
    );

    const result = await waitForProgress(client(), '99', { pollIntervalMs: 1 });
    expect(result).toMatchObject({ workflowState: 'failed', message: 'invalid grade for user 3' });
  });

  it('gives up on a job that never finishes', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/progress/99', () =>
        HttpResponse.json({ id: 99, workflow_state: 'running' })
      )
    );

    await expect(
      waitForProgress(client(), '99', { pollIntervalMs: 1, timeoutMs: 10 })
    ).rejects.toThrow(/still running/);
  });

  it('treats a state it does not recognize as unfinished rather than as success', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/progress/99', () =>
        HttpResponse.json({ id: 99, workflow_state: 'something_new' })
      )
    );

    await expect(
      waitForProgress(client(), '99', { pollIntervalMs: 1, timeoutMs: 10 })
    ).rejects.toThrow(/still queued/);
  });
});
