import { describe, it, expect } from 'vitest';
import { normalizeBaseUrl } from '../src/core/http';

describe('normalizeBaseUrl', () => {
  it('defaults a bare domain to https', () => {
    expect(normalizeBaseUrl('ubc.instructure.com')).toBe('https://ubc.instructure.com');
  });

  it('keeps an explicit https:// scheme as-is', () => {
    expect(normalizeBaseUrl('https://ubc.instructure.com')).toBe('https://ubc.instructure.com');
  });

  it('keeps an explicit http:// scheme for local/dev instances', () => {
    expect(normalizeBaseUrl('http://localhost:9100')).toBe('http://localhost:9100');
  });

  it('strips a trailing slash', () => {
    expect(normalizeBaseUrl('http://localhost:9100/')).toBe('http://localhost:9100');
    expect(normalizeBaseUrl('ubc.instructure.com/')).toBe('https://ubc.instructure.com');
  });
});
