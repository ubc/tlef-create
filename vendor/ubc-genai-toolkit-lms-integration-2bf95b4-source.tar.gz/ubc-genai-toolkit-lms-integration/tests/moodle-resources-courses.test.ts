import { describe, it, expect, beforeAll, afterEach, afterAll } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createApiClient } from '../src/providers/moodle/api-client';
import { getCourses, getCourseSections } from '../src/providers/moodle/resources/courses';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const REST_URL = 'https://moodle.example.ubc.ca/webservice/rest/server.php';

function makeClient() {
  return createApiClient({ moodleDomain: 'moodle.example.ubc.ca', token: 'tok-1', userId: '4821' });
}

describe('getCourses', () => {
  it('calls core_enrol_get_users_courses with the client userId and returns the normalized list', async () => {
    let params = new URLSearchParams();
    server.use(
      http.post(REST_URL, async ({ request }) => {
        params = new URLSearchParams(await request.text());
        return HttpResponse.json([{ id: 55, shortname: 'CPSC310', fullname: 'Intro to Software Engineering' }]);
      })
    );

    const courses = await getCourses(makeClient());
    expect(params.get('wsfunction')).toBe('core_enrol_get_users_courses');
    expect(params.get('userid')).toBe('4821');
    expect(courses).toEqual([
      {
        id: '55',
        name: 'Intro to Software Engineering',
        code: 'CPSC310',
        raw: { id: 55, shortname: 'CPSC310', fullname: 'Intro to Software Engineering' },
      },
    ]);
  });
});

describe('getCourseSections', () => {
  it('calls core_group_get_course_groups with the given courseid and returns the normalized list', async () => {
    let params = new URLSearchParams();
    server.use(
      http.post(REST_URL, async ({ request }) => {
        params = new URLSearchParams(await request.text());
        return HttpResponse.json([{ id: 12, name: 'Section 001', courseid: 55 }]);
      })
    );

    const sections = await getCourseSections(makeClient(), 55);
    expect(params.get('wsfunction')).toBe('core_group_get_course_groups');
    expect(params.get('courseid')).toBe('55');
    expect(sections).toEqual([
      {
        id: '12',
        name: 'Section 001',
        courseId: '55',
        raw: { id: 12, name: 'Section 001', courseid: 55 },
      },
    ]);
  });

  it('accepts a string course id (e.g. a getCourses result\'s .id) without a cast', async () => {
    let params = new URLSearchParams();
    server.use(
      http.post(REST_URL, async ({ request }) => {
        params = new URLSearchParams(await request.text());
        return HttpResponse.json([{ id: 12, name: 'Section 001', courseid: 55 }]);
      })
    );

    const sections = await getCourseSections(makeClient(), '55');
    expect(params.get('wsfunction')).toBe('core_group_get_course_groups');
    expect(params.get('courseid')).toBe('55');
    expect(sections).toEqual([
      {
        id: '12',
        name: 'Section 001',
        courseId: '55',
        raw: { id: 12, name: 'Section 001', courseid: 55 },
      },
    ]);
  });

  it('returns an empty list for a course with no groups', async () => {
    server.use(http.post(REST_URL, () => HttpResponse.json([])));
    const sections = await getCourseSections(makeClient(), 99);
    expect(sections).toEqual([]);
  });
});
