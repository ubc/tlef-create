import { describe, it, expect, beforeAll, afterEach, afterAll, vi } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createApiClient } from '../src/providers/moodle/api-client';
import { MoodleApiError } from '../src/providers/moodle/errors';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const REST_URL = 'https://moodle.example.ubc.ca/webservice/rest/server.php';

function makeClient(overrides: Partial<Parameters<typeof createApiClient>[0]> = {}) {
  return createApiClient({ moodleDomain: 'moodle.example.ubc.ca', token: 'tok-1', userId: '42', ...overrides });
}

describe('createApiClient', () => {
  it('POSTs wstoken/wsfunction/moodlewsrestformat and returns the parsed body', async () => {
    let body = '';
    server.use(
      http.post(REST_URL, async ({ request }) => {
        body = await request.text();
        return HttpResponse.json([{ id: 1 }]);
      })
    );

    const result = await makeClient().call('core_enrol_get_users_courses', { userid: '42' });
    const params = new URLSearchParams(body);
    expect(params.get('wstoken')).toBe('tok-1');
    expect(params.get('wsfunction')).toBe('core_enrol_get_users_courses');
    expect(params.get('moodlewsrestformat')).toBe('json');
    expect(params.get('userid')).toBe('42');
    expect(result).toEqual([{ id: 1 }]);
  });

  it('serializes array params in PHP bracket-index form', async () => {
    let body = '';
    server.use(
      http.post(REST_URL, async ({ request }) => {
        body = await request.text();
        return HttpResponse.json([]);
      })
    );

    await makeClient().call('core_course_get_courses_by_field', { value: ['12', '34'] });
    const params = new URLSearchParams(body);
    expect(params.get('value[0]')).toBe('12');
    expect(params.get('value[1]')).toBe('34');
  });

  it('serializes nested object params in PHP bracket-key form', async () => {
    let body = '';
    server.use(
      http.post(REST_URL, async ({ request }) => {
        body = await request.text();
        return HttpResponse.json([]);
      })
    );

    await makeClient().call('core_group_add_members', { members: { groupid: 5, userids: ['1', '2'] } });
    const params = new URLSearchParams(body);
    expect(params.get('members[groupid]')).toBe('5');
    expect(params.get('members[userids][0]')).toBe('1');
    expect(params.get('members[userids][1]')).toBe('2');
  });

  it('throws MoodleApiError on a 200-status exception body', async () => {
    server.use(
      http.post(REST_URL, () =>
        HttpResponse.json({ exception: 'moodle_exception', errorcode: 'invalidtoken', message: 'Invalid token - token not found' })
      )
    );

    await expect(makeClient().call('core_webservice_get_site_info')).rejects.toMatchObject({
      name: 'MoodleApiError',
      errorcode: 'invalidtoken',
      message: 'Invalid token - token not found',
    });
  });

  it('invokes onInvalidToken when errorcode is invalidtoken', async () => {
    server.use(
      http.post(REST_URL, () =>
        HttpResponse.json({ exception: 'moodle_exception', errorcode: 'invalidtoken', message: 'bad token' })
      )
    );
    const onInvalidToken = vi.fn().mockResolvedValue(undefined);

    await expect(makeClient({ onInvalidToken }).call('core_enrol_get_users_courses')).rejects.toThrow();
    expect(onInvalidToken).toHaveBeenCalledTimes(1);
  });

  it('does not invoke onInvalidToken for a different errorcode', async () => {
    server.use(
      http.post(REST_URL, () =>
        HttpResponse.json({ exception: 'moodle_exception', errorcode: 'accessexception', message: 'not allowed' })
      )
    );
    const onInvalidToken = vi.fn().mockResolvedValue(undefined);

    await expect(makeClient({ onInvalidToken }).call('core_enrol_get_users_courses')).rejects.toThrow();
    expect(onInvalidToken).not.toHaveBeenCalled();
  });

  it('exposes the userId it was constructed with', () => {
    expect(makeClient({ userId: '99' }).userId).toBe('99');
  });

  it('serializes boolean params as 1/0, not "true"/"false"', async () => {
    let body = '';
    server.use(
      http.post(REST_URL, async ({ request }) => {
        body = await request.text();
        return HttpResponse.json([]);
      })
    );

    await makeClient().call('core_course_get_courses_by_field', { visible: true, hidden: false });
    const params = new URLSearchParams(body);
    expect(params.get('visible')).toBe('1');
    expect(params.get('hidden')).toBe('0');
  });

  it('does not let a caller-supplied wstoken param override the real token', async () => {
    let body = '';
    server.use(
      http.post(REST_URL, async ({ request }) => {
        body = await request.text();
        return HttpResponse.json([]);
      })
    );

    await makeClient().call('core_enrol_get_users_courses', { wstoken: 'attacker-supplied-token' });
    const params = new URLSearchParams(body);
    expect(params.get('wstoken')).toBe('tok-1');
  });

  it('throws MoodleApiError on a non-2xx HTTP status', async () => {
    server.use(http.post(REST_URL, () => new HttpResponse(null, { status: 500 })));

    await expect(makeClient().call('core_webservice_get_site_info')).rejects.toMatchObject({
      name: 'MoodleApiError',
    });
  });

  it('throws MoodleApiError on a non-JSON response body', async () => {
    server.use(
      http.post(REST_URL, () => new HttpResponse('<html>not json</html>', { status: 200, headers: { 'Content-Type': 'text/html' } }))
    );

    await expect(makeClient().call('core_webservice_get_site_info')).rejects.toMatchObject({
      name: 'MoodleApiError',
    });
  });
});
