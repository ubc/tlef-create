import { describe, it, expect, beforeAll, afterEach, afterAll } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import {
  buildAuthorizeUrl,
  exchangeCodeForTokens,
  refreshTokens,
  revokeToken,
} from '../src/providers/canvas/oauth-client';
import { CanvasOAuthError } from '../src/providers/canvas/errors';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const config = {
  canvasDomain: 'ubc.instructure.com',
  clientId: 'client-id',
  clientSecret: 'client-secret',
  redirectUri: 'http://localhost:8070/canvas/auth/callback',
};

describe('buildAuthorizeUrl', () => {
  it('builds the authorize URL with required params', () => {
    const url = new URL(buildAuthorizeUrl(config, { state: 'abc123' }));
    expect(url.origin + url.pathname).toBe('https://ubc.instructure.com/login/oauth2/auth');
    expect(url.searchParams.get('client_id')).toBe('client-id');
    expect(url.searchParams.get('response_type')).toBe('code');
    expect(url.searchParams.get('redirect_uri')).toBe(config.redirectUri);
    expect(url.searchParams.get('state')).toBe('abc123');
    expect(url.searchParams.getAll('scope')).toEqual([]);
  });

  it('sends every scope in a single space-delimited scope param', () => {
    // Canvas reads `params[:scope]` and calls `.split` on it
    // (oauth2_provider_controller.rb). Rack collapses a repeated `scope=`
    // key to its *last* value, so repeating the param silently drops every
    // scope but the last one, and the resulting token 401s on the rest.
    const url = new URL(
      buildAuthorizeUrl(config, {
        state: 'abc123',
        scopes: ['url:GET|/api/v1/courses', 'url:GET|/api/v1/users/:id'],
      })
    );
    expect(url.searchParams.getAll('scope')).toEqual([
      'url:GET|/api/v1/courses url:GET|/api/v1/users/:id',
    ]);
    expect(url.searchParams.get('scope')?.split(' ')).toEqual([
      'url:GET|/api/v1/courses',
      'url:GET|/api/v1/users/:id',
    ]);
  });

  it('omits the scope param entirely when the scopes array is empty', () => {
    // An empty `scope=` would make Canvas parse zero scopes, which fails
    // `valid_scopes?` outright on an Enforce Scopes key.
    const url = new URL(buildAuthorizeUrl(config, { state: 'abc123', scopes: [] }));
    expect(url.searchParams.has('scope')).toBe(false);
  });

  it('respects an explicit http:// scheme for local/dev Canvas instances', () => {
    const localConfig = { ...config, canvasDomain: 'http://localhost:9100' };
    const url = new URL(buildAuthorizeUrl(localConfig, { state: 'abc123' }));
    expect(url.origin + url.pathname).toBe('http://localhost:9100/login/oauth2/auth');
  });
});

describe('exchangeCodeForTokens', () => {
  it('exchanges a code for tokens', async () => {
    server.use(
      http.post('https://ubc.instructure.com/login/oauth2/token', async ({ request }) => {
        const body = await request.text();
        const params = new URLSearchParams(body);
        expect(params.get('grant_type')).toBe('authorization_code');
        expect(params.get('code')).toBe('the-code');
        expect(params.get('client_id')).toBe('client-id');
        expect(params.get('client_secret')).toBe('client-secret');
        expect(params.get('redirect_uri')).toBe(config.redirectUri);
        return HttpResponse.json({
          access_token: 'access-1',
          refresh_token: 'refresh-1',
          expires_in: 3600,
          user: { id: 42 },
        });
      })
    );

    const tokens = await exchangeCodeForTokens(config, 'the-code');
    expect(tokens.accessToken).toBe('access-1');
    expect(tokens.refreshToken).toBe('refresh-1');
    expect(tokens.canvasUserId).toBe('42');
    expect(tokens.expiresAt).toBeGreaterThan(Date.now());
  });

  it('exchanges a code for tokens against a plain-http local Canvas instance', async () => {
    server.use(
      http.post('http://localhost:9100/login/oauth2/token', () =>
        HttpResponse.json({ access_token: 'access-1', refresh_token: 'refresh-1', expires_in: 3600, user: { id: 42 } })
      )
    );

    const tokens = await exchangeCodeForTokens({ ...config, canvasDomain: 'http://localhost:9100' }, 'the-code');
    expect(tokens.accessToken).toBe('access-1');
  });

  it('throws CanvasOAuthError on a non-2xx response', async () => {
    server.use(
      http.post('https://ubc.instructure.com/login/oauth2/token', () =>
        HttpResponse.json({ error: 'invalid_grant', error_description: 'code expired' }, { status: 400 })
      )
    );

    await expect(exchangeCodeForTokens(config, 'bad-code')).rejects.toMatchObject({
      name: 'CanvasOAuthError',
      canvasError: 'invalid_grant',
      canvasErrorDescription: 'code expired',
    });
  });

  it('succeeds with refreshToken undefined when Canvas omits it (e.g. re-authorization)', async () => {
    server.use(
      http.post('https://ubc.instructure.com/login/oauth2/token', () =>
        HttpResponse.json({ access_token: 'access-1', expires_in: 3600, user: { id: 42 } })
      )
    );

    const tokens = await exchangeCodeForTokens(config, 'the-code');
    expect(tokens.accessToken).toBe('access-1');
    expect(tokens.refreshToken).toBeUndefined();
  });
});

describe('refreshTokens', () => {
  it('refreshes an access token', async () => {
    server.use(
      http.post('https://ubc.instructure.com/login/oauth2/token', async ({ request }) => {
        const params = new URLSearchParams(await request.text());
        expect(params.get('grant_type')).toBe('refresh_token');
        expect(params.get('refresh_token')).toBe('refresh-1');
        return HttpResponse.json({ access_token: 'access-2', expires_in: 3600 });
      })
    );

    const result = await refreshTokens(config, 'refresh-1');
    expect(result.accessToken).toBe('access-2');
    expect(result.refreshToken).toBeUndefined();
    expect(result.expiresAt).toBeGreaterThan(Date.now());
  });

  it('surfaces a new refresh_token when Canvas rotates it', async () => {
    server.use(
      http.post('https://ubc.instructure.com/login/oauth2/token', () =>
        HttpResponse.json({ access_token: 'access-2', refresh_token: 'refresh-2', expires_in: 3600 })
      )
    );

    const result = await refreshTokens(config, 'refresh-1');
    expect(result.refreshToken).toBe('refresh-2');
  });

  it('throws CanvasOAuthError when the refresh token was revoked', async () => {
    server.use(
      http.post('https://ubc.instructure.com/login/oauth2/token', () =>
        HttpResponse.json({ error: 'invalid_grant' }, { status: 400 })
      )
    );

    await expect(refreshTokens(config, 'revoked')).rejects.toBeInstanceOf(CanvasOAuthError);
  });
});

describe('revokeToken', () => {
  it('sends a DELETE with the bearer token', async () => {
    let authHeader = '';
    server.use(
      http.delete('https://ubc.instructure.com/login/oauth2/token', ({ request }) => {
        authHeader = request.headers.get('Authorization') ?? '';
        return HttpResponse.json({});
      })
    );

    await revokeToken(config, 'access-1');
    expect(authHeader).toBe('Bearer access-1');
  });

  it('throws CanvasOAuthError on a non-2xx response', async () => {
    server.use(
      http.delete('https://ubc.instructure.com/login/oauth2/token', () => new HttpResponse(null, { status: 401 }))
    );

    await expect(revokeToken(config, 'access-1')).rejects.toBeInstanceOf(CanvasOAuthError);
  });
});
