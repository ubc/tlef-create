import { afterAll, afterEach, beforeAll, describe, expect, it } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createApiClient } from '../src/providers/moodle/api-client';
import { downloadFile, getCourseFiles } from '../src/providers/moodle/resources/files';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const REST_URL = 'https://moodle.example.ubc.ca/webservice/rest/server.php';
const FILE_URL = 'https://moodle.example.ubc.ca/webservice/pluginfile.php/4/mod_resource/content/1/notes.txt';

function makeClient() {
  return createApiClient({ moodleDomain: 'moodle.example.ubc.ca', token: 'tok-1', userId: '42' });
}

function courseContents(fileUrl = FILE_URL) {
  return [
    {
      id: 2,
      name: 'Week 1',
      modules: [
        {
          id: 3,
          name: 'Lecture notes',
          contents: [
            {
              type: 'file',
              filename: 'notes.txt',
              filesize: 5,
              fileurl: fileUrl,
              mimetype: 'text/plain',
              timecreated: 1_700_000_000,
              timemodified: 1_700_000_100,
            },
          ],
        },
      ],
    },
  ];
}

describe('Moodle course files', () => {
  it('flattens module contents into normalized file metadata', async () => {
    let params = new URLSearchParams();
    server.use(
      http.post(REST_URL, async ({ request }) => {
        params = new URLSearchParams(await request.text());
        return HttpResponse.json(courseContents());
      })
    );
    const files = await getCourseFiles(makeClient(), '55');
    expect(params.get('wsfunction')).toBe('core_course_get_contents');
    expect(params.get('courseid')).toBe('55');
    expect(files).toEqual([
      expect.objectContaining({
        courseId: '55',
        filename: 'notes.txt',
        mimeType: 'text/plain',
        size: 5,
      }),
    ]);
    expect(files[0].id).toMatch(/^[A-Za-z0-9_-]{43}$/);
  });

  it('re-resolves the course-scoped id and downloads with the Moodle token', async () => {
    server.use(
      http.post(REST_URL, () => HttpResponse.json(courseContents())),
      http.get(FILE_URL, ({ request }) => {
        expect(new URL(request.url).searchParams.get('token')).toBe('tok-1');
        return new HttpResponse(new TextEncoder().encode('notes'), {
          headers: { 'content-type': 'text/plain' },
        });
      })
    );
    const [file] = await getCourseFiles(makeClient(), 55);
    const result = await downloadFile(makeClient(), 55, file.id);
    expect(new TextDecoder().decode(result.data)).toBe('notes');
    expect(result).toMatchObject({ filename: 'notes.txt', contentType: 'text/plain', size: 5 });
  });

  it('rejects file URLs outside the configured Moodle origin', async () => {
    server.use(http.post(REST_URL, () => HttpResponse.json(courseContents('https://attacker.example/file'))));
    const [file] = await getCourseFiles(makeClient(), 55);
    await expect(downloadFile(makeClient(), 55, file.id)).rejects.toMatchObject({
      name: 'MoodleApiError',
      errorcode: 'invalidfileurl',
    });
  });
});
