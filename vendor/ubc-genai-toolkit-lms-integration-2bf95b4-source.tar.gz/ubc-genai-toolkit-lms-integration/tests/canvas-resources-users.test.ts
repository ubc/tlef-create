import { afterAll, afterEach, beforeAll, describe, expect, it } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createApiClient } from '../src/providers/canvas/api-client';
import { getCourseUsers } from '../src/providers/canvas/resources/users';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const client = () => createApiClient({ canvasDomain: 'ubc.instructure.com', accessToken: 'token-1' });
const ROSTER_URL = 'https://ubc.instructure.com/api/v1/courses/7/users';

describe('Canvas course users', () => {
  it('normalizes the identity fields a roster match relies on', async () => {
    server.use(
      http.get(ROSTER_URL, () =>
        HttpResponse.json([
          {
            id: 2,
            name: 'Ada Lovelace',
            email: 'ada@student.ubc.ca',
            login_id: 'adal',
            sis_user_id: '12345678',
            integration_id: 'PUID-0001',
          },
        ])
      )
    );
    await expect(getCourseUsers(client(), 7)).resolves.toEqual([
      expect.objectContaining({
        id: '2',
        name: 'Ada Lovelace',
        email: 'ada@student.ubc.ca',
        loginId: 'adal',
        sisId: '12345678',
        integrationId: 'PUID-0001',
      }),
    ]);
  });

  it('requests students and current enrollments without unnecessary identity includes', async () => {
    let params = new URLSearchParams();
    server.use(
      http.get(ROSTER_URL, ({ request }) => {
        params = new URL(request.url).searchParams;
        return HttpResponse.json([]);
      })
    );

    await getCourseUsers(client(), 7);
    expect(params.getAll('enrollment_type[]')).toEqual(['student']);
    expect(params.getAll('enrollment_state[]')).toEqual(['active', 'invited']);
    expect(params.getAll('include[]')).toEqual([]);
  });

  it('deduplicates documented includes supplied by the caller', async () => {
    let params = new URLSearchParams();
    server.use(
      http.get(ROSTER_URL, ({ request }) => {
        params = new URL(request.url).searchParams;
        return HttpResponse.json([]);
      })
    );

    await getCourseUsers(client(), 7, { include: ['enrollments', 'enrollments'], enrollmentTypes: ['student', 'ta'] });
    expect(params.getAll('include[]')).toEqual(['enrollments']);
    expect(params.getAll('enrollment_type[]')).toEqual(['student', 'ta']);
  });

  it('leaves identity fields undefined when Canvas withholds them', async () => {
    server.use(
      http.get(ROSTER_URL, () => HttpResponse.json([{ id: 3, name: 'Grace Hopper', sis_user_id: null }]))
    );
    const [user] = await getCourseUsers(client(), 7);
    expect(user).toMatchObject({ id: '3', name: 'Grace Hopper' });
    expect(user.integrationId).toBeUndefined();
    expect(user.sisId).toBeUndefined();
    expect(user.email).toBeUndefined();
    expect(user.loginId).toBeUndefined();
  });

  it('falls back to the sortable name, then a placeholder, when no name is returned', async () => {
    server.use(
      http.get(ROSTER_URL, () =>
        HttpResponse.json([
          { id: 4, sortable_name: 'Hopper, Grace' },
          { id: 5 },
        ])
      )
    );
    const users = await getCourseUsers(client(), 7);
    expect(users.map((user) => user.name)).toEqual(['Hopper, Grace', 'Canvas user 5']);
  });

  it('returns every student across pages, not just Canvas\'s first page', async () => {
    server.use(
      http.get(ROSTER_URL, ({ request }) => {
        const page = Number(new URL(request.url).searchParams.get('page') ?? '1');
        return HttpResponse.json([{ id: page, name: `Student ${page}`, integration_id: `PUID-${page}` }], {
          headers: page < 3 ? { Link: `<${ROSTER_URL}?page=${page + 1}>; rel="next"` } : {},
        });
      })
    );

    const users = await getCourseUsers(client(), 7);
    expect(users.map((user) => user.integrationId)).toEqual(['PUID-1', 'PUID-2', 'PUID-3']);
  });
});
