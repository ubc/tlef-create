import { afterAll, afterEach, beforeAll, describe, expect, it, vi } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createApiClient } from '../src/providers/canvas/api-client';
import { downloadFile, getCourseFiles } from '../src/providers/canvas/resources/files';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

function makeClient(overrides: Partial<Parameters<typeof createApiClient>[0]> = {}) {
  return createApiClient({ canvasDomain: 'ubc.instructure.com', accessToken: 'token-1', ...overrides });
}

describe('Canvas course files', () => {
  it('normalizes file metadata and provider query options', async () => {
    let search = '';
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/files', ({ request }) => {
        search = new URL(request.url).search;
        return HttpResponse.json([
          {
            id: 9,
            display_name: 'Week 1',
            filename: 'week-1.pdf',
            'content-type': 'application/pdf',
            size: 123,
            created_at: '2026-01-01T00:00:00Z',
            updated_at: '2026-01-02T00:00:00Z',
          },
        ]);
      })
    );

    const files = await getCourseFiles(makeClient(), '7', {
      contentTypes: ['application/pdf', 'text/plain'],
      sort: 'updated_at',
      order: 'desc',
    });
    expect(new URLSearchParams(search).getAll('content_types[]')).toEqual(['application/pdf', 'text/plain']);
    expect(files).toEqual([
      expect.objectContaining({
        id: '9',
        courseId: '7',
        name: 'Week 1',
        filename: 'week-1.pdf',
        mimeType: 'application/pdf',
        size: 123,
      }),
    ]);
  });

  it('downloads bytes after a course-scoped metadata lookup', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/files/9', () =>
        HttpResponse.json({
          id: 9,
          filename: 'notes.txt',
          'content-type': 'text/plain',
          size: 5,
          url: 'https://ubc.instructure.com/files/9/download',
        })
      ),
      http.get('https://ubc.instructure.com/files/9/download', ({ request }) => {
        expect(request.headers.get('authorization')).toBe('Bearer token-1');
        return new HttpResponse(new TextEncoder().encode('notes'), {
          headers: { 'content-type': 'text/plain' },
        });
      })
    );

    const result = await downloadFile(makeClient(), 7, 9, { maxBytes: 10 });
    expect(new TextDecoder().decode(result.data)).toBe('notes');
    expect(result).toMatchObject({ filename: 'notes.txt', contentType: 'text/plain', size: 5 });
  });

  it('follows hosted Canvas file redirects without forwarding Canvas credentials', async () => {
    let externalAuthorization: string | null = 'not requested';
    let externalCookie: string | null = 'not requested';
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/files/9', () =>
        HttpResponse.json({
          id: 9,
          filename: 'notes.txt',
          'content-type': 'text/plain',
          size: 5,
          url: 'https://ubc.instructure.com/files/9/download',
        })
      ),
      http.get('https://ubc.instructure.com/files/9/download', ({ request }) => {
        expect(request.headers.get('authorization')).toBe('Bearer token-1');
        return new HttpResponse(null, {
          status: 302,
          headers: {
            location: 'https://files-us-east-1.inscloudgate.net/signed/notes?signature=secret',
            'set-cookie': 'canvas_session=session-secret; Secure; HttpOnly',
          },
        });
      }),
      http.get('https://files-us-east-1.inscloudgate.net/signed/notes', ({ request }) => {
        externalAuthorization = request.headers.get('authorization');
        externalCookie = request.headers.get('cookie');
        return new HttpResponse(new TextEncoder().encode('notes'), {
          headers: { 'content-type': 'text/plain' },
        });
      })
    );

    const result = await downloadFile(makeClient(), 7, 9, { maxBytes: 10 });

    expect(new TextDecoder().decode(result.data)).toBe('notes');
    expect(externalAuthorization).toBeNull();
    expect(externalCookie).toBeNull();
  });

  it('follows Canvas user-content redirects without forwarding Canvas credentials', async () => {
    let externalAuthorization: string | null = 'not requested';
    let externalCookie: string | null = 'not requested';
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/files/9', () =>
        HttpResponse.json({
          id: 9,
          filename: 'notes.txt',
          'content-type': 'text/plain',
          size: 5,
          url: 'https://ubc.instructure.com/files/9/download',
        })
      ),
      http.get('https://ubc.instructure.com/files/9/download', ({ request }) => {
        expect(request.headers.get('authorization')).toBe('Bearer token-1');
        return new HttpResponse(null, {
          status: 302,
          headers: {
            location: 'https://a24449-1677.cluster222.canvas-user-content.com/files/9/download?verifier=secret',
            'set-cookie': 'canvas_session=session-secret; Secure; HttpOnly',
          },
        });
      }),
      http.get('https://a24449-1677.cluster222.canvas-user-content.com/files/9/download', ({ request }) => {
        externalAuthorization = request.headers.get('authorization');
        externalCookie = request.headers.get('cookie');
        return new HttpResponse(new TextEncoder().encode('notes'), {
          headers: { 'content-type': 'text/plain' },
        });
      })
    );

    const result = await downloadFile(makeClient(), 7, 9, { maxBytes: 10 });

    expect(new TextDecoder().decode(result.data)).toBe('notes');
    expect(externalAuthorization).toBeNull();
    expect(externalCookie).toBeNull();
  });

  it('supports a hosted Canvas redirect chain ending at signed S3 storage', async () => {
    const credentialsSeen: Array<{ authorization: string | null; cookie: string | null }> = [];
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/files/9', () =>
        HttpResponse.json({
          id: 9,
          size: 5,
          url: 'https://ubc.instructure.com/files/9/download',
        })
      ),
      http.get('https://ubc.instructure.com/files/9/download', () =>
        new HttpResponse(null, {
          status: 302,
          headers: { location: 'https://files.inscloudgate.net/signed/notes' },
        })
      ),
      http.get('https://files.inscloudgate.net/signed/notes', ({ request }) => {
        credentialsSeen.push({
          authorization: request.headers.get('authorization'),
          cookie: request.headers.get('cookie'),
        });
        return new HttpResponse(null, {
          status: 302,
          headers: { location: 'https://course-files.s3.us-west-2.amazonaws.com/notes?signature=secret' },
        });
      }),
      http.get('https://course-files.s3.us-west-2.amazonaws.com/notes', ({ request }) => {
        credentialsSeen.push({
          authorization: request.headers.get('authorization'),
          cookie: request.headers.get('cookie'),
        });
        return new HttpResponse(new TextEncoder().encode('notes'));
      })
    );

    const result = await downloadFile(makeClient(), 7, 9);

    expect(new TextDecoder().decode(result.data)).toBe('notes');
    expect(credentialsSeen).toEqual([
      { authorization: null, cookie: null },
      { authorization: null, cookie: null },
    ]);
  });

  it('does not reattach Canvas credentials if an external host redirects back to Canvas', async () => {
    let returnedAuthorization: string | null = 'not requested';
    const fetchSpy = vi.spyOn(globalThis, 'fetch');
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/files/9', () =>
        HttpResponse.json({ id: 9, size: 5, url: 'https://ubc.instructure.com/files/9/download' })
      ),
      http.get('https://ubc.instructure.com/files/9/download', () =>
        new HttpResponse(null, {
          status: 302,
          headers: {
            location: 'https://files.inscloudgate.net/signed/notes',
            'set-cookie': 'canvas_session=session-secret; Secure; HttpOnly',
          },
        })
      ),
      http.get('https://files.inscloudgate.net/signed/notes', () =>
        new HttpResponse(null, {
          status: 302,
          headers: { location: 'https://ubc.instructure.com/files/9/final' },
        })
      ),
      http.get('https://ubc.instructure.com/files/9/final', ({ request }) => {
        returnedAuthorization = request.headers.get('authorization');
        return new HttpResponse(new TextEncoder().encode('notes'));
      })
    );

    await downloadFile(makeClient(), 7, 9);

    const returnedFetch = fetchSpy.mock.calls.find(([input]) => String(input).includes('/files/9/final'));
    const explicitlySuppliedHeaders = new Headers(returnedFetch?.[1]?.headers);
    expect(returnedAuthorization).toBeNull();
    // MSW's interceptor maintains its own cookie store and can add Set-Cookie
    // values after fetch receives the request. Inspect the actual fetch init to
    // prove the client itself did not reattach its Canvas cookie jar.
    expect(explicitlySuppliedHeaders.get('cookie')).toBeNull();
    fetchSpy.mockRestore();
  });

  it('rejects redirects to unknown hosts and HTTP downgrades', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/files/9', () =>
        HttpResponse.json({ id: 9, url: 'https://ubc.instructure.com/files/9/download' })
      ),
      http.get('https://ubc.instructure.com/files/9/download', () =>
        new HttpResponse(null, {
          status: 302,
          headers: { location: 'https://canvas-user-content.com.attacker.example/file' },
        })
      )
    );
    await expect(downloadFile(makeClient(), 7, 9)).rejects.toMatchObject({
      message:
        'Canvas returned an unexpected file download URL '
        + '(rejected https://canvas-user-content.com.attacker.example)',
      statusCode: 502,
    });

    server.resetHandlers();
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/files/9', () =>
        HttpResponse.json({ id: 9, url: 'https://ubc.instructure.com/files/9/download' })
      ),
      http.get('https://ubc.instructure.com/files/9/download', () =>
        new HttpResponse(null, {
          status: 302,
          headers: { location: 'http://files.inscloudgate.net/file' },
        })
      )
    );
    await expect(downloadFile(makeClient(), 7, 9)).rejects.toMatchObject({
      message: 'Canvas returned an unexpected file download URL (rejected http://files.inscloudgate.net)',
      statusCode: 502,
    });
  });

  it('supports explicitly configured institutional file hosts without forwarding credentials', async () => {
    let externalAuthorization: string | null = 'not requested';
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/files/9', () =>
        HttpResponse.json({ id: 9, size: 5, url: 'https://ubc.instructure.com/files/9/download' })
      ),
      http.get('https://ubc.instructure.com/files/9/download', () =>
        new HttpResponse(null, {
          status: 302,
          headers: { location: 'https://cdn.files.example.edu/notes' },
        })
      ),
      http.get('https://cdn.files.example.edu/notes', ({ request }) => {
        externalAuthorization = request.headers.get('authorization');
        return new HttpResponse(new TextEncoder().encode('notes'));
      })
    );

    const client = createApiClient({
      canvasDomain: 'ubc.instructure.com',
      accessToken: 'token-1',
      allowedDownloadHostSuffixes: ['files.example.edu'],
    });
    await downloadFile(client, 7, 9);

    expect(externalAuthorization).toBeNull();
  });

  it('rejects a metadata URL outside the configured Canvas origin', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/files/9', () =>
        HttpResponse.json({ id: 9, url: 'https://attacker.example/file?verifier=must-not-appear' })
      )
    );
    const failure = await downloadFile(makeClient(), 7, 9).then(() => null, (error) => error);
    expect(failure).toMatchObject({
      name: 'CanvasApiError',
      message: 'Canvas returned an unexpected file download URL (rejected https://attacker.example)',
      statusCode: 502,
    });
    expect(failure.message).not.toContain('must-not-appear');
  });

  it('enforces the caller download limit', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses/7/files/9', () =>
        HttpResponse.json({ id: 9, size: 5, url: 'https://ubc.instructure.com/files/9/download' })
      ),
      http.get('https://ubc.instructure.com/files/9/download', () =>
        new HttpResponse(new TextEncoder().encode('notes'), { headers: { 'content-length': '5' } })
      )
    );
    await expect(downloadFile(makeClient(), 7, 9, { maxBytes: 4 })).rejects.toMatchObject({ statusCode: 413 });
  });
});

describe('Canvas course files via public_url', () => {
  const METADATA_URL = 'https://ubc.instructure.com/api/v1/courses/7/files/9';
  const PUBLIC_URL_ENDPOINT = 'https://ubc.instructure.com/api/v1/files/9/public_url';
  const SIGNED_LINK = 'https://inscloudgate.net/files/abc/notes.txt';

  function serveMetadata(overrides: Record<string, unknown> = {}) {
    return http.get(METADATA_URL, () =>
      HttpResponse.json({
        id: 9,
        filename: 'notes.txt',
        'content-type': 'text/plain',
        size: 5,
        url: 'https://ubc.instructure.com/files/9/download?download_frd=1&verifier=file-verifier',
        ...overrides,
      })
    );
  }

  function servePublicUrl(link: string) {
    return http.get(PUBLIC_URL_ENDPOINT, () => HttpResponse.json({ public_url: link }));
  }

  function serveNotes(url: string, init: ConstructorParameters<typeof HttpResponse>[1] = {}) {
    return http.get(url, () => new HttpResponse(new TextEncoder().encode('notes'), init));
  }

  it('downloads the signed link without Canvas credentials on any hop', async () => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch');
    const apiAuthorization: Array<string | null> = [];
    const storageCredentials: Array<{ authorization: string | null; cookie: string | null }> = [];
    server.use(
      http.get(METADATA_URL, ({ request }) => {
        apiAuthorization.push(request.headers.get('authorization'));
        return HttpResponse.json({
          id: 9,
          filename: 'notes.txt',
          'content-type': 'text/plain',
          size: 5,
          url: 'https://ubc.instructure.com/files/9/download',
        });
      }),
      http.get(PUBLIC_URL_ENDPOINT, ({ request }) => {
        apiAuthorization.push(request.headers.get('authorization'));
        return HttpResponse.json({ public_url: `${SIGNED_LINK}?token=signed-jwt` });
      }),
      http.get(SIGNED_LINK, ({ request }) => {
        storageCredentials.push({
          authorization: request.headers.get('authorization'),
          cookie: request.headers.get('cookie'),
        });
        return new HttpResponse(null, {
          status: 302,
          headers: {
            location: 'https://course-files.s3.us-west-2.amazonaws.com/notes?signature=secret',
            'set-cookie': 'instfs_session=session-secret; Secure; HttpOnly',
          },
        });
      }),
      http.get('https://course-files.s3.us-west-2.amazonaws.com/notes', ({ request }) => {
        storageCredentials.push({
          authorization: request.headers.get('authorization'),
          cookie: request.headers.get('cookie'),
        });
        return new HttpResponse(new TextEncoder().encode('notes'), {
          headers: { 'content-type': 'text/plain' },
        });
      })
    );

    const result = await downloadFile(makeClient(), 7, 9, { maxBytes: 10, via: 'public-url' });

    expect(new TextDecoder().decode(result.data)).toBe('notes');
    expect(result).toMatchObject({ filename: 'notes.txt', contentType: 'text/plain', size: 5 });
    // The token authorizes the two API reads, which is where Canvas checks it.
    expect(apiAuthorization).toEqual(['Bearer token-1', 'Bearer token-1']);
    expect(storageCredentials).toEqual([
      { authorization: null, cookie: null },
      { authorization: null, cookie: null },
    ]);
    // MSW keeps its own cookie store, so also check what the client itself
    // handed fetch for every request that was not an API read.
    const downloadCalls = fetchSpy.mock.calls.filter(([input]) => !String(input).includes('/api/v1/'));
    expect(downloadCalls).toHaveLength(2);
    for (const [, init] of downloadCalls) {
      const headers = new Headers(init?.headers);
      expect(headers.get('authorization')).toBeNull();
      expect(headers.get('cookie')).toBeNull();
      expect(init?.credentials).toBe('omit');
    }
    fetchSpy.mockRestore();
  });

  it('sends neither the token nor Canvas cookies when the signed link is on Canvas itself', async () => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch');
    const seen: Array<string | null> = [];
    server.use(
      serveMetadata(),
      servePublicUrl('https://ubc.instructure.com/courses/7/files/9/download?verifier=link-verifier'),
      http.get('https://ubc.instructure.com/courses/7/files/9/download', ({ request }) => {
        seen.push(request.headers.get('authorization'));
        return new HttpResponse(null, {
          status: 302,
          headers: {
            location: 'https://ubc.instructure.com/files/9/download_frd?verifier=link-verifier',
            'set-cookie': 'canvas_session=session-secret; Secure; HttpOnly',
          },
        });
      }),
      http.get('https://ubc.instructure.com/files/9/download_frd', ({ request }) => {
        seen.push(request.headers.get('authorization'));
        return new HttpResponse(new TextEncoder().encode('notes'));
      })
    );

    const result = await downloadFile(makeClient(), 7, 9, { via: 'public-url' });

    expect(new TextDecoder().decode(result.data)).toBe('notes');
    expect(seen).toEqual([null, null]);
    const secondHop = fetchSpy.mock.calls.find(([input]) => String(input).includes('/download_frd'));
    expect(new Headers(secondHop?.[1]?.headers).get('cookie')).toBeNull();
    fetchSpy.mockRestore();
  });

  it('downloads a local Canvas verifier link through the docker alias without the token', async () => {
    let seen: { host: string | null; authorization: string | null; verifier: string | null } | null = null;
    server.use(
      http.get('http://localhost:9100/api/v1/courses/7/files/9', () =>
        HttpResponse.json({ id: 9, size: 5, url: 'http://canvas.docker/files/9/download?download_frd=1' })
      ),
      http.get('http://localhost:9100/api/v1/files/9/public_url', () =>
        HttpResponse.json({ public_url: 'http://canvas.docker/courses/7/files/9/download?verifier=local-verifier' })
      ),
      http.get('http://localhost:9100/courses/7/files/9/download', ({ request }) => {
        seen = {
          host: request.headers.get('host'),
          authorization: request.headers.get('authorization'),
          verifier: new URL(request.url).searchParams.get('verifier'),
        };
        return new HttpResponse(new TextEncoder().encode('notes'), {
          headers: { 'content-type': 'text/plain' },
        });
      })
    );

    const client = createApiClient({ canvasDomain: 'http://localhost:9100', accessToken: 'token-1' });
    const result = await downloadFile(client, 7, 9, { maxBytes: 10, via: 'public-url' });

    expect(new TextDecoder().decode(result.data)).toBe('notes');
    expect(seen).toEqual({ host: 'canvas.docker', authorization: null, verifier: 'local-verifier' });
  });

  it.each([
    ['an unknown host', 'https://attacker.example/file?token=must-not-appear', 'https://attacker.example'],
    [
      'a lookalike of a storage host',
      'https://inscloudgate.net.attacker.example/file?token=must-not-appear',
      'https://inscloudgate.net.attacker.example',
    ],
    ['plain HTTP on a storage host', 'http://files.inscloudgate.net/file?token=must-not-appear', 'http://files.inscloudgate.net'],
    [
      'a nonstandard port on a storage host',
      'https://files.inscloudgate.net:8443/file?token=must-not-appear',
      'https://files.inscloudgate.net:8443',
    ],
    ['a non-HTTP scheme', 'file:///etc/passwd?token=must-not-appear', 'file:'],
  ])('refuses a signed link on %s without requesting it', async (_label, link, rejected) => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch');
    server.use(serveMetadata(), servePublicUrl(link));

    const failure = await downloadFile(makeClient(), 7, 9, { via: 'public-url' }).then(() => null, (error) => error);

    expect(failure).toMatchObject({
      name: 'CanvasApiError',
      message: `Canvas returned an unexpected file download URL (rejected ${rejected})`,
      statusCode: 502,
    });
    expect(failure.message).not.toContain('must-not-appear');
    expect(fetchSpy.mock.calls.map(([input]) => new URL(String(input)).pathname)).toEqual([
      '/api/v1/courses/7/files/9',
      '/api/v1/files/9/public_url',
    ]);
    fetchSpy.mockRestore();
  });

  it('accepts a configured institutional storage host as the first hop', async () => {
    let authorization: string | null = 'not requested';
    server.use(
      serveMetadata(),
      servePublicUrl('https://cdn.files.example.edu/notes?signature=secret'),
      http.get('https://cdn.files.example.edu/notes', ({ request }) => {
        authorization = request.headers.get('authorization');
        return new HttpResponse(new TextEncoder().encode('notes'));
      })
    );

    const client = makeClient({ allowedDownloadHostSuffixes: ['files.example.edu'] });
    const result = await downloadFile(client, 7, 9, { via: 'public-url' });

    expect(new TextDecoder().decode(result.data)).toBe('notes');
    expect(authorization).toBeNull();
  });

  it.each([401, 403])('asks for one new link when storage refuses the first with %i', async (status) => {
    const onUnauthorized = vi.fn(async () => 'token-2');
    let linksIssued = 0;
    server.use(
      serveMetadata(),
      http.get(PUBLIC_URL_ENDPOINT, () => {
        linksIssued += 1;
        return HttpResponse.json({ public_url: `${SIGNED_LINK}?token=link-${linksIssued}` });
      }),
      http.get(SIGNED_LINK, ({ request }) =>
        new URL(request.url).searchParams.get('token') === 'link-1'
          ? new HttpResponse(null, { status })
          : new HttpResponse(new TextEncoder().encode('notes'))
      )
    );

    const result = await downloadFile(makeClient({ onUnauthorized }), 7, 9, { via: 'public-url' });

    expect(new TextDecoder().decode(result.data)).toBe('notes');
    expect(linksIssued).toBe(2);
    // Storage never saw the token, so the token is not what it refused.
    expect(onUnauthorized).not.toHaveBeenCalled();
  });

  it('gives up when the second link is refused too', async () => {
    const onUnauthorized = vi.fn(async () => 'token-2');
    let linksIssued = 0;
    server.use(
      serveMetadata(),
      http.get(PUBLIC_URL_ENDPOINT, () => {
        linksIssued += 1;
        return HttpResponse.json({ public_url: `${SIGNED_LINK}?token=link-${linksIssued}` });
      }),
      http.get(SIGNED_LINK, () => new HttpResponse(null, { status: 401 }))
    );

    await expect(
      downloadFile(makeClient({ onUnauthorized }), 7, 9, { via: 'public-url' })
    ).rejects.toMatchObject({
      name: 'CanvasApiError',
      message: 'Canvas file download returned 401',
      statusCode: 401,
    });
    expect(linksIssued).toBe(2);
    expect(onUnauthorized).not.toHaveBeenCalled();
  });

  it.each([401, 403, 404])('falls back to the file URL when Canvas refuses public_url with %i', async (status) => {
    let fileUrlAuthorization: string | null = 'not requested';
    server.use(
      serveMetadata(),
      http.get(PUBLIC_URL_ENDPOINT, () => new HttpResponse(null, { status })),
      http.get('https://ubc.instructure.com/files/9/download', ({ request }) => {
        fileUrlAuthorization = request.headers.get('authorization');
        return new HttpResponse(new TextEncoder().encode('notes'), {
          headers: { 'content-type': 'text/plain' },
        });
      })
    );

    const result = await downloadFile(makeClient(), 7, 9, { maxBytes: 10, via: 'public-url' });

    expect(new TextDecoder().decode(result.data)).toBe('notes');
    expect(result).toMatchObject({ filename: 'notes.txt', contentType: 'text/plain', size: 5 });
    expect(fileUrlAuthorization).toBe('Bearer token-1');
  });

  it('does not fall back when public_url fails for another reason', async () => {
    server.use(serveMetadata(), http.get(PUBLIC_URL_ENDPOINT, () => new HttpResponse(null, { status: 500 })));

    await expect(downloadFile(makeClient(), 7, 9, { via: 'public-url' })).rejects.toMatchObject({
      name: 'CanvasApiError',
      statusCode: 500,
    });
  });

  it('refuses a public_url response that names no link', async () => {
    server.use(serveMetadata(), http.get(PUBLIC_URL_ENDPOINT, () => HttpResponse.json({ public_url: null })));

    await expect(downloadFile(makeClient(), 7, 9, { via: 'public-url' })).rejects.toMatchObject({
      name: 'CanvasApiError',
      message: 'Canvas did not provide a public URL for file 9',
      statusCode: 502,
    });
  });

  it('still refuses an HTML page served in place of the file', async () => {
    server.use(
      serveMetadata(),
      servePublicUrl(`${SIGNED_LINK}?token=signed-jwt`),
      http.get(SIGNED_LINK, () =>
        new HttpResponse('<!doctype html><html><body>Log in</body></html>', {
          headers: { 'content-type': 'text/html; charset=utf-8' },
        })
      )
    );

    await expect(downloadFile(makeClient(), 7, 9, { via: 'public-url' })).rejects.toMatchObject({
      message: 'Canvas returned an HTML page instead of the requested file',
      statusCode: 502,
    });
  });

  it('still checks the downloaded size against the course-scoped metadata', async () => {
    server.use(serveMetadata({ size: 10 }), servePublicUrl(`${SIGNED_LINK}?token=signed-jwt`), serveNotes(SIGNED_LINK));

    await expect(downloadFile(makeClient(), 7, 9, { via: 'public-url' })).rejects.toMatchObject({
      message: 'Canvas file download was incomplete (expected 10 bytes, received 5)',
      statusCode: 502,
    });
  });

  it('still enforces the caller download limit', async () => {
    server.use(
      serveMetadata(),
      servePublicUrl(`${SIGNED_LINK}?token=signed-jwt`),
      serveNotes(SIGNED_LINK, { headers: { 'content-length': '5' } })
    );

    await expect(downloadFile(makeClient(), 7, 9, { maxBytes: 4, via: 'public-url' })).rejects.toMatchObject({
      statusCode: 413,
    });
  });

  it('still stops a signed link that redirects without end', async () => {
    let hops = 0;
    server.use(
      serveMetadata(),
      servePublicUrl('https://inscloudgate.net/loop/0'),
      http.get('https://inscloudgate.net/loop/:hop', ({ params }) => {
        hops += 1;
        return new HttpResponse(null, {
          status: 302,
          headers: { location: `https://inscloudgate.net/loop/${Number(params.hop) + 1}` },
        });
      })
    );

    await expect(downloadFile(makeClient(), 7, 9, { via: 'public-url' })).rejects.toMatchObject({
      message: 'Canvas file download exceeded the redirect limit',
      statusCode: 502,
    });
    expect(hops).toBe(6);
  });

  it('leaves the default path alone: no public_url request without via', async () => {
    server.use(serveMetadata(), serveNotes('https://ubc.instructure.com/files/9/download'));
    const fetchSpy = vi.spyOn(globalThis, 'fetch');

    await downloadFile(makeClient(), 7, 9, { via: 'file-url' });
    await downloadFile(makeClient(), 7, 9);

    expect(fetchSpy.mock.calls.map(([input]) => new URL(String(input)).pathname)).toEqual([
      '/api/v1/courses/7/files/9',
      '/files/9/download',
      '/api/v1/courses/7/files/9',
      '/files/9/download',
    ]);
    fetchSpy.mockRestore();
  });

  it('rejects an unknown via before calling Canvas', async () => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch');

    await expect(
      downloadFile(makeClient(), 7, 9, { via: 'public_url' as never })
    ).rejects.toMatchObject({ name: 'CanvasApiError', statusCode: 400 });
    expect(fetchSpy).not.toHaveBeenCalled();
    fetchSpy.mockRestore();
  });
});
