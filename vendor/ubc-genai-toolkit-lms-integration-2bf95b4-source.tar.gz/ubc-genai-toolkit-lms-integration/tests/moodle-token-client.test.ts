import { describe, it, expect, beforeAll, afterEach, afterAll } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { validateToken } from '../src/providers/moodle/token-client';
import { MoodleApiError } from '../src/providers/moodle/errors';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const REST_URL = 'https://moodle.example.ubc.ca/webservice/rest/server.php';

describe('validateToken', () => {
  it('calls core_webservice_get_site_info and returns the site info', async () => {
    let wsfunction = '';
    server.use(
      http.post(REST_URL, async ({ request }) => {
        const params = new URLSearchParams(await request.text());
        wsfunction = params.get('wsfunction') ?? '';
        return HttpResponse.json({ sitename: 'UBC Moodle', username: 'jsmith', userid: 4821 });
      })
    );

    const info = await validateToken('moodle.example.ubc.ca', 'tok-1');
    expect(wsfunction).toBe('core_webservice_get_site_info');
    expect(info).toEqual({ sitename: 'UBC Moodle', username: 'jsmith', userid: 4821 });
  });

  it('throws MoodleApiError for an invalid token', async () => {
    server.use(
      http.post(REST_URL, () =>
        HttpResponse.json({ exception: 'moodle_exception', errorcode: 'invalidtoken', message: 'Invalid token - token not found' })
      )
    );

    await expect(validateToken('moodle.example.ubc.ca', 'bad-token')).rejects.toBeInstanceOf(MoodleApiError);
  });
});
