import { describe, it, expect, beforeAll, afterEach, afterAll, vi } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createApiClient } from '../src/providers/canvas/api-client';
import { CanvasApiError } from '../src/providers/canvas/errors';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

function makeClient(overrides: Partial<Parameters<typeof createApiClient>[0]> = {}) {
  return createApiClient({ canvasDomain: 'ubc.instructure.com', accessToken: 'token-1', ...overrides });
}

describe('createCanvasApiClient', () => {
  it('GETs against /api/v1/* with the bearer token', async () => {
    let authHeader = '';
    let path = '';
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', ({ request }) => {
        authHeader = request.headers.get('Authorization') ?? '';
        path = new URL(request.url).pathname;
        return HttpResponse.json([{ id: 1 }]);
      })
    );

    const result = await makeClient().get('/courses');
    expect(authHeader).toBe('Bearer token-1');
    expect(path).toBe('/api/v1/courses');
    expect(result).toEqual([{ id: 1 }]);
  });

  it('resolves a path without a leading slash the same way', async () => {
    let path = '';
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', ({ request }) => {
        path = new URL(request.url).pathname;
        return HttpResponse.json([]);
      })
    );
    await makeClient().get('courses');
    expect(path).toBe('/api/v1/courses');
  });

  it('does not double-prefix a path that already includes api/v1', async () => {
    let path = '';
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', ({ request }) => {
        path = new URL(request.url).pathname;
        return HttpResponse.json([]);
      })
    );
    await makeClient().get('/api/v1/courses');
    expect(path).toBe('/api/v1/courses');
  });

  it('serializes query params', async () => {
    let search = '';
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', ({ request }) => {
        search = new URL(request.url).search;
        return HttpResponse.json([]);
      })
    );
    await makeClient().get('/courses', { enrollment_type: 'teacher' });
    expect(search).toContain('enrollment_type=teacher');
  });

  it('serializes array-valued query params in Canvas/Rails repeated-bracket form', async () => {
    let capturedUrl = '';
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', ({ request }) => {
        capturedUrl = request.url;
        return HttpResponse.json([]);
      })
    );
    await makeClient().get('/courses', { include: ['syllabus_body', 'term'] });
    const url = new URL(capturedUrl);
    expect(url.searchParams.getAll('include[]')).toEqual(['syllabus_body', 'term']);
    expect(url.search).not.toContain('syllabus_body,term');
  });

  it('POSTs a JSON body', async () => {
    let body: unknown;
    server.use(
      http.post('https://ubc.instructure.com/api/v1/courses/1/assignments', async ({ request }) => {
        body = await request.json();
        return HttpResponse.json({ id: 99 });
      })
    );
    const result = await makeClient().post('/courses/1/assignments', { name: 'HW1' });
    expect(body).toEqual({ name: 'HW1' });
    expect(result).toEqual({ id: 99 });
  });

  it('retries once via onUnauthorized after a 401', async () => {
    const seenTokens: string[] = [];
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', ({ request }) => {
        const auth = request.headers.get('Authorization') ?? '';
        seenTokens.push(auth);
        if (auth === 'Bearer token-1') return new HttpResponse(null, { status: 401 });
        return HttpResponse.json([{ id: 1 }]);
      })
    );

    const onUnauthorized = vi.fn().mockResolvedValue('token-2');
    const result = await makeClient({ onUnauthorized }).get('/courses');

    expect(onUnauthorized).toHaveBeenCalledTimes(1);
    expect(seenTokens).toEqual(['Bearer token-1', 'Bearer token-2']);
    expect(result).toEqual([{ id: 1 }]);
  });

  it('throws CanvasApiError on 401 when onUnauthorized is not provided', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', () => new HttpResponse(null, { status: 401 }))
    );

    await expect(makeClient().get('/courses')).rejects.toMatchObject({
      name: 'CanvasApiError',
      statusCode: 401,
    });
  });

  it('throws CanvasApiError on other non-2xx responses without retrying', async () => {
    let attempts = 0;
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', () => {
        attempts++;
        return new HttpResponse(null, { status: 404 });
      })
    );

    await expect(makeClient().get('/courses')).rejects.toBeInstanceOf(CanvasApiError);
    expect(attempts).toBe(1);
  });
});

/**
 * Serves `pages` as consecutive Canvas pages, linking each to the next exactly
 * as Canvas does. Records every request URL so tests can assert on paging.
 */
function servePages(pages: unknown[][], { origin = 'https://ubc.instructure.com' } = {}) {
  const requested: URL[] = [];
  server.use(
    http.get('https://ubc.instructure.com/api/v1/courses', ({ request }) => {
      const url = new URL(request.url);
      requested.push(url);
      const index = Number(url.searchParams.get('page') ?? '1') - 1;
      const isLast = index >= pages.length - 1;
      const nextUrl = `${origin}/api/v1/courses?page=${index + 2}&per_page=${url.searchParams.get('per_page')}`;
      return HttpResponse.json(pages[index] ?? [], {
        headers: isLast ? {} : { Link: `<${nextUrl}>; rel="next"` },
      });
    })
  );
  return requested;
}

describe('canvas getAll pagination', () => {
  it('follows rel="next" and concatenates every page', async () => {
    const requested = servePages([[{ id: 1 }, { id: 2 }], [{ id: 3 }], []]);

    const rows = await makeClient().getAll('/courses');

    expect(rows).toEqual([{ id: 1 }, { id: 2 }, { id: 3 }]);
    expect(requested).toHaveLength(3);
  });

  it('requests Canvas\'s maximum page size instead of its default of 10', async () => {
    const requested = servePages([[{ id: 1 }]]);
    await makeClient().getAll('/courses');
    expect(requested[0].searchParams.get('per_page')).toBe('100');
  });

  it('respects a caller-supplied per_page', async () => {
    const requested = servePages([[{ id: 1 }]]);
    await makeClient().getAll('/courses', { per_page: 25 });
    expect(requested[0].searchParams.get('per_page')).toBe('25');
  });

  it('keeps other query params and array-valued params on the first page', async () => {
    const requested = servePages([[]]);
    await makeClient().getAll('/courses', { enrollment_type: ['student'], include: ['email'] });
    expect(requested[0].searchParams.getAll('enrollment_type[]')).toEqual(['student']);
    expect(requested[0].searchParams.getAll('include[]')).toEqual(['email']);
  });

  it('returns a single page unchanged when Canvas sends no Link header', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', () => HttpResponse.json([{ id: 1 }]))
    );
    await expect(makeClient().getAll('/courses')).resolves.toEqual([{ id: 1 }]);
  });

  it('refuses to follow a next link to another origin', async () => {
    servePages([[{ id: 1 }], [{ id: 2 }]], { origin: 'https://evil.example' });

    await expect(makeClient().getAll('/courses')).rejects.toMatchObject({
      name: 'CanvasApiError',
      message: expect.stringContaining('unexpected origin'),
    });
  });

  // Pins the documented default. This drifted once already: the option's JSDoc,
  // the README, and agents_canvas.md all claimed 100 (the per_page value) while
  // the code used 500. Nothing failed, because nothing asserted it.
  it('defaults the page ceiling to 500 requests, not the per_page value', async () => {
    let served = 0;
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', ({ request }) => {
        served += 1;
        const page = Number(new URL(request.url).searchParams.get('page') ?? '1');
        return HttpResponse.json([{ id: page }], {
          headers: { Link: `<https://ubc.instructure.com/api/v1/courses?page=${page + 1}>; rel="next"` },
        });
      })
    );

    await expect(makeClient().getAll('/courses')).rejects.toMatchObject({
      name: 'CanvasApiError',
      message: expect.stringContaining('exceeded 500 pages'),
    });
    expect(served).toBe(500);
  });

  it('throws rather than silently truncating when maxPages is reached', async () => {
    // Every page advertises a new one, so only the ceiling stops the loop.
    let served = 0;
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', ({ request }) => {
        served += 1;
        const page = Number(new URL(request.url).searchParams.get('page') ?? '1');
        return HttpResponse.json([{ id: page }], {
          headers: { Link: `<https://ubc.instructure.com/api/v1/courses?page=${page + 1}>; rel="next"` },
        });
      })
    );

    await expect(makeClient({ maxPages: 3 }).getAll('/courses')).rejects.toMatchObject({
      name: 'CanvasApiError',
      message: expect.stringContaining('exceeded 3 pages'),
    });
    expect(served).toBe(3);
  });

  it('stops immediately when next points back at a page already fetched', async () => {
    // A self-referential next would otherwise re-append the same rows until the
    // ceiling; this must fail on the first repeat, not after maxPages requests.
    let served = 0;
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', () => {
        served += 1;
        return HttpResponse.json([{ id: 1 }], {
          headers: { Link: '<https://ubc.instructure.com/api/v1/courses?per_page=100>; rel="next"' },
        });
      })
    );

    await expect(makeClient().getAll('/courses')).rejects.toMatchObject({
      name: 'CanvasApiError',
      message: expect.stringContaining('looped back'),
    });
    expect(served).toBe(1);
  });

  it('rejects a non-list body instead of returning a corrupt array', async () => {
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', () => HttpResponse.json({ id: 1 }))
    );

    await expect(makeClient().getAll('/courses')).rejects.toMatchObject({
      message: expect.stringContaining('non-list body'),
    });
  });

  it('refreshes the token mid-pagination and keeps going', async () => {
    let refreshed = false;
    server.use(
      http.get('https://ubc.instructure.com/api/v1/courses', ({ request }) => {
        const url = new URL(request.url);
        const page = Number(url.searchParams.get('page') ?? '1');
        const auth = request.headers.get('Authorization');
        if (page === 2 && !refreshed) return new HttpResponse(null, { status: 401 });
        if (page === 2 && auth !== 'Bearer token-2') return new HttpResponse(null, { status: 401 });
        return HttpResponse.json([{ id: page }], {
          headers: page === 1
            ? { Link: '<https://ubc.instructure.com/api/v1/courses?page=2>; rel="next"' }
            : {},
        });
      })
    );

    const onUnauthorized = vi.fn(async () => {
      refreshed = true;
      return 'token-2';
    });
    const rows = await makeClient({ onUnauthorized }).getAll('/courses');

    expect(onUnauthorized).toHaveBeenCalledTimes(1);
    expect(rows).toEqual([{ id: 1 }, { id: 2 }]);
  });
});

describe('ApiClient.download credentials', () => {
  it('still refreshes the token when a Canvas file URL answers 401', async () => {
    const seen: Array<string | null> = [];
    server.use(
      http.get('https://ubc.instructure.com/files/9/download', ({ request }) => {
        seen.push(request.headers.get('authorization'));
        return seen.length === 1
          ? new HttpResponse(null, { status: 401 })
          : new HttpResponse(new TextEncoder().encode('notes'));
      })
    );

    const onUnauthorized = vi.fn().mockResolvedValue('token-2');
    const result = await makeClient({ onUnauthorized }).download('https://ubc.instructure.com/files/9/download');

    expect(new TextDecoder().decode(result.data)).toBe('notes');
    expect(seen).toEqual(['Bearer token-1', 'Bearer token-2']);
    expect(onUnauthorized).toHaveBeenCalledTimes(1);
  });

  it('does not refresh the token when a signed link answers 401', async () => {
    let requests = 0;
    server.use(
      http.get('https://inscloudgate.net/files/abc', () => {
        requests += 1;
        return new HttpResponse(null, { status: 401 });
      })
    );

    const onUnauthorized = vi.fn().mockResolvedValue('token-2');
    await expect(
      makeClient({ onUnauthorized }).download('https://inscloudgate.net/files/abc?token=expired', { credentials: 'none' })
    ).rejects.toMatchObject({ name: 'CanvasApiError', statusCode: 401 });

    expect(onUnauthorized).not.toHaveBeenCalled();
    expect(requests).toBe(1);
  });

  it('lets only a signed link start on a storage host', async () => {
    server.use(
      http.get('https://files.inscloudgate.net/signed/notes', () => new HttpResponse(new TextEncoder().encode('notes')))
    );

    await expect(makeClient().download('https://files.inscloudgate.net/signed/notes')).rejects.toMatchObject({
      message: 'Canvas returned an unexpected file download URL (rejected https://files.inscloudgate.net)',
      statusCode: 502,
    });
    const result = await makeClient().download('https://files.inscloudgate.net/signed/notes', { credentials: 'none' });
    expect(new TextDecoder().decode(result.data)).toBe('notes');
  });

  it('rejects an unknown credentials value before any request', async () => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch');

    await expect(
      makeClient().download('https://ubc.instructure.com/files/9/download', { credentials: 'omit' as never })
    ).rejects.toMatchObject({ name: 'CanvasApiError', statusCode: 400 });
    expect(fetchSpy).not.toHaveBeenCalled();
    fetchSpy.mockRestore();
  });
});
