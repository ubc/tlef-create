import { afterAll, afterEach, beforeAll, describe, expect, it } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createApiClient } from '../src/providers/canvas/api-client';
import { explainUnmatched, matchCourseRoster } from '../src/providers/canvas/resources/users';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const client = () => createApiClient({ canvasDomain: 'ubc.instructure.com', accessToken: 'token-1' });
const ROSTER_URL = 'https://ubc.instructure.com/api/v1/courses/7/users';

describe('matchCourseRoster', () => {
  it('stamps the report with the course it actually read', async () => {
    server.use(
      http.get(ROSTER_URL, () =>
        HttpResponse.json([{ id: 2, name: 'Ada Lovelace', integration_id: 'PUID-0001' }])
      )
    );

    const report = await matchCourseRoster(client(), 7, ['PUID-0001']);
    expect(report.courseId).toBe('7');
    expect(report.matched).toEqual([
      { key: 'PUID-0001', lmsUserId: '2', name: 'Ada Lovelace', matchedBy: 'integrationId' },
    ]);
  });
});

describe('explainUnmatched', () => {
  const activeRoster = () =>
    http.get(ROSTER_URL, ({ request }) => {
      const states = new URL(request.url).searchParams.getAll('enrollment_state[]');
      if (states.includes('completed')) {
        return HttpResponse.json([
          {
            id: 5,
            name: 'Grace Hopper',
            integration_id: 'PUID-0404',
            enrollments: [{ enrollment_state: 'completed' }],
          },
        ]);
      }
      return HttpResponse.json([{ id: 2, name: 'Ada Lovelace', integration_id: 'PUID-0001' }]);
    });

  it('identifies an unmatched student who had concluded enrollment', async () => {
    server.use(activeRoster());

    const report = await matchCourseRoster(client(), 7, ['PUID-0001', 'PUID-0404']);
    expect(report.appOnly).toEqual([{ key: 'PUID-0404', reason: 'unknown' }]);

    const explained = await explainUnmatched(client(), 7, report);
    expect(explained.appOnly).toEqual([
      {
        key: 'PUID-0404',
        reason: 'enrollment-ended',
        formerEnrollment: { lmsUserId: '5', name: 'Grace Hopper', state: 'completed' },
      },
    ]);
  });

  it('marks someone absent from concluded enrollments too as never enrolled', async () => {
    server.use(activeRoster());

    const report = await matchCourseRoster(client(), 7, ['PUID-0001', 'PUID-9999']);
    const explained = await explainUnmatched(client(), 7, report);
    expect(explained.appOnly).toEqual([{ key: 'PUID-9999', reason: 'not-enrolled' }]);
  });

  it('leaves matched entries and the course stamp untouched', async () => {
    server.use(activeRoster());

    const report = await matchCourseRoster(client(), 7, ['PUID-0001', 'PUID-0404']);
    const explained = await explainUnmatched(client(), 7, report);
    expect(explained.matched).toEqual(report.matched);
    expect(explained.courseId).toBe('7');
  });

  it('skips the extra request when everyone matched', async () => {
    let reads = 0;
    server.use(
      http.get(ROSTER_URL, () => {
        reads += 1;
        return HttpResponse.json([{ id: 2, name: 'Ada Lovelace', integration_id: 'PUID-0001' }]);
      })
    );

    const report = await matchCourseRoster(client(), 7, ['PUID-0001']);
    await explainUnmatched(client(), 7, report);
    expect(reads).toBe(1);
  });

  it('refuses to explain a report built from a different course', async () => {
    server.use(activeRoster());

    const report = await matchCourseRoster(client(), 7, ['PUID-0404']);
    await expect(explainUnmatched(client(), 9, report)).rejects.toThrow(/course 7, not 9/);
  });
});
