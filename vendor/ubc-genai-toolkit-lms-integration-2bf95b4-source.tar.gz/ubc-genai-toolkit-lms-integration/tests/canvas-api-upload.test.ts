import { describe, it, expect, beforeAll, afterEach, afterAll, vi } from 'vitest';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { createApiClient } from '../src/providers/canvas/api-client';
import { CanvasUploadError } from '../src/providers/canvas/errors';

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const COMMENT_FILES_PATH =
  '/courses/7/assignments/8/submissions/9/comments/files';
const COMMENT_FILES_URL =
  'https://ubc.instructure.com/api/v1/courses/7/assignments/8/submissions/9/comments/files';

function makeClient(overrides: Partial<Parameters<typeof createApiClient>[0]> = {}) {
  return createApiClient({
    canvasDomain: 'ubc.instructure.com',
    accessToken: 'token-1',
    ...overrides,
  });
}

function pdf(text = 'feedback'): Uint8Array {
  return new TextEncoder().encode(`%PDF-1.7\n${text}\n%%EOF\n`);
}

function uploadFile(client = makeClient(), data = pdf()) {
  return client.uploadFile(COMMENT_FILES_PATH, {
    name: 'feedback.pdf',
    contentType: 'application/pdf',
    data,
  });
}

/** The initialization response Canvas returns for a comment-file upload. */
function ticket(uploadUrl: string, params: Record<string, unknown> = { key: 'signed-key', policy: 'signed-policy' }) {
  return HttpResponse.json({ upload_url: uploadUrl, upload_params: params });
}

describe('ApiClient.uploadFile initialization', () => {
  it('declares the filename, exact byte length, and content type to Canvas', async () => {
    let body: unknown;
    let authorization: string | null = null;
    server.use(
      http.post(COMMENT_FILES_URL, async ({ request }) => {
        authorization = request.headers.get('authorization');
        body = await request.json();
        return ticket('https://ubc.instructure.com/files_api/upload');
      }),
      http.post('https://ubc.instructure.com/files_api/upload', () =>
        HttpResponse.json({ id: 4242 }, { status: 201 })
      )
    );

    const data = pdf();
    const result = await uploadFile(makeClient(), data);

    expect(authorization).toBe('Bearer token-1');
    expect(body).toEqual({
      name: 'feedback.pdf',
      size: data.byteLength,
      content_type: 'application/pdf',
    });
    expect(result).toMatchObject({ id: '4242' });
  });

  it('rejects a malformed initialization response before any external request', async () => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch');
    server.use(
      http.post(COMMENT_FILES_URL, () => HttpResponse.json({ upload_params: { key: 'k' } }))
    );

    const failure = await uploadFile().then(() => null, (error: unknown) => error);

    expect(failure).toBeInstanceOf(CanvasUploadError);
    expect(failure).toMatchObject({ stage: 'initialize-upload', statusCode: 502 });
    expect(fetchSpy.mock.calls).toHaveLength(1);
    fetchSpy.mockRestore();
  });

  it('rejects upload parameters that are not scalar values', async () => {
    server.use(
      http.post(COMMENT_FILES_URL, () =>
        ticket('https://ubc.instructure.com/files_api/upload', { key: 'k', nested: { a: 1 } })
      )
    );

    await expect(uploadFile()).rejects.toMatchObject({
      stage: 'initialize-upload',
      statusCode: 502,
    });
  });

  it('surfaces a Canvas rejection of the initialization request with its status', async () => {
    server.use(
      http.post(COMMENT_FILES_URL, () => new HttpResponse(null, { status: 403 }))
    );

    await expect(uploadFile()).rejects.toMatchObject({
      stage: 'initialize-upload',
      statusCode: 403,
    });
  });
});

describe('ApiClient.uploadFile byte transfer', () => {
  it('copies every upload parameter unchanged, puts the file last, and sends no credentials', async () => {
    const params = {
      key: 'submissions/7/feedback.pdf',
      acl: 'private',
      policy: 'eyJleHBpcmF0aW9uIjoi',
      'x-amz-signature': 'signed',
      success_action_redirect: 'https://ubc.instructure.com/api/v1/files/4242',
    };
    let fieldNames: string[] = [];
    let sentParams: Record<string, string> = {};
    let contentType: string | null = null;
    let authorization: string | null = 'not requested';
    let cookie: string | null = 'not requested';
    let uploadedName: string | undefined;
    let uploadedType: string | undefined;
    let uploadedBytes = new Uint8Array();

    server.use(
      http.post(COMMENT_FILES_URL, () =>
        ticket('https://course-files.s3.us-west-2.amazonaws.com/upload', params)
      ),
      http.post('https://course-files.s3.us-west-2.amazonaws.com/upload', async ({ request }) => {
        authorization = request.headers.get('authorization');
        cookie = request.headers.get('cookie');
        contentType = request.headers.get('content-type');
        const form = await request.formData();
        fieldNames = [...form.keys()];
        for (const [name, value] of form.entries()) {
          if (typeof value === 'string') sentParams[name] = value;
        }
        const file = form.get('file') as File;
        uploadedName = file.name;
        uploadedType = file.type;
        uploadedBytes = new Uint8Array(await file.arrayBuffer());
        return new HttpResponse(null, {
          status: 303,
          headers: { location: 'https://ubc.instructure.com/api/v1/files/4242?done=1' },
        });
      }),
      http.get('https://ubc.instructure.com/api/v1/files/4242', () =>
        HttpResponse.json({ id: 4242, display_name: 'feedback.pdf' })
      )
    );

    const data = pdf();
    const result = await uploadFile(makeClient(), data);

    expect(sentParams).toEqual(params);
    expect(fieldNames[fieldNames.length - 1]).toBe('file');
    expect(fieldNames.slice(0, -1)).toEqual(Object.keys(params));
    expect(contentType).toMatch(/^multipart\/form-data; boundary=.+/);
    expect(authorization).toBeNull();
    expect(cookie).toBeNull();
    expect(uploadedName).toBe('feedback.pdf');
    expect(uploadedType).toBe('application/pdf');
    expect(uploadedBytes).toEqual(data);
    expect(result).toMatchObject({ id: '4242' });
  });

  it('sends no Canvas credentials even when the upload URL is on the Canvas origin', async () => {
    let authorization: string | null = 'not requested';
    let cookie: string | null = 'not requested';
    server.use(
      http.post(COMMENT_FILES_URL, () => ticket('https://ubc.instructure.com/files_api/upload')),
      http.post('https://ubc.instructure.com/files_api/upload', ({ request }) => {
        authorization = request.headers.get('authorization');
        cookie = request.headers.get('cookie');
        return HttpResponse.json({ id: 77 }, { status: 201 });
      })
    );

    await expect(uploadFile()).resolves.toMatchObject({ id: '77' });
    expect(authorization).toBeNull();
    expect(cookie).toBeNull();
  });

  it('uploads to an explicitly allowed institutional storage host', async () => {
    let reached = false;
    server.use(
      http.post(COMMENT_FILES_URL, () => ticket('https://cdn.files.example.edu/upload')),
      http.post('https://cdn.files.example.edu/upload', () => {
        reached = true;
        return HttpResponse.json({ id: 5 }, { status: 201 });
      })
    );

    const client = makeClient({ allowedUploadHostSuffixes: ['files.example.edu'] });
    await expect(uploadFile(client)).resolves.toMatchObject({ id: '5' });
    expect(reached).toBe(true);
  });

  it('sends no bytes to a non-allowlisted, HTTP, credential-bearing, or malformed upload URL', async () => {
    const rejected = [
      'https://canvas-user-content.com.attacker.example/upload',
      'http://files.inscloudgate.net/upload',
      'https://user:secret@files.inscloudgate.net/upload',
      'https://files.inscloudgate.net:8443/upload',
      'not-a-url-at-all::',
    ];

    for (const uploadUrl of rejected) {
      server.resetHandlers();
      const fetchSpy = vi.spyOn(globalThis, 'fetch');
      server.use(http.post(COMMENT_FILES_URL, () => ticket(uploadUrl)));

      const failure = await uploadFile().then(() => null, (error: unknown) => error);

      expect(failure, uploadUrl).toBeInstanceOf(CanvasUploadError);
      // `initialize-upload`, not `upload-bytes`: the distinction is the caller's
      // proof that no byte of student feedback left the process.
      expect(failure, uploadUrl).toMatchObject({ stage: 'initialize-upload', statusCode: 502 });
      // Only the initialization request may have gone out.
      expect(fetchSpy.mock.calls, uploadUrl).toHaveLength(1);
      fetchSpy.mockRestore();
    }
  });

  it('does not leak the signed upload URL in a rejection message', async () => {
    server.use(
      http.post(COMMENT_FILES_URL, () =>
        ticket('https://attacker.example/upload?signature=must-not-appear')
      )
    );

    const failure = await uploadFile().then(() => null, (error: unknown) => error);

    expect(String((failure as Error).message)).not.toContain('must-not-appear');
    expect(String((failure as Error).message)).toContain('https://attacker.example');
  });

  it('reports a rejected upload from the storage host at the upload-bytes stage', async () => {
    server.use(
      http.post(COMMENT_FILES_URL, () => ticket('https://files.inscloudgate.net/upload')),
      http.post('https://files.inscloudgate.net/upload', () => new HttpResponse(null, { status: 400 }))
    );

    await expect(uploadFile()).rejects.toMatchObject({
      stage: 'upload-bytes',
      statusCode: 400,
    });
  });
});

describe('ApiClient.uploadFile against a local Canvas', () => {
  // A Canvas in docker answers on localhost but hands out URLs on its compose
  // hostname. Node's fetch overwrites `Host`, so this path goes through
  // node:http instead — and has to build the same multipart body by hand.
  const localClient = () =>
    createApiClient({ canvasDomain: 'http://localhost:9100', accessToken: 'token-1' });

  it('rewrites the docker alias to the configured origin and keeps the multipart body intact', async () => {
    let uploadHost: string | null = null;
    let uploadContentType: string | null = null;
    let uploadAuthorization: string | null = 'not requested';
    let uploadedBytes = new Uint8Array();
    let sentKey: string | undefined;
    let confirmHost: string | null = null;
    let confirmAuthorization: string | null = null;

    server.use(
      http.post(
        'http://localhost:9100/api/v1/courses/7/assignments/8/submissions/9/comments/files',
        () =>
          HttpResponse.json({
            upload_url: 'http://canvas.docker/files_api/upload',
            upload_params: { key: 'signed-key' },
          })
      ),
      http.post('http://localhost:9100/files_api/upload', async ({ request }) => {
        uploadHost = request.headers.get('host');
        uploadContentType = request.headers.get('content-type');
        uploadAuthorization = request.headers.get('authorization');
        const form = await request.formData();
        sentKey = form.get('key') as string;
        uploadedBytes = new Uint8Array(await (form.get('file') as File).arrayBuffer());
        return new HttpResponse(null, {
          status: 201,
          headers: { location: 'http://canvas.docker/api/v1/files/77' },
        });
      }),
      http.get('http://localhost:9100/api/v1/files/77', ({ request }) => {
        confirmHost = request.headers.get('host');
        confirmAuthorization = request.headers.get('authorization');
        return HttpResponse.json({ id: 77 });
      })
    );

    const data = pdf();
    const result = await uploadFile(localClient(), data);

    expect(result).toMatchObject({ id: '77' });
    expect(uploadHost).toBe('canvas.docker');
    expect(uploadContentType).toMatch(/^multipart\/form-data; boundary=.+/);
    expect(uploadAuthorization).toBeNull();
    expect(sentKey).toBe('signed-key');
    expect(uploadedBytes).toEqual(data);
    // The confirmation is back against Canvas, which does take the token.
    expect(confirmHost).toBe('canvas.docker');
    expect(confirmAuthorization).toBe('Bearer token-1');
  });

  it('does not treat the docker alias as Canvas when Canvas is not local', async () => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch');
    server.use(
      http.post(COMMENT_FILES_URL, () => ticket('https://canvas.docker/files_api/upload'))
    );

    await expect(uploadFile()).rejects.toMatchObject({
      stage: 'initialize-upload',
      statusCode: 502,
    });
    expect(fetchSpy.mock.calls).toHaveLength(1);
    fetchSpy.mockRestore();
  });
});

describe('ApiClient.uploadFile completion', () => {
  it('finalizes a 3xx completion with an authenticated Canvas GET', async () => {
    let method = '';
    let authorization: string | null = null;
    server.use(
      http.post(COMMENT_FILES_URL, () => ticket('https://files.inscloudgate.net/upload')),
      http.post('https://files.inscloudgate.net/upload', () =>
        new HttpResponse(null, {
          status: 302,
          headers: { location: 'https://ubc.instructure.com/api/v1/files/4242?done=1' },
        })
      ),
      http.get('https://ubc.instructure.com/api/v1/files/4242', ({ request }) => {
        method = request.method;
        authorization = request.headers.get('authorization');
        return HttpResponse.json({ id: 4242 });
      })
    );

    await expect(uploadFile()).resolves.toMatchObject({ id: '4242' });
    expect(method).toBe('GET');
    expect(authorization).toBe('Bearer token-1');
  });

  it('finalizes a 201 Created completion through its Location header', async () => {
    server.use(
      http.post(COMMENT_FILES_URL, () => ticket('https://files.inscloudgate.net/upload')),
      http.post('https://files.inscloudgate.net/upload', () =>
        new HttpResponse(null, {
          status: 201,
          headers: { location: 'https://ubc.instructure.com/api/v1/files/99' },
        })
      ),
      http.get('https://ubc.instructure.com/api/v1/files/99', () => HttpResponse.json({ id: 99 }))
    );

    await expect(uploadFile()).resolves.toMatchObject({ id: '99' });
  });

  it('refreshes once when the token expires during Canvas confirmation', async () => {
    let refreshes = 0;
    const seenTokens: Array<string | null> = [];
    server.use(
      http.post(COMMENT_FILES_URL, () => ticket('https://files.inscloudgate.net/upload')),
      http.post('https://files.inscloudgate.net/upload', () =>
        new HttpResponse(null, {
          status: 201,
          headers: { location: 'https://ubc.instructure.com/api/v1/files/100' },
        })
      ),
      http.get('https://ubc.instructure.com/api/v1/files/100', ({ request }) => {
        const token = request.headers.get('authorization');
        seenTokens.push(token);
        return token === 'Bearer token-2'
          ? HttpResponse.json({ id: 100 })
          : new HttpResponse(null, { status: 401 });
      })
    );

    const client = makeClient({
      onUnauthorized: async () => {
        refreshes += 1;
        return 'token-2';
      },
    });

    await expect(uploadFile(client)).resolves.toMatchObject({ id: '100' });
    expect(refreshes).toBe(1);
    expect(seenTokens).toEqual(['Bearer token-1', 'Bearer token-2']);
  });

  it('accepts a 201 Created that returns the attachment inline', async () => {
    server.use(
      http.post(COMMENT_FILES_URL, () => ticket('https://files.inscloudgate.net/upload')),
      http.post('https://files.inscloudgate.net/upload', () =>
        HttpResponse.json({ attachment: { id: 31 } }, { status: 201 })
      )
    );

    await expect(uploadFile()).resolves.toMatchObject({ id: '31' });
  });

  it('never sends Canvas credentials to a completion URL on another external host', async () => {
    const externalAuthorization: Array<string | null> = [];
    server.use(
      http.post(COMMENT_FILES_URL, () => ticket('https://files.inscloudgate.net/upload')),
      http.post('https://files.inscloudgate.net/upload', () =>
        new HttpResponse(null, {
          status: 303,
          headers: { location: 'https://course-files.s3.us-west-2.amazonaws.com/confirm' },
        })
      ),
      http.get('https://course-files.s3.us-west-2.amazonaws.com/confirm', ({ request }) => {
        externalAuthorization.push(request.headers.get('authorization'));
        return new HttpResponse(null, {
          status: 303,
          headers: { location: 'https://ubc.instructure.com/api/v1/files/8' },
        });
      }),
      http.get('https://ubc.instructure.com/api/v1/files/8', () => HttpResponse.json({ id: 8 }))
    );

    await expect(uploadFile()).resolves.toMatchObject({ id: '8' });
    expect(externalAuthorization).toEqual([null]);
  });

  it('rejects a completion redirect to a host outside the upload allowlist', async () => {
    server.use(
      http.post(COMMENT_FILES_URL, () => ticket('https://files.inscloudgate.net/upload')),
      http.post('https://files.inscloudgate.net/upload', () =>
        new HttpResponse(null, {
          status: 303,
          headers: { location: 'https://attacker.example/confirm' },
        })
      )
    );

    await expect(uploadFile()).rejects.toMatchObject({
      stage: 'confirm-upload',
      statusCode: 502,
    });
  });

  it('fails when a redirect completion carries no destination', async () => {
    server.use(
      http.post(COMMENT_FILES_URL, () => ticket('https://files.inscloudgate.net/upload')),
      http.post('https://files.inscloudgate.net/upload', () => new HttpResponse(null, { status: 302 }))
    );

    await expect(uploadFile()).rejects.toMatchObject({
      stage: 'upload-bytes',
      statusCode: 502,
    });
  });

  it('fails when the completion chain never settles', async () => {
    let hops = 0;
    server.use(
      http.post(COMMENT_FILES_URL, () => ticket('https://files.inscloudgate.net/upload')),
      http.post('https://files.inscloudgate.net/upload', () =>
        new HttpResponse(null, {
          status: 303,
          headers: { location: 'https://ubc.instructure.com/api/v1/files/1' },
        })
      ),
      http.get('https://ubc.instructure.com/api/v1/files/:id', ({ params }) => {
        hops += 1;
        return new HttpResponse(null, {
          status: 303,
          headers: { location: `https://ubc.instructure.com/api/v1/files/${Number(params.id) + 1}` },
        });
      })
    );

    await expect(uploadFile()).rejects.toMatchObject({
      stage: 'confirm-upload',
      statusCode: 502,
    });
    expect(hops).toBeLessThanOrEqual(5);
  });

  it('rejects a completed upload that carries no file id', async () => {
    server.use(
      http.post(COMMENT_FILES_URL, () => ticket('https://files.inscloudgate.net/upload')),
      http.post('https://files.inscloudgate.net/upload', () =>
        HttpResponse.json({ display_name: 'feedback.pdf' }, { status: 201 })
      )
    );

    await expect(uploadFile()).rejects.toMatchObject({
      stage: 'confirm-upload',
      statusCode: 502,
    });
  });

  it('reports a Canvas failure during completion at the confirm-upload stage', async () => {
    server.use(
      http.post(COMMENT_FILES_URL, () => ticket('https://files.inscloudgate.net/upload')),
      http.post('https://files.inscloudgate.net/upload', () =>
        new HttpResponse(null, {
          status: 303,
          headers: { location: 'https://ubc.instructure.com/api/v1/files/4242' },
        })
      ),
      http.get('https://ubc.instructure.com/api/v1/files/4242', () =>
        new HttpResponse(null, { status: 401 })
      )
    );

    await expect(uploadFile()).rejects.toMatchObject({
      stage: 'confirm-upload',
      statusCode: 401,
    });
  });
});
