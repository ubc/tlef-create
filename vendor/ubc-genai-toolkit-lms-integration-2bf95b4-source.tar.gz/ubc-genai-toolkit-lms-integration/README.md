# UBC GenAI Toolkit - LMS Integration

Multi-LMS (Canvas, Moodle) auth client and Express integration for Node.js — connect a user's
Canvas or Moodle account (or both) and call that LMS's API as them.

This is an internal UBC package published to **GitHub Packages**, not the public npm registry —
`npm install` needs to know where to find the `@ubc` scope and be authenticated, even for
public-visibility repos (GitHub Packages requires auth for every install, unlike npmjs.com).

Add to your project's `.npmrc`:

```
@ubc:registry=https://npm.pkg.github.com
```

Add to your **user-level** `~/.npmrc` (never commit this — it's a personal credential) a
[GitHub personal access token](https://github.com/settings/tokens) with at least the
`read:packages` scope:

```
//npm.pkg.github.com/:_authToken=YOUR_GITHUB_TOKEN
```

```bash
npm install @ubc/ubc-genai-toolkit-lms-integration
```

- Node `>=18`, Express `^4.18.0 || ^5.0.0` (peer dependency).
- `express-session` (or equivalent `req.session`) for Canvas's OAuth flow.
- `express.json()` for Moodle's `/connect` route.

Canvas and Moodle are namespaced (`canvas.*` / `moodle.*`) — mount whichever your app needs.

## Environment variables

**Required** — each provider's `loadConfigFromEnv` throws, listing any that are missing, if you
mount that provider:

| Variable | Provider | Notes |
|---|---|---|
| `CANVAS_DOMAIN` | Canvas | e.g. `ubc.instructure.com` |
| `CANVAS_CLIENT_ID` | Canvas | From the Canvas Developer Key |
| `CANVAS_CLIENT_SECRET` | Canvas | From the Canvas Developer Key |
| `CANVAS_REDIRECT_URI` | Canvas | Full URL to your app's callback route — see below |
| `MOODLE_DOMAIN` | Moodle | e.g. `moodle.example.ubc.ca` |

`CANVAS_REDIRECT_URI` is your own app's callback URL — by default (no `basePath` override) it's
just `{your-domain}/canvas/auth/callback`. That exact string must also be registered in the
Developer Key's redirect URI whitelist in Canvas admin — a mismatch on either side fails the OAuth
exchange. Example:

```
CANVAS_REDIRECT_URI=https://grasp.staging.apps.ltic.ubc.ca/canvas/auth/callback
```

Only mounting one provider? Only that provider's variables apply — a Moodle-only app doesn't need
any `CANVAS_*` var, and vice versa.

There are no optional environment variables. `loadConfigFromEnv` reads only the required variables
above; everything else (`tokenStore`, `getUserKey`, `scopes`, `basePath`,
`allowedDownloadHostSuffixes`) is supplied as plain JS to its `overrides` argument, not sourced
from `process.env`. If your app wants an env-driven Mongo collection name, that's your own app's
convention, not something this package reads — e.g. the pattern used in the examples below:

```js
createMongoTokenStore(() => myDb.connect(), {
  collectionName: process.env.CANVAS_TOKEN_COLLECTION_NAME || 'canvas_tokens',
})
```

## Canvas

Requires a Canvas **Developer Key** (client ID/secret + redirect URI) from your Canvas admin.

```js
const express = require('express');
const session = require('express-session');
const { canvas, createMongoTokenStore } = require('@ubc/ubc-genai-toolkit-lms-integration');

// Reads CANVAS_DOMAIN / CANVAS_CLIENT_ID / CANVAS_CLIENT_SECRET / CANVAS_REDIRECT_URI from process.env
const canvasConfig = canvas.loadConfigFromEnv({
  tokenStore: createMongoTokenStore(() => myDb.connect(), {
    collectionName: process.env.CANVAS_TOKEN_COLLECTION_NAME || 'canvas_tokens',
  }),
  getUserKey: (req) => req.user.id,
});

const app = express();
app.use(session({ secret: process.env.SESSION_SECRET }));
app.use('/canvas/auth', canvas.createAuthRouter(canvasConfig)); // required — wires up login/callback/logout

// Not required setup — just an example of a route you'd add yourself, once
// connected, to actually use the Canvas connection.
app.get('/api/canvas/courses', canvas.requireAuth(canvasConfig), async (req, res) => {
  res.json(await canvas.getCourses(req.canvasApi));
});
```

| Route | Method | Purpose |
|---|---|---|
| `{basePath}/login` | GET | Redirect to Canvas's authorize screen |
| `{basePath}/callback` | GET | Exchange the code, store tokens |
| `{basePath}/logout` | POST | Revoke and clear stored tokens |

Page routes needing a browser redirect (instead of a JSON 401) use `canvas.ensureAuth` in place of
`canvas.requireAuth`.

**Read APIs:**

- `canvas.getCourses(client, query?)`
- `canvas.getCourseSections(client, courseId)`
- `canvas.getCourseUsers(client, courseId, { enrollmentTypes?, enrollmentStates?, include? })`
- `canvas.getCourseFiles(client, courseId, options?)`
- `canvas.downloadFile(client, courseId, fileId, { maxBytes?, via? })`
- `canvas.getGradeItems(client, courseId, options?)`
- `canvas.getGrades(client, { courseId, gradeItemId?, userIds?, enrollmentStates? })`
- `canvas.getSubmissions(client, { courseId, gradeItemId, userIds?, includeUnsubmitted?, include? })`
- `canvas.resolveSubmissions(report, gradeItemId, submissions)`
- `canvas.downloadSubmissionAttachment(client, { courseId, gradeItemId, userId, attachmentId, maxBytes })`

Course, section, roster, file, grade-item, grade, and submission results use the shared normalized
types below; the raw Canvas response remains on `.raw`. `getGrades` is read-only: omit
`gradeItemId` for current course grades, or provide it for assignment submissions. File
metadata/downloads require the Canvas Files scopes (on an Enforce Scopes key, see **Developer Keys
with Enforce Scopes** below for downloads); grades require the relevant Assignments, Enrollments,
and Submissions scopes on a least-privilege Developer Key. Methods throw `canvas.CanvasApiError`.

`getSubmissions` lists work without downloading it — attachment bytes come separately from
`downloadSubmissionAttachment`, so a 300-person course doesn't pull 300 files to answer "who
submitted?". Canvas returns a placeholder for every student who hasn't submitted; those are
excluded unless you pass `includeUnsubmitted: true`.

`getSubmissions` returns Canvas user ids. Pass the results through `resolveSubmissions` with the
expected assignment and a match report to get them keyed by your own identifiers, plus an explicit
list of submissions whose student has no application account. The resolver checks every row's course
and assignment; otherwise a mixed array could process Lab 2 work as Lab 1, and a student the join
silently drops looks exactly like one who never submitted.

`downloadSubmissionAttachment` names the course, assignment, student, and attachment rather than
taking a URL, and re-resolves it through Canvas before fetching. A URL passed in from elsewhere
proves only that it points at Canvas, not that the file belongs to this submission. `maxBytes` is
required here, unlike on course files: these bytes come from a student and are buffered whole in
memory, so the ceiling is a decision you make rather than inherit. Missing, non-positive, non-finite,
and non-integer limits are rejected at runtime as well as by TypeScript.

**Matching a roster to your own users:**

- `canvas.matchCourseRoster(client, courseId, appUserKeys, options?)`
- `canvas.explainUnmatched(client, courseId, report, options?)`

`matchCourseRoster` reads the roster and pairs it against your application's identifiers on
`integration_id` alone — at UBC, the PUID. There is deliberately no fallback key: an unmatched
student is a line in a report someone reads, while a mis-matched one is a grade filed against the
wrong person. The returned `LmsRosterMatchReport` separates `matched`, `appOnly` (your users with
no active enrollment), `rosterOnly` (students who never used your app — informational, not a
warning), and `ambiguous` (a key claimed twice on one side, matched to neither).

The report is stamped with the course whose roster produced it, which is what makes it safe to
write from. A Canvas user id is the same in every course a student takes, so a score computed for
one section would otherwise post cleanly against another.

`explainUnmatched` costs one extra request and answers a question the active roster can't: a
student who dropped is simply absent, indistinguishable from one who was never enrolled. It reads
concluded enrollments and upgrades each `appOnly` entry's `reason` to `enrollment-ended` (with the
former enrollment attached) or `not-enrolled`.

**Writing grades back:**

- `canvas.resolveGradeWrites(report, gradeItemId, grades)` — pure; translates your keys to Canvas user ids
- `canvas.preflightGradeExport(client, { courseId, gradeItemId, batch })` — every check, no write
- `canvas.postGrades(client, { courseId, gradeItemId, batch, allowPartial?, preflight? })` — one bulk request
- `canvas.waitForProgress(client, progressId, options?)` — poll the queued job

```js
const report = await canvas.matchCourseRoster(client, courseId, appUsers);
const batch = canvas.resolveGradeWrites(report, gradeItemId, [
  { key: 'PUID-0001', postedGrade: 85, comment: 'Nice work' },
]);

// Show the instructor batch.unresolved and preflight.postManually before writing.
const preflight = await canvas.preflightGradeExport(client, { courseId, gradeItemId, batch });

const queued = await canvas.postGrades(client, { courseId, gradeItemId, batch, preflight });
const done = await canvas.waitForProgress(client, queued.progressId);
```

Resolving is a separate step from sending on purpose: an instructor should see who is about to be
graded, and who is about to be skipped, before anything reaches Canvas. `postGrades` throws
`canvas.CanvasGradeExportError` — `reason` is one of `roster-coverage`, `course-mismatch`,
`assignment-mismatch`, `empty-batch`, `partial-export`, `invalid-grade`, `preflight-stale`, or
`unsupported-grading` — before sending anything, for the cases where the write would succeed against
Canvas while being wrong or the reviewed conditions changed.

Two of those are worth understanding. **`assignment-mismatch`**: a batch computed for Lab 1 posts
perfectly cleanly to Lab 2 — same course, same students, same ids — and Canvas only checks that Lab
2 belongs to the course, so the batch carries the assignment it was computed for and that is
checked too. **`partial-export`**: if anything is unresolved, the write is refused unless you pass
`allowPartial: true`, because a partial export is only visibly partial if your UI remembers to
render the skipped list.

**Sending feedback PDFs back:**

- `canvas.resolveSubmissionFeedbackWrites(report, gradeItemId, inputs, { maxBytesPerFile })` — pure
- `canvas.preflightSubmissionFeedbackExport(client, { courseId, gradeItemId, batch })` — every check, no upload
- `canvas.postSubmissionFeedbackPdfs(client, { courseId, gradeItemId, batch, preflight?, concurrency? })`

Attaches one application-generated PDF to each student's submission as an instructor comment. It
starts after your application has generated the feedback and an instructor has approved it; this
package neither creates nor edits PDFs. v1 is PDF-only, Canvas-only, and one file per student.

```js
const report = await canvas.matchCourseRoster(client, courseId, appUsers);

const batch = canvas.resolveSubmissionFeedbackWrites(
  report,
  gradeItemId,
  approved.map((feedback) => ({
    feedbackId: feedback.id,       // your record id; every result and error names it
    key: feedback.puid,            // your identifier, never a Canvas user id
    attempt: feedback.canvasAttempt, // the imported attempt this feedback is about
    filename: 'feedback.pdf',
    data: feedback.pdfBytes,       // Uint8Array or Buffer
    textComment: 'Your written feedback is attached.',
  })),
  { maxBytesPerFile: 10 * 1024 * 1024 }
);

// Keep the batch server-side. Show the instructor these four things and batch.unresolved.
const preflight = await canvas.preflightSubmissionFeedbackExport(client, {
  courseId,
  gradeItemId,
  batch,
});
// preflight.fileCount, preflight.totalBytes, preflight.assignmentName, preflight.postManually

// Only after the instructor confirms:
const result = await canvas.postSubmissionFeedbackPdfs(client, {
  courseId,
  gradeItemId,
  batch,
  preflight,
  concurrency: 3,
});
```

Canvas needs four or five requests per student — verify the submission, negotiate an upload, send
the bytes, confirm the upload where Canvas asks for it, and attach the file to a comment — and the
bytes go to Instructure's storage rather than to Canvas itself. All of that is inside `postSubmissionFeedbackPdfs`; the Canvas bearer token and cookies are
never sent to the storage host, which Canvas itself requires ("the access token is not sent with
this request").

`preflight.batchFingerprint` covers the target, every feedback id, student, attempt, filename,
comment text, and a hash of every PDF. `postSubmissionFeedbackPdfs` re-reads the assignment and
recomputes the fingerprint immediately before the first upload, so a file swapped after the
instructor approved it — or a posting policy changed during review — is refused as `preflight-stale`
rather than uploaded.

> **Students may see this immediately.** `postManually: false` means the PDF is downloadable by the
> student the moment it is attached. Show `preflight.postManually` before the instructor confirms,
> not after.

Once the first upload starts, per-student outcomes replace exceptions: `results` has one entry per
`batch.writes` entry, **in that order**, and one student's failure does not erase the record of the
students who succeeded. Each entry is `attached`, `failed`, `unknown`, or `not-attempted`, with the
`stage` that stopped it (`verify-submission`, `initialize-upload`, `upload-bytes`, `confirm-upload`,
`attach-comment`). Persist `feedbackId` with the outcome.

Three of those states need handling beyond a log line:

- **`unknown`** means the connection failed during the comment write itself. Canvas may have created
  the comment before it dropped, so there is no safe automatic retry — re-running blind can leave a
  student with two copies of their feedback. Canvas exposes no idempotency key for this write, and
  this package does not pretend otherwise. Reconcile these by hand.
- **`failed` at `attach-comment`** carries a `fileId`: the PDF is in Canvas with nothing pointing at
  it. That id is what makes the orphan findable.
- **`not-attempted`** means the export stopped before reaching that student, after Canvas rejected
  the credentials. Nothing was sent for them. Losing authorization is a fact about the export rather
  than about one student, so the run stops instead of producing 280 identical errors.

Refusals throw `canvas.CanvasSubmissionFeedbackError` before the first upload — `reason` is one of
`roster-coverage`, `course-mismatch`, `assignment-mismatch`, `empty-batch`, `partial-export`,
`invalid-feedback`, `preflight-stale`, `unsupported-grading`, or `unsupported-group-assignment`.
Group assignments are refused deliberately: whether one PDF belongs to one student or to a whole
group is a product decision, and Canvas would silently pick one.

Every file is validated on the way in and again before the write — `.pdf` filename with no path
separators or control characters, non-empty bytes under `maxBytesPerFile`, and a real `%PDF-`
signature in the first 1 KB. A batch is an ordinary mutable object, so a limit enforced only where
the data was first read is not enforced at all.

> **The batch is not a security token,** for the same reasons as the grade batch above, and the
> preflight is not proof that a review happened. Keep both server-side, or behind an opaque
> prepared-operation id, and derive `courseId`/`gradeItemId` from your own record of the linked
> course. The package's target checks catch plumbing mistakes; instructor authorization is yours.

Least-privilege Developer Key scopes for this feature:

```text
url:GET|/api/v1/courses/:course_id/assignments/:assignment_id
url:GET|/api/v1/courses/:course_id/assignments/:assignment_id/submissions/:user_id
url:POST|/api/v1/courses/:course_id/assignments/:assignment_id/submissions/:user_id/comments/files
url:PUT|/api/v1/courses/:course_id/assignments/:assignment_id/submissions/:user_id
```

Roster matching additionally needs the course-users scope, which the grade export already requires.

> **The batch is not a security token.** It is an ordinary object whose `userId` values mean
> whatever the process holding it says they mean. Resolve and post it within the same server-side
> request, or store it behind an opaque server-side prepared-operation id while the instructor
> reviews it. Never round-trip the object through a browser, and derive `courseId`/`gradeItemId` from
> your own record of the linked course rather than from anything the client sent. The course and
> assignment checks catch plumbing mistakes; they are not an authorization boundary.

`preflightGradeExport` exists because the posting policy is only useful *before* the write. Under an
automatic policy a generated comment is visible to the student the instant it lands, so learning
that from the response is learning it too late. Call it, show the instructor what is about to
happen, then pass the server-held result to `postGrades` as `preflight`. `postGrades` always reads
the assignment again immediately before writing. If the posting policy, grading type, points
possible, or assignment name changed during review, it refuses with `preflight-stale` and requires a
new review. Never accept an unsigned preflight object back from the browser as proof that review
happened.

Canvas applies the batch asynchronously, so `postGrades` returning means *accepted*, not
*applied*; `waitForProgress` tells you which. A `failed` job is returned rather than thrown,
because Canvas puts the students it couldn't grade in the message and that list is the point.

`postManually` is the assignment's posting policy, on both the preflight and the result. When
`true`, the grades **and comments** stay hidden from students until an instructor posts the
assignment in Canvas; when `false` they are visible immediately — which for generated feedback means
with no review step unless your application provides one. Surface it either way.

`matchCourseRoster` accepts either bare key strings or `{ appUserId, key }` records. Pass the
records if your application can hold the same PUID on two accounts: only an account id makes "one
person listed twice" distinguishable from "two accounts claiming the same student", and the second
is an ambiguity that must not resolve to a grade. A uniqueness constraint on the PUID column is the
better primary fix; this is the backstop.

`getCourseUsers` defaults to active and invited **student** enrollments and requests no optional
identity data. Canvas returns `integration_id`, `sis_user_id`, and `login_id` only to callers
permitted to read SIS data, so those may be absent on a roster that is otherwise complete — see
`rosterFieldCoverage` below. Pass only documented `include` values the application actually needs.

Hosted Canvas may redirect a file download from the configured Canvas origin to Instructure's
`*.inscloudgate.net` or `*.canvas-user-content.com` file hosts and, in some flows, to a signed
Amazon S3 object URL. The client follows those HTTPS redirects, but sends the Canvas bearer token
and cookies only to the Canvas origin. The initial download URL must still be on Canvas, and
credentials are never reattached after a redirect leaves it.

Self-hosted deployments using another trusted file service can add reviewed HTTPS hostname
suffixes when constructing the Canvas config:

```js
const canvasConfig = canvas.loadConfigFromEnv({
  tokenStore,
  getUserKey: (req) => req.user.id,
  allowedDownloadHostSuffixes: ['files.example.edu'],
});
```

An allowed suffix matches that hostname and its subdomains. External download hops must use HTTPS
on the standard port and never receive Canvas credentials, so keep this list as narrow as possible.

**Developer Keys with Enforce Scopes:** by default `downloadFile` requests the file's own Canvas
URL, `/files/:id/download`, with the bearer token. That is not an `/api/v1` path, so no scope can
cover it. A development Canvas refuses a scoped token there even though every API read works,
because two account flags that are off by default elsewhere are on in development
(`enable_file_access_with_api_tokens`, `disable_adding_uuid_verifier_in_api`). Hosted Canvas can
start refusing it whenever Instructure turns them on. Pass `via: 'public-url'` to avoid that path:

```js
const file = await canvas.downloadFile(req.canvasApi, courseId, fileId, {
  maxBytes: HOST_LIMIT_BYTES,
  via: 'public-url',
});
```

The package then asks `GET /api/v1/files/:id/public_url` for a time-limited signed link to the same
file and downloads that with no Canvas credentials: the link itself is the authorization, and Canvas
checks the token, the scope, and the user's access to the file before issuing it. The key needs both
of these:

```text
url:GET|/api/v1/courses/:course_id/files/:id
url:GET|/api/v1/files/:id/public_url
```

The course-scoped metadata lookup still runs first, so a link is only requested for a file Canvas
has confirmed belongs to the course, and the size, `maxBytes`, HTML, redirect, and host checks all
still apply. The link may start on one of the storage hosts above rather than on Canvas, and no hop
receives the token or cookies. Anyone holding the link could fetch that one file until it expires
(on hosted Canvas, up to a day), so the package never returns or logs it: error messages name the
host, never the link.

If Canvas refuses the `public_url` request with 401, 403, or 404 (a key without that scope, for
example), the download falls back to the file URL. If storage refuses the link with 401 or 403, as
it would an expired one, the package asks for one new link. It does not refresh the access token for
that, since the token was never sent. Without `via`, `downloadFile` makes the same requests it
always has.

Feedback uploads work the same way in the other direction: Canvas names the destination for the
bytes, and it is regularly one of those same Instructure or S3 hosts rather than Canvas itself. That
destination is checked against the upload allowlist before a single byte is sent, and it is
configured separately, because letting a host serve a file back is a smaller decision than letting
student feedback be sent to it:

```js
const canvasConfig = canvas.loadConfigFromEnv({
  tokenStore,
  getUserKey: (req) => req.user.id,
  allowedDownloadHostSuffixes: ['files.example.edu'],
  allowedUploadHostSuffixes: ['files.example.edu'],
});
```

An upload destination that is not on the list receives nothing, and the failure reports
`initialize-upload` — which is your evidence that no student's feedback left the server. There is no
permissive fallback; a new storage host has to be added here deliberately.

**Pagination:** Canvas ["will be paginated to 10 items by
default"](https://canvas.instructure.com/doc/api/file.pagination.html) and reports the rest only in
a `Link` header. All of the list operations above follow `rel="next"` and return the complete set,
so a course with 40 assignments gives you 40 grade items.

Calling the client yourself? Use `getAll` for a list endpoint and `get` for a single object:

```js
const students = await client.getAll('/courses/7/users', { enrollment_type: ['student'] });
const assignment = await client.get('/courses/7/assignments/8');
```

`getAll` requests `per_page=100` (pass your own `per_page` to override), throws instead of returning
a partial list if it exceeds `maxPages` (a request count, default 500, configurable per client or
per call — with the default `per_page` that's 50,000 rows), and
refuses to follow a `next` link to a different origin. Canvas puts "an unspecified limit" on
`per_page`, so treat the value as a request — `getAll` follows the `Link` header regardless of how
many rows a page actually comes back with.

> Upgrading from `0.2.0`: no resource function paginated before `0.3.0`, so an app that looked
> healthy was reading only the first 10 rows of every list. Signatures are unchanged — the same
> calls now simply return everything.

## Moodle

No OAuth — a user self-serves a `wstoken` from their own Moodle account (Preferences → Security
keys) and pastes it into your app. No expiry; valid until revoked from that same page.

**One-time Moodle admin setup:**

1. **Site administration → Advanced features** — enable Web Services.
2. **Plugins → Web services → Manage protocols** — enable REST.
3. **Plugins → Web services → External services** — create a service, whitelist:
   `core_webservice_get_site_info`, `core_enrol_get_users_courses`, `core_group_get_course_groups`.
   Add `core_course_get_contents` for files and `gradereport_user_get_grade_items` for read-only
   grades. Enable the service's **files download** option before using file downloads.
4. **Users → Permissions → Define roles → Authenticated user** — grant **both**
   `moodle/webservice:createtoken` and `webservice/rest:use` (two separate capabilities; missing
   either one breaks the connect flow).
5. Leave the service **unrestricted** (safe — every whitelisted function is scoped to the token
   holder's own data).

```js
const { moodle, createMongoTokenStore } = require('@ubc/ubc-genai-toolkit-lms-integration');

// Reads MOODLE_DOMAIN from process.env
const moodleConfig = moodle.loadConfigFromEnv({
  tokenStore: createMongoTokenStore(() => myDb.connect(), {
    collectionName: process.env.MOODLE_TOKEN_COLLECTION_NAME || 'moodle_tokens',
  }),
  getUserKey: (req) => req.user.id,
});

app.use(express.json());
app.use('/moodle/auth', moodle.createAuthRouter(moodleConfig)); // required — wires up connect/disconnect

// Not required setup — just an example of a route you'd add yourself, once
// connected, to actually use the Moodle connection.
app.get('/api/moodle/courses', moodle.requireAuth(moodleConfig), async (req, res) => {
  res.json(await moodle.getCourses(req.moodleApi));
});
```

| Route | Method | Purpose |
|---|---|---|
| `{basePath}/connect` | POST | Body `{ token }` — validates and stores the pasted key |
| `{basePath}/disconnect` | POST | Deletes the locally stored token (does not revoke it on Moodle's side) |

Only `moodle.requireAuth` exists — no `ensureAuth`, since there's no redirect URL to send a
browser to.

**Read APIs:**

- `moodle.getCourses(client)`
- `moodle.getCourseSections(client, courseId)`
- `moodle.getCourseUsers(client, courseId, { roleShortnames? })`
- `moodle.getCourseFiles(client, courseId, options?)`
- `moodle.downloadFile(client, courseId, fileId, { maxBytes? })`
- `moodle.getGradeItems(client, courseId, { userId?, groupId? })`
- `moodle.getGrades(client, { courseId, userIds?, groupId? })`

These return the same shared normalized shapes as Canvas. `getCourseSections` maps to Moodle's
**Groups**, not Moodle's own "sections" concept. `getCourseUsers` filters to the `student` role
client-side, since Moodle's web service returns every enrolled user; it needs
`moodle/site:viewuseridentity` for `email` and `idnumber`, and never populates `integrationId`,
which has no Moodle equivalent. Moodle grade reads require
`gradereport/user:view`; requesting all users also requires `moodle/grade:viewall`, and normal
Moodle course/group visibility rules still apply. These operations are read-only and throw
`moodle.MoodleApiError`.

## Shared exports

- **`TokenStore<T>`** — implement this to plug in a storage backend other than Mongo.
- **`createMongoTokenStore(db, options?)`** — ready-made Mongo backend. Use a distinct
  `collectionName` per provider — reusing one across providers overwrites the other's tokens.
- **`LmsError`** — base class for `canvas.CanvasOAuthError`/`canvas.CanvasApiError` and
  `moodle.MoodleApiError`, carrying a `provider` field for generic error handling.
- **`LmsCourse` / `LmsCourseSection`** — normalized courses and sections/groups.
- **`LmsRosterUser`** — a normalized person on a course roster, carrying the four fields worth
  matching on: `integrationId`, `sisId`, `loginId`, `email`. All are optional, because which ones
  a provider returns depends on the permissions of the token that read the roster. At UBC, Canvas
  `integrationId` holds the PUID — the identifier CWL authenticates against — which makes it the
  strongest key for matching a roster to CWL-authenticated accounts. Never match it against a
  student-number field; those are different namespaces.
- **`rosterFieldCoverage(users)` / `LmsRosterFieldCoverage`** — how many roster entries carried
  each identity field. Zero coverage across a non-empty roster usually means the token lacked
  permission to see the field, not that every person is missing a value. Check this before acting
  on who failed to match, and especially before offering to remove them.
- **`matchRosterByIntegrationId(courseId, roster, appUsers)` / `LmsRosterMatchReport`** — pairs a
  roster with your own users on `integrationId` alone, and reports the misses rather than guessing
  at them. Pure, so you can build the report once, show it to an instructor, and act on the same
  object you displayed. Prefer `canvas.matchCourseRoster`, which takes the course id from the read
  instead of a second argument that could disagree with it.
- **`LmsFile` / `LmsFileDownload`** — normalized course-file metadata and downloaded bytes.
  The package owns authenticated retrieval; the host app owns type/size policy, parsing, and
  persistence. Use `maxBytes` to enforce the host's download ceiling before parsing.
- **`LmsGradeItem` / `LmsGrade`** — normalized gradebook items, course totals, and user scores.
  Grade reads are server-side; grade writes are Canvas-only — see `canvas.postGrades`.
- **`LmsSubmission` / `LmsSubmissionAttachment`** — one student's work on one grade item, with its
  attachments listed but not downloaded. `body` is raw student-authored HTML and is not sanitized
  here.

Every normalized metadata object includes `.raw` (typed `unknown`) for provider-only fields.
Application identity and LMS identity remain separate: `requireAuth` proves that a usable LMS
credential exists, not that its owner is an instructor. Consumer apps must apply their own role
checks and ensure the connected LMS identity has access to the requested course and grade data.

## License

GPL-3.0
