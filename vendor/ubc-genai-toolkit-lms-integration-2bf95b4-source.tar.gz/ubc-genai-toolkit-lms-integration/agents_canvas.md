# LMS integration guide for coding agents

Use this file when adding Canvas or Moodle features to a Node/Express application with
`@ubc/ubc-genai-toolkit-lms-integration`. Adapt the examples to the host application. Do not copy
BiocBot paths or models blindly.

## Start with repository discovery

Before editing, inspect:

- `package.json`, lockfile, Node version, module system, and installed LMS package version.
- Express initialization, JSON parsing, session configuration, and route conventions.
- Authentication middleware and how the application represents user IDs and roles.
- User/course models, course ownership rules, database adapter, and index/migration conventions.
- Existing upload, parsing, storage, chunking, embedding, and retry services.
- Frontend conventions and test frameworks.
- The actual exports in the installed package. Do not assume an API exists because this guide
  mentions it.

The installed version matters more than usual, because several releases changed behaviour rather
than only adding to it:

- **`0.3.0`** made every Canvas list operation paginate. Before it they returned Canvas's first page
  of 10, with nothing in the body to say rows were dropped. Treat upgrading as a correctness fix,
  not a convenience.
- **`1.0.0`** removed `provider` from the normalized resource types, restricted the Canvas OAuth
  `returnTo` to same-site paths, and fixed a disconnect that failed for exactly the users whose
  tokens most needed clearing. TypeScript callers get a compile error for `course.provider`;
  **JavaScript callers get `undefined`**, so grep for `.provider` on those objects before upgrading.
- **`1.1.0`** added roster matching on `integration_id`, submission import, and the Canvas grade
  export.
- **`1.2.0`** added the Canvas submission-feedback PDF export, and the Canvas file-upload primitive
  underneath it.

If the version you need is not yet available from GitHub Packages, publish the package before
updating a consumer lockfile. Do not replace a registry dependency with a committed local
`file:../...` reference.

## Responsibility boundary

The package owns:

- Canvas OAuth, token refresh/revocation, and authenticated Canvas clients.
- Moodle token validation and authenticated Moodle clients.
- Provider URL construction, authenticated file retrieval, and Canvas's three-request file upload.
- Normalized course, section/group, roster, file, submission, grade-item, and grade types.
- Roster matching on the institutional identifier, and the match report every write is addressed
  through.
- Provider read operations, the Canvas write operations, and provider error classes.

The consumer application owns:

- Its accounts, sessions, roles, and business authorization.
- The stable application-user key used to store each user's LMS credential, and the institutional
  identifier (at UBC, the PUID) it matches students on.
- Course linking and local database models.
- UI, workflows, instructor confirmation, auditing, and data-retention rules.
- File-type/size policy, parsing, chunking, embeddings, and document persistence.
- Deciding what a grade is and what a feedback PDF says. The package transports them; it never
  generates, edits, or renders one.
- Persisting the outcome of every write against its own record ids, because no Canvas write here is
  idempotent.
- Grade-data minimization and authorization for every requested course/student.
- Progress reporting for long imports and exports.

Never reimplement OAuth, token refresh, provider REST clients, authenticated file downloading, or
Canvas's upload protocol inside the consumer when the installed package exports the operation. Never
move host-specific document ingestion or database writes into the provider package.

The one sanctioned reason to reach for the raw authenticated client (`req.canvasApi`,
`req.moodleApi`) is an endpoint the package does not wrap. The client is still the package's, so
token handling, refresh, and error classes are unchanged — but use `getAll` for list endpoints (see
[Pagination](#pagination)). Do not construct your own HTTP client, and do not fetch `raw.url` or a
submission attachment's `url` directly.

## Installation

The package is hosted on GitHub Packages. Commit only this project-level `.npmrc`:

```ini
@ubc:registry=https://npm.pkg.github.com
```

Put a personal token with `read:packages` in the developer or CI user's configuration, never in
the repository:

```ini
//npm.pkg.github.com/:_authToken=YOUR_GITHUB_TOKEN
```

Install and verify the version/exports:

```bash
npm install @ubc/ubc-genai-toolkit-lms-integration@^1.2.0
```

```bash
node -e "const p=require('@ubc/ubc-genai-toolkit-lms-integration'); console.log(typeof p.canvas.matchCourseRoster, typeof p.canvas.postGrades, typeof p.canvas.postSubmissionFeedbackPdfs)"
```

Requirements: Node 18 or newer, Express 4.18/5, a server-side token store, `express-session` for
Canvas OAuth, and `express.json()` for the Moodle token-connect route.

## Shared normalized API

```ts
interface LmsCourse {
  id: string;
  name: string;
  code: string;
  raw: unknown;
}

interface LmsCourseSection {
  id: string;
  name: string;
  courseId: string;
  raw: unknown;
}

interface LmsRosterUser {
  id: string;
  name: string;
  email?: string;
  /** Canvas `integration_id` — at UBC, the PUID. Moodle always leaves this undefined. */
  integrationId?: string;
  /** Canvas `sis_user_id` / Moodle `idnumber` — at UBC, the student number. */
  sisId?: string;
  /** Canvas `login_id` / Moodle `username`. */
  loginId?: string;
  raw: unknown;
}

interface LmsFile {
  id: string;
  courseId: string;
  name: string;
  filename: string;
  mimeType?: string;
  size?: number;
  createdAt?: string;
  updatedAt?: string;
  raw: unknown;
}

interface LmsFileDownload {
  data: Uint8Array;
  contentType?: string;
  filename?: string;
  size: number;
}

interface LmsGradeItem {
  id: string;
  courseId: string;
  name: string;
  maxScore?: number;
  dueAt?: string;
  raw: unknown;
}

interface LmsGrade {
  courseId: string;
  gradeItemId?: string;
  userId: string;
  score?: number;
  grade?: string;
  maxScore?: number;
  submittedAt?: string;
  gradedAt?: string;
  raw: unknown;
}

interface LmsSubmissionAttachment {
  id: string;
  filename: string;
  displayName: string;
  mimeType?: string;
  size?: number;
  /** Metadata only. Do not fetch this — see the submission import recipe. */
  url: string;
}

interface LmsSubmission {
  courseId: string;
  gradeItemId: string;
  userId: string;
  attempt?: number;
  workflowState: string;
  submittedAt?: string;
  late?: boolean;
  missing?: boolean;
  /** Text-entry submissions, as the raw HTML the LMS stores. A student wrote it. */
  body?: string;
  url?: string;
  attachments: LmsSubmissionAttachment[];
  score?: number;
  grade?: string;
  raw: unknown;
}
```

Treat `raw` as provider-specific and untrusted. Do not return it to browsers unless a reviewed
feature needs specific fields. `body` on a submission is untrusted markup written by a student —
sanitize it before rendering, and never inject it into a prompt without the same care.

None of these carry a `provider` tag. Every resource is reached through a provider-specific
namespace (`canvas.*` / `moodle.*`), so the caller already knows which LMS a result came from, and
the package never returns a mixed list. The ids are provider-scoped though, so an application that
persists or caches these must record the provider itself alongside them — see "Store the minimum
provider reference on the local course" below.

## Pagination

Canvas: "Requests that return multiple items will be paginated to **10 items by default**." A course
with 12 assignments or 11 students returns 10 rows and a `Link` header, with nothing in the body to
say rows were dropped. Silent truncation is the failure mode here, and it hides in local testing: a
fixture with five students is under the page limit, so everything looks correct until a real course
runs.

Do not hard-code a page size and assume it was honoured. Canvas documents "an unspecified limit to
how big you can set `per_page` to, so be sure to always check for the `Link` header" — there is no
published maximum, and a server may cap the value silently. Following `rel="next"` until it is
absent is the only correct termination condition.
See [Canvas's pagination docs](https://canvas.instructure.com/doc/api/file.pagination.html).

The package's Canvas resource functions — `getCourses`, `getCourseSections`, `getCourseUsers`,
`getCourseFiles`, `getSubmissions`, `getGradeItems`, `getGrades` — follow `rel="next"` and return
the complete list. Nothing extra is required to use them.

For a raw client call against a list endpoint, use `getAll`, not `get`:

```js
// Every page, per_page=100, Link-following handled for you.
const users = await req.canvasApi.getAll('/courses/7/users', { enrollment_type: ['student'] });

// One page only — correct for a single object, wrong for a list.
const assignment = await req.canvasApi.get('/courses/7/assignments/8');
```

`getAll` throws rather than returning a partial list when it hits the page ceiling
(`maxPages`, a count of requests rather than rows, default 500), and refuses to follow a `next` link
that points at a different origin.
Both are deliberate: a truncated roster or a bearer token sent to an attacker-supplied host are
worse outcomes than a failed request.

File downloads have a separate, constrained redirect policy. The metadata URL must begin on the
configured Canvas origin, but hosted Canvas may redirect the bytes through `*.inscloudgate.net`,
`*.canvas-user-content.com`, or a signed Amazon S3 object host. Those HTTPS hops are accepted
without ever forwarding Canvas bearer tokens, cookies, or host headers off-origin. Self-hosted
deployments can provide narrow `allowedDownloadHostSuffixes` in the Canvas config for another
reviewed file service; HTTP downgrades and unrecognized hosts remain blocked. Uploads have their own
allowlist — see [Uploads and the host allowlist](#uploads-and-the-host-allowlist).

`canvas.downloadFile(..., { via: 'public-url' })` downloads a signed link from
`GET /api/v1/files/:id/public_url` instead of the file's own URL. No hop of it receives the bearer
token or cookies, and it may start on one of those storage hosts rather than on Canvas; every other
check is the same. A 401 or 403 from storage gets one fresh link, not a token refresh.

Moodle needs none of this. Its web-service functions return the full result set in one call.

## Canvas configuration and routes

Required environment variables:

```env
CANVAS_DOMAIN=
CANVAS_CLIENT_ID=
CANVAS_CLIENT_SECRET=
CANVAS_REDIRECT_URI=
```

The ID/secret belong to a Canvas Developer Key, not a course or user. The redirect URI must exactly
match the Developer Key entry.

Configure least-privilege endpoint scopes for the endpoints the features in use actually call. The
package calls these and nothing else:

```text
GET  /api/v1/courses                                                          course selection
GET  /api/v1/courses/:course_id/sections                                      sections
GET  /api/v1/courses/:course_id/users                                         roster + matching
GET  /api/v1/courses/:course_id/files                                         file import
GET  /api/v1/courses/:course_id/files/:file_id                                file import
GET  /api/v1/files/:id/public_url                                             file import, via: 'public-url'
GET  /api/v1/courses/:course_id/assignments                                   grade items
GET  /api/v1/courses/:course_id/assignments/:assignment_id                    grades, both exports
GET  /api/v1/courses/:course_id/enrollments                                   course totals
GET  /api/v1/courses/:course_id/assignments/:assignment_id/submissions        grades, submissions
GET  /api/v1/courses/:course_id/assignments/:assignment_id/submissions/:user_id
POST /api/v1/courses/:course_id/assignments/:assignment_id/submissions/update_grades
GET  /api/v1/progress/:id                                                     grade export job
POST /api/v1/courses/:course_id/assignments/:assignment_id/submissions/:user_id/comments/files
PUT  /api/v1/courses/:course_id/assignments/:assignment_id/submissions/:user_id
```

File import on an Enforce Scopes key needs `via: 'public-url'` and
`url:GET|/api/v1/files/:id/public_url`. Without them the download itself goes to
`/files/:id/download`, which is not an `/api/v1` path: no scope can cover it, so Canvas can refuse
the token there while the file list and metadata reads succeed. A key that does not enforce scopes
needs nothing extra for `via: 'public-url'`, and a `public_url` request refused with 401, 403, or 404
falls back to the file URL.

Any feature that matches students needs the course-users scope. Without it Canvas returns 403 at
match time even though file import and grade reads both still work — a confusing failure, because
nothing about the reads suggests the roster is the missing piece.

```js
const { canvas, createMongoTokenStore } =
  require('@ubc/ubc-genai-toolkit-lms-integration');

const canvasConfig = canvas.loadConfigFromEnv({
  tokenStore: createMongoTokenStore(() => db, {
    collectionName: 'lms_canvas_tokens'
  }),
  getUserKey: req => {
    if (!req.user?.id) throw new Error('Application authentication required');
    return String(req.user.id);
  },
  basePath: '/api/lms/canvas/auth'
});

app.use(
  '/api/lms/canvas',
  requireApplicationAuth,
  requireLocalInstructorRole,
  canvasRoutes(canvas, canvasConfig)
);
```

Mount `canvas.createAuthRouter(canvasConfig)` at `/auth` inside that router. Use
`canvas.requireAuth(canvasConfig)` for JSON routes and `canvas.ensureAuth(canvasConfig)` only for
page routes that should redirect automatically. Both attach `req.canvasApi`.

Validate OAuth `returnTo` values as local absolute paths: they must start with `/` and not `//`.
Since `1.0.0` the router enforces this itself and falls back to `/`, including for an absolute
same-origin URL.

Two optional config fields widen the file host allowlists, and only self-hosted deployments should
need them: `allowedDownloadHostSuffixes` and `allowedUploadHostSuffixes`. They are separate on
purpose — see below.

## Moodle configuration and routes

Required environment variable:

```env
MOODLE_DOMAIN=
```

Moodle currently uses a user-pasted web-service token. Mount `moodle.createAuthRouter(config)` and
protect JSON routes with `moodle.requireAuth(config)`. There is no browser redirect middleware.

The Moodle external service must whitelist only the functions in use:

- `core_webservice_get_site_info`
- `core_enrol_get_users_courses`
- `core_group_get_course_groups`
- `core_course_get_contents` for course files
- `gradereport_user_get_grade_items` for read-only grades
- `core_enrol_get_enrolled_users` for the roster

Enable REST and the service's file-download option. Token users need `webservice/rest:use` plus the
course and grade capabilities required by Moodle. Reading all users' grades requires
`gradereport/user:view` and `moodle/grade:viewall`; Moodle group visibility rules still apply.

`core_enrol_get_enrolled_users` returns `email`, `username`, and `idnumber` only when the token's
account holds `moodle/site:viewuseridentity` and the site's `showuseridentity` setting includes
those fields. A token that can read grades can therefore still come back with every identity field
blank, which makes matching impossible rather than merely inaccurate. Detect that case explicitly
and tell the instructor which Moodle setting to change; do not silently report zero matches.

**Moodle is read-only in this package.** Roster matching, submission import, grade export, and
feedback export are all Canvas-only. Moodle rosters never carry an `integrationId`, so the matcher
in the next section cannot match one at all — do not wire it up and expect a partial result.

## Identity and authorization

Keep these identities distinct:

```text
application user -> token-store key -> connected Canvas/Moodle identity
```

An application instructor can connect a student LMS account. `canvas.requireAuth` and
`moodle.requireAuth` mean only that a usable credential exists. They do not prove an instructor
role.

Every instructor feature must combine:

1. Application authorization: local role plus ownership/management of the local course.
2. LMS authorization: the connected identity can access or manage the selected LMS course.

For Canvas course selection/linking, list courses with:

```js
canvas.getCourses(req.canvasApi, { enrollment_type: 'teacher' })
```

Reject a requested link unless its ID appears in that result. Moodle does not yet export a generic
`canManageCourse` helper; enforce the strongest available provider check and handle capability
errors without treating a stored token as proof of instructor status.

LMS user IDs are provider-scoped. Never join them to application users by numeric ID, and never
treat a matched identifier as authentication — it decides which row a grade is filed under, not who
is allowed to sign in. Matching is described in the next section.

## Roster matching (identity mapping)

Grades and submissions arrive keyed by an LMS user ID, and the application stores them against its
own user ID, so something has to decide who is who. Get this wrong and one student's marks — or one
student's written feedback — appear on another student's record. Treat matching as a first-class,
inspectable step, not a side effect of an import or an export.

Make it a separate, explicit action. The instructor runs "match students", reads the result, fixes
what is wrong, and only then imports or exports. Folding matching into the operation hides exactly
the step that needs review, and re-running to pick up a roster change becomes impossible to reason
about.

### One key, on purpose

The package matches on **Canvas `integration_id` only**, surfaced as `integrationId`. At UBC this
holds the student's PUID — the identifier CWL authenticates against, which makes it both universally
populated and the same value a CWL-authenticated account already stores.

There is deliberately no fallback key, and adding one in the consumer would undo the reason:

- **Email** is the tempting fallback, and it is a plausible match rather than a certain one. Where
  the application lets people register with a personal address, the two sides hold genuinely
  different values for the same person.
- **Student number** (`sisId` — Canvas `sis_user_id`, Moodle `idnumber`) is authoritative when both
  sides have it, but not every account has one. It is also a different namespace from the PUID;
  comparing across the two is a false match waiting for a collision.
- **Username/login** (`loginId`) and email-local-part heuristics are weaker again.
- **Display name is never evidence.** "J. Smith", "Jane Smith", and a second Jane Smith in the same
  section are exactly the ambiguity that silently misfiles a grade. A name is fine as a label on a
  match an instructor is reviewing.

The costs are not symmetric: an unmatched student is a line in a report someone reads, while a
mis-matched one is a grade or a piece of feedback filed against the wrong person. `sisId`, `email`,
and `loginId` are still normalized onto every roster entry, so a consumer that has a reviewed reason
to use one can — but that becomes the consumer's decision to defend, and the export functions will
not accept a report built any other way.

### Building the report

```js
const { canvas, moodle, rosterFieldCoverage } = require('@ubc/ubc-genai-toolkit-lms-integration');

// Preferred: reads the roster and matches in one call, so the report's courseId
// comes from the read that produced it.
const report = await canvas.matchCourseRoster(req.canvasApi, externalCourseId, appUsers);

// Roster only, if you want to inspect it before matching.
const users = await canvas.getCourseUsers(req.canvasApi, externalCourseId);
const moodleUsers = await moodle.getCourseUsers(req.moodleApi, externalCourseId);
const coverage = rosterFieldCoverage(users);
```

`appUsers` is an iterable of either bare key strings or `{ appUserId, key }` records. Use the record
form wherever the application can hold the same key on two accounts: with bare strings an identical
key repeated is one person, while with account ids two accounts claiming one student is an ambiguity
that must not resolve to a grade. Keys are compared trimmed and case-insensitively, so two
application keys differing only by case are ambiguous rather than silently merged.

Prefer `matchCourseRoster` over calling `getCourseUsers` and `matchRosterByIntegrationId`
separately. The report carries the course whose roster produced it, and a report carrying the wrong
course id is precisely what lets a grade computed for one course be posted against another — the
same person is the same Canvas user id in both, and nothing downstream would catch it.

Both providers' `getCourseUsers` default to students only (`enrollment_type: ['student']` and
`enrollment_state: ['active', 'invited']` on Canvas, the `student` role shortname on Moodle) and
both read the whole roster — the Canvas call paginates internally, so there is no `get`/`getAll`
decision left to get wrong. Pass `enrollmentTypes` / `enrollmentStates` / `roleShortnames` to widen
the filter, and `include` to add Canvas `include[]` values. Moodle users carrying no visible roles
are kept rather than dropped, since an empty `roles` array means the token could not read role
assignments, not that the person holds none.

### Reading the report

```ts
interface LmsRosterMatchReport {
  courseId: string;                  // stamped from the read
  matched: LmsRosterMatch[];         // { key, appUserId?, lmsUserId, name, matchedBy }
  appOnly: LmsAppOnlyUser[];         // { key, appUserId?, reason, formerEnrollment? }
  rosterOnly: LmsRosterOnlyUser[];   // { lmsUserId, name, key? }
  coverage: LmsRosterFieldCoverage;  // { total, integrationId, sisId, email, loginId }
  ambiguous: LmsAmbiguousKey[];      // { key, lmsUserIds, appKeys, appUserIds? }
}
```

`matched`, `appOnly`, and the application-side keys in `ambiguous` are **disjoint** and together
account for every distinct key supplied, so the counts can be rendered to a human without
double-counting anyone. Report both unmatched directions: `rosterOnly` is informational — on a
partially adopted course it is most of the class — while `appOnly` is the list that matters on
export, because each entry is a grade with nowhere to go.

`ambiguous` reports both id lists because they mean different things: two `lmsUserIds` is a
duplicate account in the LMS, two `appKeys` or `appUserIds` is a duplicate in the application, and
the fix differs. Neither resolves to a write.

`matchedBy` is always `'integrationId'` today. It is recorded anyway so that an instructor looking
at an unexpected grade can see the evidence behind the link, and so that adding a weaker key later
cannot silently change what an existing match meant. Show it in the UI.

### Absent fields are not absent people

Canvas serializes `integration_id`, `sis_user_id`, and `login_id` only for callers permitted to read
SIS data, and that permission is an account-level role configuration. An instructor token can return
a complete, correct roster in which all three are empty. Moodle gates `email` and `idnumber` behind
`moodle/site:viewuseridentity` the same way.

This matters because the symptom is indistinguishable from a real roster difference: everyone comes
back unmatched, exactly as they would if none of them had signed up. Check `report.coverage`
against `total` before drawing conclusions, and never offer a destructive action — removing people,
marking them dropped — off a roster whose coverage is low. The export functions refuse outright with
`roster-coverage` when a non-empty roster carried no `integrationId` at all, rather than reporting
"0 of 240 matched" and inviting someone to conclude the application's records are wrong.

A test account with the field deliberately populated is the cheapest way to tell "not permitted"
apart from "not populated"; without one, a staging roster of hand-created users will show empty
fields for both reasons and look identical.

### Why someone is missing: `explainUnmatched`

`getCourseUsers` returns only active and invited enrollments, so a student who dropped in week 8 is
simply absent — identical, from the caller's side, to someone who was never in the course. One is a
person whose grade no longer has anywhere to go; the other is usually a linked-course mistake.

```js
const explained = await canvas.explainUnmatched(req.canvasApi, externalCourseId, report);
// Each appOnly entry's reason becomes 'enrollment-ended' (with formerEnrollment
// attached) or 'not-enrolled', instead of 'unknown'.
```

One extra request, reading `completed`, `inactive`, and `rejected` enrollments. It throws if the
report was built from a different course. Skipping it is honest rather than wrong — every `appOnly`
entry just stays `unknown` — but "3 students dropped after week 8" and "you linked the wrong course"
are worth telling apart before an instructor acts on the list.

### Rules that keep it honest

- A key held by two application accounts matches neither. It is reported as ambiguous, not attached
  to whichever row was read first.
- One LMS person maps to at most one application user, and vice versa. A second LMS row claiming an
  already-matched account is a duplicate account in the LMS — reported, never overwritten.
- Record `matchedBy` alongside the mapping and show it in the UI.
- Delete mappings for LMS users no longer on the roster on every run, so a student who dropped the
  course stops appearing.
- Report both unmatched directions with counts. "22 of 25 matched" next to the numbers is the
  difference between a trustworthy view and a misleading one.

Store one mapping document per LMS identity, with unique indexes on both
`(courseId, provider, externalCourseId, externalUserId)` and
`(courseId, provider, externalCourseId, localUserId)`. The second index is what makes a duplicate
match a loud failure instead of a quiet overwrite.

Roster data is personal information. Read it only when an instructor asks to match, keep only the
fields the mapping and its audit trail need, and do not log it. A PUID is an identifier, not a
secret, but it does not belong in logs or error messages either — the package's own refusals never
contain one.

## Course-link persistence

Store the minimum provider reference on the local course:

```js
{
  provider: 'canvas',
  courseId: '123',
  name: 'Example course',
  code: 'EXAM101',
  linkedAt: new Date(),
  linkedBy: applicationUserId
}
```

Authorize the local course before reading or changing the link. Revalidate the connected LMS
identity's access when linking and before sensitive operations; do not trust a stale database link
alone. Every write path below derives its `courseId`/`gradeItemId` from this record — never from
anything the client sent.

## File import recipe

Provider calls:

```js
const files = await provider.getCourseFiles(req.lmsApi, externalCourseId, options);
const downloaded = await provider.downloadFile(
  req.lmsApi,
  externalCourseId,
  externalFileId,
  // `via` is Canvas-only; Moodle ignores it. See "Canvas configuration and routes".
  { maxBytes: HOST_LIMIT_BYTES, via: 'public-url' }
);
const buffer = Buffer.from(downloaded.data);
```

The consumer must then:

1. Authorize the local course and revalidate LMS course access.
2. Allowlist MIME types and reject declared files above the host limit.
3. Download with `maxBytes`; do not fetch `raw.url` directly or expose tokens.
4. Deduplicate on provider + external course ID + external file ID.
5. Pass the bytes into the host's existing upload/ingestion service.
6. Persist origin metadata such as provider, external IDs, source update time, and import time.
7. Preserve the existing parser, chunker, embeddings, vector store, and local course/unit link.

Use a unique partial database index for imported LMS files. Keep its name and options stable once
deployed; changing a partial filter under the same index name makes MongoDB reject startup. If the
definition must change, implement an explicit reviewed migration rather than dropping an index at
ordinary application startup.

## Submission import recipe

Course files are what an instructor published. Submissions are what students handed in, and they are
the input an application actually grades. Canvas only.

```js
const submissions = await canvas.getSubmissions(req.canvasApi, {
  courseId,
  gradeItemId,
  // Canvas user ids from report.matched — narrows the result, not the request.
  userIds: report.matched.map(m => m.lmsUserId),
});

const resolved = canvas.resolveSubmissions(report, gradeItemId, submissions);
// resolved.matched:    [{ key, appUserId?, submission }]
// resolved.unresolved: [{ lmsUserId, reason: 'no-app-account' | 'ambiguous-key' }]

const file = await canvas.downloadSubmissionAttachment(req.canvasApi, {
  courseId,
  gradeItemId,
  userId: submission.userId,
  attachmentId: attachment.id,
  maxBytes: HOST_LIMIT_BYTES,
});
```

What the package does, and what it leaves to you:

- **Attachments are listed, not fetched.** A course-wide submission read would otherwise pull every
  file in the class to answer "who submitted?". Download the ones you need, one at a time.
- **`maxBytes` is required** on the attachment download, unlike on course files. The bytes are
  student-uploaded and buffered whole in memory, so the ceiling is a decision the host makes rather
  than inherits. The download also fails `502` if the received size disagrees with the size Canvas
  declared.
- **The attachment is named, not linked.** Pass course, assignment, user, and attachment ids and let
  Canvas produce the URL. A URL handed in from outside proves only that it points at Canvas — not
  that the file belongs to this course, this assignment, or this student. Never fetch
  `attachment.url` yourself.
- **Unsubmitted placeholders are excluded** unless you pass `includeUnsubmitted: true`. Canvas
  returns a row for every student who has not submitted; a caller asking for submissions usually
  means the work that exists.
- **`userIds` filters client-side.** Canvas's per-assignment submissions endpoint has no server-side
  user filter, so every page is read either way. It narrows what you handle, not what you fetch.
- **`resolveSubmissions` is the import-side counterpart to the export resolvers.** It re-keys
  submissions from Canvas user ids to the application's own identifiers and validates course and
  assignment on every row. Without it every caller writes the same join by hand, and the failure is
  quiet: an unresolved submission is a student whose work the application will never see, which
  looks identical to a student who did not submit.
- It throws `canvas.CanvasGradeExportError` (the shared class, despite the name) with
  `roster-coverage`, `course-mismatch`, or `assignment-mismatch`.

Store `attempt` with whatever you generate from a submission. The feedback export verifies it, and
without it you cannot tell later which draft your feedback was actually about.

## Import UI

An import asks four questions — who are you, which course, which file, where does it go — and the
answers are mostly one-time. Rendering all of that inline puts a permanent configuration panel on
top of a page whose actual job is something else, and a second provider doubles it.

- Put one small launcher per provider on the page, and the workflow in a modal.
- Drive both providers from one parameterized module, not one file per provider. Canvas and Moodle
  differ in three places: how you connect (redirect vs pasted token), the request field names, and
  the label. Everything else is identical, and duplicating it means every later fix lands twice.
- Probe each provider's `/status` on load. `401` means "configured, not connected" — show the
  launcher with that state. `404` means the deployment has no credentials for that LMS at all, so
  render nothing; do not advertise an LMS this institution does not run.
- Skip steps that are already answered. An instructor who connected last week should open the modal
  on "choose a course", not on a connect button they have no reason to press.
- Number the steps and show which one is current. "Step 2 of 4 · Choose the course" tells an
  instructor how much is left; a bare form does not.
- Canvas OAuth navigates away and comes back. Put a marker in the `returnTo` path, and reopen the
  modal on that marker so the instructor lands back in the flow instead of on a blank page. The
  `returnTo` must still validate as a local absolute path.
- Read the choices back before the irreversible step. A short summary of course, file, and
  destination costs one screen and prevents importing the wrong file into the wrong unit.

## Progress streaming for long imports

A file import is one request that does several slow things: fetch from the provider, store the
original, extract text (potentially with per-image LLM description), persist, chunk, and embed. A
single spinner for all of it tells the instructor nothing about where the minutes went, and nothing
about which stage failed. The same is true of a feedback export across 200 students.

Stream the stages. Newline-delimited JSON over the same POST is enough — no SSE, no WebSocket, no
job queue:

```js
// Server: opt in only when the client asks for it, so existing JSON callers
// and tests keep the single-shot 201 response unchanged.
const wantsStream = String(req.get('accept') || '').includes('application/x-ndjson');
```

Rules that make this safe:

- **Open the stream last.** Headers commit the response to `200`. Every check that deserves a real
  status code — 400 bad input, 403 wrong instructor, 404 missing file, 409 already imported — must
  run before the first byte goes out. After that, failures are reported in band as a terminal
  `{"type":"error"}` line, and the client has to read the last event rather than trust the status.
- **Name stages on the server, label them on the client.** Send `{"type":"step","step":"extract"}`
  plus any detail only the server knows (bytes downloaded, characters extracted, chunks stored).
  Wording, ordering, and translation stay a UI concern.
- **Emit from the ingestion service, not the route.** Give the host's existing ingestion function an
  optional `onProgress` callback and have the route forward it. The route then reports real stage
  transitions instead of guessing at elapsed time, and every other caller of that service is
  unaffected. Wrap the callback so a throwing listener cannot fail an import that is otherwise
  succeeding. The feedback export takes `onItemComplete` for the same purpose and already ignores
  what it throws.
- **Do not fake progress.** A timer that advances a bar because eight seconds passed is worse than
  no bar: it reports success while the request is dying.
- **Check the response path for buffering.** Compression middleware or a proxy that buffers will
  hold every line until the request ends. Set `Cache-Control: no-store` and `X-Accel-Buffering: no`,
  and verify against the real deployment, not just localhost.
- **Handle split lines on the client.** A network chunk can end mid-object; buffer the tail until
  its newline arrives.

The same stages give you the failure UI for free: mark the stage that was active when the error
arrived, and the instructor sees "failed while extracting text" rather than "import failed".

## Read-only grade recipe

Canvas:

```js
const items = await canvas.getGradeItems(req.canvasApi, courseId);
const totals = await canvas.getGrades(req.canvasApi, { courseId });
const scores = await canvas.getGrades(req.canvasApi, {
  courseId,
  gradeItemId,
  userIds: allowedCanvasUserIds
});
```

Moodle:

```js
const items = await moodle.getGradeItems(req.moodleApi, courseId);
const grades = await moodle.getGrades(req.moodleApi, {
  courseId,
  userIds: allowedMoodleUserIds,
  groupId
});
```

Canvas needs one call per grade item plus one for enrollment totals, so a course with thirty
assignments makes thirty-one requests. Moodle returns every item for the course in one call. Budget
for that difference before adding a per-item view.

Grade data is sensitive educational information. Keep these calls server-side, authorize the
course on every request, request only necessary users/items, avoid logging payloads, return only
fields the UI needs, and apply the application's retention/audit policy.

### Storing and showing a snapshot

- An import is a point-in-time snapshot, not a live view. Store `importedAt` with it and put that
  timestamp next to the numbers, or an instructor will read a stale figure as current.
- Key every stored grade on the application user ID from the identity mapping, and drop rows whose
  mapping no longer exists. Rows keyed only by an LMS user ID become orphans the moment a roster
  changes.
- Replace the previous snapshot rather than accumulating one row per import, unless the application
  has a stated reason to keep history and a retention rule to match.
- Show grades on the record they belong to — the student's own row or card — not in a separate table
  the instructor has to cross-reference by name. A detached grade table is where mismatches hide.
- Show unmatched students where the grades are shown. "22 of 25 matched" next to the numbers is the
  difference between a trustworthy view and a misleading one.
- An import against a course with no mappings will succeed and store nothing. Say so plainly and
  point at the matching step; a silent success here reads as "the LMS has no grades".

## Writing back to Canvas

Everything above reads. From `1.1.0` the package also writes: grades and comments to an assignment,
and from `1.2.0` a feedback PDF onto each student's submission. Moodle has no write path.

Every write follows the same three steps, and they are separate on purpose:

```text
resolve  (pure, no network)   who is about to be written to, and who is about to be skipped
preflight (reads, no write)   every check plus the assignment's posting policy
write    (side effects)       runs a fresh preflight again, then sends
```

The middle step exists because the posting policy is only actionable **before** the write. Under an
automatic posting policy a generated comment or an attached PDF is visible to the student the
instant it lands, so learning that from the response is learning it too late. Call the preflight,
show the instructor what is about to happen, then pass the server-held result back into the write.

The write always repeats the preflight itself and compares. A preflight object is not proof that a
review happened — it is an ordinary object, forgeable if it ever crosses a trust boundary, and a
legitimate one goes stale while an instructor reads it. When the reviewed state no longer matches,
the write is refused as `preflight-stale` and a fresh review is required.

> **A batch is not a security token.** It is an ordinary mutable object whose `userId` values mean
> whatever the process holding it says they mean. Resolve and write within the same server-side
> request, or hold it server-side behind an opaque prepared-operation id while the instructor
> reviews. Never round-trip a batch or a preflight through a browser, and derive
> `courseId`/`gradeItemId` from the application's own record of the linked course. The package's
> target checks catch plumbing mistakes; instructor authorization is the consumer's job.

Two refusals are worth understanding before either recipe, because both describe a write that would
succeed against Canvas while being wrong:

- **`course-mismatch`** — the batch was resolved against a different course's roster. The same
  person is the same Canvas user id in every course they take, so nothing downstream would catch it.
- **`assignment-mismatch`** — the batch was computed for a different assignment in the same course.
  Canvas checks only that the assignment belongs to the course, so Lab 1's scores or Lab 1's
  feedback land on Lab 2 without complaint. This is why the batch carries the assignment it was
  computed for, not just the course.

And one that is about the UI rather than the data: **`partial-export`**. If anything is unresolved,
the write is refused unless you pass `allowPartial: true`, because a partial export is only visibly
partial if the surrounding UI remembers to render the skipped list. "23 of 25 students graded" is
not something an instructor should have to notice on their own.

## Grade export recipe

```js
const report = await canvas.matchCourseRoster(req.canvasApi, courseId, appUsers);

const batch = canvas.resolveGradeWrites(report, gradeItemId, [
  { key: student.puid, postedGrade: 17.5, comment: 'Nicely argued.' },
  { key: other.puid, excuse: true },
]);
// batch.unresolved: [{ key, reason: 'no-roster-match' | 'ambiguous-key' | 'duplicate-key' }]

const preflight = await canvas.preflightGradeExport(req.canvasApi, {
  courseId, gradeItemId, batch,
});
// Show the instructor: preflight.assignmentName, preflight.postManually,
// preflight.maxScore, preflight.gradingType, and batch.unresolved.

// Only after the instructor confirms:
const queued = await canvas.postGrades(req.canvasApi, {
  courseId, gradeItemId, batch, preflight,
});
const done = await canvas.waitForProgress(req.canvasApi, queued.progressId);
```

Notes that change how you write the surrounding code:

- **`postedGrade` can be points, a percentage (`'88%'`), a letter (`'A-'`), or pass/fail.** Canvas
  parses it according to the assignment's own grading type, so the application does not have to know
  which is in use. Every write must carry at least one of `postedGrade`, `comment`, or `excuse`.
- **It is one bulk request, not one per student.** A course of 300 is a single round trip, and
  Canvas reports per-student failures for the batch rather than leaving a half-finished export
  behind.
- **A successful return means accepted, not applied.** Canvas queues the batch; pass `progressId`
  to `waitForProgress` to find out which. That function returns on `failed` rather than throwing,
  because Canvas puts the students it could not grade in the job's message and that list is the
  point. Only running out of time throws (`CanvasApiError` 504; 60s default, configurable via
  `timeoutMs`/`pollIntervalMs`).
- **`postGrades` returns `postManually`** alongside the job. Surface it either way — the instructor
  should not have to guess whether the comments they just sent are already visible.
- **Duplicate keys are dropped, not merged.** Two rows for one student mean the application does not
  agree with itself about the score; whichever arrived last would win in `grade_data` and nobody
  would see the other, so neither is written.

`canvas.CanvasGradeExportError` is thrown before anything reaches Canvas, with `reason` one of:
`roster-coverage`, `course-mismatch`, `assignment-mismatch`, `empty-batch`, `partial-export`,
`invalid-grade`, `preflight-stale`, `unsupported-grading`. `empty-batch` is not pedantry: Canvas
accepts an empty `grade_data` and reports success, which reads as "grades exported".
`unsupported-grading` covers anonymous and moderated assignments, where Canvas does not accept
grades addressed by user id.

## Feedback PDF export recipe

Attaches one application-generated PDF to each student's submission as an instructor comment. It
starts **after** the application has generated the feedback and an instructor has approved it — this
package neither creates nor edits PDFs. v1 is PDF-only, Canvas-only, and one file per student.

```js
const batch = canvas.resolveSubmissionFeedbackWrites(
  report,
  gradeItemId,
  approved.map(feedback => ({
    feedbackId: feedback.id,          // your record id; every result and error names it
    key: feedback.puid,               // your identifier, never a Canvas user id
    attempt: feedback.canvasAttempt,  // the imported attempt this feedback is about
    filename: 'feedback.pdf',
    data: feedback.pdfBytes,          // Uint8Array or Buffer
    textComment: 'Your written feedback is attached.',
  })),
  { maxBytesPerFile: 10 * 1024 * 1024 }
);

const preflight = await canvas.preflightSubmissionFeedbackExport(req.canvasApi, {
  courseId, gradeItemId, batch,
});
// Show the instructor: preflight.fileCount, preflight.totalBytes,
// preflight.assignmentName, preflight.postManually, and batch.unresolved.

// Only after the instructor confirms:
const result = await canvas.postSubmissionFeedbackPdfs(req.canvasApi, {
  courseId, gradeItemId, batch, preflight,
  concurrency: 3,                       // 1..10, defaults to 3
  onItemComplete: r => stream.write(JSON.stringify(r) + '\n'),
});
```

### What the export guarantees, and what it does not

**The attempt is verified before any byte is uploaded.** Canvas will happily accept feedback written
about a first draft against a resubmission, and neither the instructor nor the student can see that
it happened. The export re-reads the submission with `submission_history` and refuses the item if
the named attempt is not there. This is why the submission importer's `attempt` must be persisted.

**`preflight.batchFingerprint` covers the files themselves**, not just the target: every feedback
id, student, attempt, filename, comment text, and a hash of every PDF, each field length-prefixed.
The export recomputes it immediately before the first upload, so a file swapped after approval — or
a posting policy changed during review — is refused as `preflight-stale` rather than uploaded.

**Every PDF is validated twice**, at resolution and again before the write: a `.pdf` filename with
no path separators or control characters, non-empty bytes within `maxBytesPerFile`, and a real
`%PDF-` signature in the first 1 KB. The filename and content type are supplied by the caller, so
neither is evidence of what the file actually is. The batch is mutable, so a limit enforced only
where the data was first read is not enforced at all.

**There is no atomic or exactly-once behaviour, and none is claimed.** Canvas exposes no idempotency
key for a submission comment. Once the first upload starts, per-student outcomes replace exceptions:
`result.results` has one entry per `batch.writes` entry, **in that order** regardless of completion
order, so one bad PDF does not erase the record of the students who succeeded.

Each entry is `attached`, `failed`, `unknown`, or `not-attempted`, with the `stage` that stopped it
(`verify-submission`, `initialize-upload`, `upload-bytes`, `confirm-upload`, `attach-comment`).
Persist `feedbackId` with the outcome. Three states need handling beyond a log line:

- **`unknown`** — the connection failed during the comment write itself. Canvas may have created the
  comment before it dropped, so there is no safe automatic retry: re-running blind can leave a
  student with two copies of their feedback. Reconcile these by hand.
- **`failed` at `attach-comment`** — carries a `fileId`. The PDF is in Canvas with nothing pointing
  at it; that id is what makes the orphan findable.
- **`not-attempted`** — the export stopped before reaching that student, after Canvas rejected the
  credentials. Nothing was sent for them. Losing authorization is a fact about the export rather
  than about one student, so the run stops instead of producing 280 identical errors.

> **Students may see this immediately.** `postManually: false` means the PDF is downloadable by the
> student the moment it is attached. Show `preflight.postManually` before the instructor confirms,
> not after.

`canvas.CanvasSubmissionFeedbackError` is thrown before the first upload, with `reason` one of:
`roster-coverage`, `course-mismatch`, `assignment-mismatch`, `empty-batch`, `partial-export`,
`invalid-feedback`, `preflight-stale`, `unsupported-grading`, `unsupported-group-assignment`. Group
assignments are refused deliberately: whether one PDF belongs to one student or to a whole group is
a product decision, and Canvas would silently pick one. Refusal messages name the stage and the safe
ids needed to diagnose them, and never a token, signed upload parameter, signed URL, PUID, PDF
content, or feedback text — keep it that way in anything the consumer logs.

## Uploads and the host allowlist

`ApiClient.uploadFile(path, file)` implements Canvas's three-request upload protocol: Canvas
negotiates the destination, the bytes go there as `multipart/form-data` with every signed
`upload_params` field copied verbatim and the file last, and the result is confirmed back on the
Canvas origin. `postSubmissionFeedbackPdfs` is built on it.

It is **not** a general-purpose uploader, and should not be used as one. The destination is never a
caller argument — it comes from the authenticated response to `path` — so it cannot be turned into
"POST these bytes anywhere".

- The Canvas bearer token and cookie jar are **never** sent to an upload destination, which Canvas
  itself requires ("the access token is not sent with this request"). Credentials return only for a
  confirmation URL on the exact configured Canvas origin, and a confirmation that bounces through
  another storage host does not regain them.
- Destinations are matched on label boundaries, so `canvas-user-content.com.attacker.test` is not a
  match. Instructure's gateway (`*.inscloudgate.net`), `*.canvas-user-content.com`, and signed
  Amazon S3 object hosts are permitted already.
- HTTP, nonstandard ports, and URLs carrying embedded credentials are rejected before any byte is
  sent. A rejected destination reports stage `initialize-upload`, which is the caller's evidence
  that nothing left the server.
- `allowedUploadHostSuffixes` on the Canvas config widens it for a self-hosted deployment. It is
  **separate from `allowedDownloadHostSuffixes` on purpose**: the two usually hold the same values,
  but permitting a host to serve a file back is a smaller decision than permitting student feedback
  to be sent to it, and a deployment should be able to make the first without silently making the
  second.

`canvas.CanvasUploadError` extends `CanvasApiError`, so existing Canvas HTTP handling still catches
it. The addition is `stage`, which is what tells "nothing was sent" from "the bytes are in Canvas
but unattached".

## Error and token-expiry behavior

- Handle `canvas.CanvasApiError`, `moodle.MoodleApiError`, and shared `LmsError` centrally.
- Handle the refusal classes separately from HTTP failures — nothing failed, the operation was
  stopped on purpose, and `reason` says which check stopped it:
  - `canvas.CanvasGradeExportError` (also thrown by `resolveSubmissions`)
  - `canvas.CanvasSubmissionFeedbackError`
  - `canvas.CanvasUploadError` (a `CanvasApiError` with a `stage`)
- A Canvas 401 may trigger one package-managed refresh/retry. If refresh fails, require reconnect.
- Moodle invalid-token responses should clear the stored credential through the configured hook.
- Map provider 401/403/404/413 responses to useful application errors without leaking tokens,
  secrets, request headers, raw grade payloads, PUIDs, feedback text, or provider internals.
- Do not retry permission errors. Retry only bounded, transient failures and only when the
  operation is safe/idempotent — which excludes every write in this package. An `unknown` feedback
  result is specifically the case where retrying is unsafe.

## Tests and acceptance criteria

At minimum, test:

- no token, expired/revoked token, refresh success, refresh failure, and disconnect;
- application role denial and local course-ownership denial;
- connected LMS identity without teacher/grade permission;
- cross-course link/import/grade attempts;
- provider errors and malformed/non-file download responses;
- same-origin redirect enforcement and download byte limits;
- duplicate imports and database-index behavior;
- existing upload ingestion still parses, stores, chunks, and indexes files;
- grade responses expose only requested users/items;
- no credential, PUID, or student-grade data appears in logs or browser-visible errors.

For roster matching, test that:

- a match on `integrationId` produces `matchedBy: 'integrationId'`, and nothing else matches;
- a key shared by two application accounts is reported ambiguous and matches neither;
- a second LMS row claiming an already-matched account is reported, not silently overwritten;
- identical display names with no shared `integrationId` produce no match at all;
- `matched`, `appOnly`, and ambiguous app keys stay disjoint;
- mappings for students no longer on the roster are removed;
- `explainUnmatched` separates `enrollment-ended` from `not-enrolled`, and refuses another course's
  report;
- a roster with every identity field blank fails loudly instead of reporting zero matches.

For the write paths, test that:

- a batch resolved against another course, or computed for another assignment, is refused;
- an empty batch is refused rather than reported as a successful export;
- unresolved entries are refused without `allowPartial`, and exported with it;
- a preflight taken with `allowPartial: true` does not carry that permission into a write that did
  not ask for it;
- a posting policy, grading type, points possible, or assignment name changed between preflight and
  write is refused as `preflight-stale`;
- a PDF swapped after the preflight is refused as `preflight-stale` via `batchFingerprint`;
- feedback naming an attempt the student does not have is refused at `verify-submission`, before
  any upload;
- a non-PDF with a `.pdf` name, an oversized file, and a filename with a path separator are all
  refused;
- a group assignment and an anonymously graded assignment are refused;
- a mid-run failure yields per-student results in `batch.writes` order, not an exception;
- an `attach-comment` failure carries `fileId`, and a dropped connection during it reports
  `unknown` rather than `failed`;
- a 401/403 mid-run marks the remaining items `not-attempted`;
- an upload destination off the allowlist is refused at `initialize-upload` with no bytes sent, and
  no bearer token or cookie is present on any off-origin request;
- a throwing `onItemComplete` does not fail an export in flight.

For progress streaming, test that:

- the stage sequence and terminal `done` event arrive in order;
- a failure after the stream opens arrives as an in-band `error` event on a `200` response;
- validation errors before the stream opens still return their real status code;
- a client that does not ask for NDJSON still receives the original single JSON response.

Feature acceptance requires a real local/provider smoke test in addition to mocks. For matching,
that smoke test must include at least one student who should not match, since a run where
everything matches proves nothing about the failure path. For the feedback export, it must include
one student whose submission has been replaced since the feedback was generated.

## Local environments

For Canvas, `lthub/canvas-dev-only` can provide a local instance. Create a local Developer Key and
register the exact consumer callback URI. The package supports the image's `canvas.docker` file
redirect while connecting through a localhost URL.

For Moodle, use `https://github.com/ubc/moodle-docker`. Enable REST/web services, create the
least-privilege service, whitelist the functions above, enable file downloads, assign required
capabilities, and generate a token for the test user.

Seed local fixtures with a script rather than clicking through both LMSs by hand: create the test
students on the provider, create the matching application accounts, and populate `integration_id` on
the Canvas users — a local fixture where that field is empty will look exactly like the missing-SIS-
permission failure, and a fixture where nothing matches will look like a broken integration when the
code is fine. Give at least one student a deliberately mismatched key so the unmatched path is
visible on every run.

Verify the write paths against a real assignment before shipping them. Set the assignment to manual
posting first, confirm the comment and PDF land where expected, and only then check what an
automatic posting policy does — that one is visible to students immediately, which is the whole
reason the preflight surfaces it.

Never put local admin passwords, Developer Key secrets, OAuth tokens, Moodle tokens, GitHub package
tokens, student grade data, PUIDs, or generated feedback in this guide, fixtures, commits,
screenshots, or logs.
