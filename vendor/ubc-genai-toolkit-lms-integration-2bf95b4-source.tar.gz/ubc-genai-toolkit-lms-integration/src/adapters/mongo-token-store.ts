import type { TokenStore } from '../core/types';

/**
 * The subset of the MongoDB driver's `Collection` API this adapter needs.
 * Declared structurally (not imported from `mongodb`) so this package never
 * takes a hard dependency on the driver — any real `Collection` instance
 * satisfies this shape as-is.
 */
export interface MongoCollectionLike {
  createIndex(indexSpec: Record<string, unknown>, options?: Record<string, unknown>): Promise<unknown>;
  findOne(filter: Record<string, unknown>): Promise<Record<string, unknown> | null>;
  updateOne(
    filter: Record<string, unknown>,
    update: Record<string, unknown>,
    options?: Record<string, unknown>
  ): Promise<unknown>;
  deleteOne(filter: Record<string, unknown>): Promise<unknown>;
}

/** The subset of the MongoDB driver's `Db` API this adapter needs. */
export interface MongoDbLike {
  collection(name: string): MongoCollectionLike;
}

/**
 * Either an already-connected `Db`, or a function that resolves to one
 * (sync or async) — for apps that connect lazily on first use rather than
 * eagerly at startup.
 */
export type MongoDbProvider = MongoDbLike | (() => MongoDbLike | Promise<MongoDbLike>);

export interface MongoTokenStoreOptions {
  /**
   * Defaults to `'canvas_tokens'`. Every store for a provider other than
   * Canvas (or any second store for a different provider sharing the same
   * `userKey`) MUST pass an explicit `collectionName` — two providers
   * sharing a collection will silently overwrite each other's tokens, since
   * both are keyed only by `userKey` with no provider discriminator.
   */
  collectionName?: string;
}

const DEFAULT_COLLECTION_NAME = 'canvas_tokens';

/**
 * A {@link TokenStore} backed by MongoDB — one adapter among what's meant to
 * become a family (`createMongoTokenStore` now, `createPostgresTokenStore` /
 * `createRedisTokenStore` etc. later), all implementing the same
 * storage-agnostic `TokenStore` interface. This is the only entry point in
 * the package that knows anything about a specific database.
 *
 * The unique index on `userKey` is created lazily on first use and memoized
 * for the lifetime of the returned store, so it's safe to call this once per
 * process even under a clustered/multi-worker app — concurrent identical
 * `createIndex` calls are a no-op, not a race.
 *
 * @param db An already-connected `Db`, or a function returning one (called
 * lazily on first use) for apps that connect on-demand rather than at
 * startup.
 */
export function createMongoTokenStore<T>(db: MongoDbProvider, options: MongoTokenStoreOptions = {}): TokenStore<T> {
  const collectionName = options.collectionName ?? DEFAULT_COLLECTION_NAME;
  let collectionPromise: Promise<MongoCollectionLike> | null = null;

  function resolveCollection(): Promise<MongoCollectionLike> {
    if (!collectionPromise) {
      collectionPromise = (async () => {
        const resolvedDb = typeof db === 'function' ? await db() : db;
        const collection = resolvedDb.collection(collectionName);
        await collection.createIndex({ userKey: 1 }, { unique: true });
        return collection;
      })().catch((err) => {
        // Don't poison every future call with a one-time startup failure
        // (e.g. the DB not being reachable yet) — let the next call retry.
        collectionPromise = null;
        throw err;
      });
    }
    return collectionPromise;
  }

  return {
    async get(userKey): Promise<T | null> {
      const collection = await resolveCollection();
      const doc = await collection.findOne({ userKey });
      return (doc?.tokens as T | undefined) ?? null;
    },
    async set(userKey, tokens: T) {
      const collection = await resolveCollection();
      await collection.updateOne({ userKey }, { $set: { tokens } }, { upsert: true });
    },
    async delete(userKey) {
      const collection = await resolveCollection();
      await collection.deleteOne({ userKey });
    },
  };
}
