import { normalizeBaseUrl } from '../../core/http';

export function baseUrl(canvasDomain: string): string {
  return normalizeBaseUrl(canvasDomain);
}
