import type { ApiClient } from '../api-client';
import type { LmsGrade, LmsGradeItem, LmsRosterMatchReport } from '../../../core/types';
import { foldRosterKey } from '../../../core/roster';
import { CanvasApiError, CanvasGradeExportError } from '../errors';

export interface Assignment {
  id: number;
  name: string;
  points_possible?: number;
  grading_type?: string;
  due_at?: string | null;
  /** Grades and comments stay hidden from students until an instructor posts them. */
  post_manually?: boolean;
  anonymous_grading?: boolean;
  moderated_grading?: boolean;
  /**
   * Set when the assignment is submitted and graded as a group. Null on an
   * ordinary assignment. A comment on a group assignment can fan out to every
   * member, so the feedback export refuses these rather than guess.
   */
  group_category_id?: number | null;
  [key: string]: unknown;
}

export interface Submission {
  assignment_id: number;
  user_id: number;
  score?: number | null;
  grade?: string | null;
  submitted_at?: string | null;
  graded_at?: string | null;
  [key: string]: unknown;
}

export interface Enrollment {
  user_id: number;
  grades?: {
    current_score?: number | null;
    current_grade?: string | null;
    final_score?: number | null;
    final_grade?: string | null;
    [key: string]: unknown;
  };
  [key: string]: unknown;
}

export interface GetGradeItemsOptions {
  searchTerm?: string;
  bucket?: 'past' | 'overdue' | 'undated' | 'ungraded' | 'unsubmitted' | 'upcoming' | 'future';
  orderBy?: 'position' | 'name' | 'due_at';
}

export interface GetGradesOptions {
  courseId: string | number;
  /** Omit to return current overall course grades from enrollments. */
  gradeItemId?: string | number;
  /** Optional provider user ids to retain in the normalized response. */
  userIds?: Array<string | number>;
  enrollmentStates?: string[];
}

/** Lists Canvas assignments as normalized gradebook items. */
export async function getGradeItems(
  client: ApiClient,
  canvasCourseId: string | number,
  options: GetGradeItemsOptions = {}
): Promise<LmsGradeItem[]> {
  const assignments = await client.getAll<Assignment>(
    `/courses/${encodeURIComponent(String(canvasCourseId))}/assignments`,
    {
      search_term: options.searchTerm,
      bucket: options.bucket,
      order_by: options.orderBy,
    }
  );
  return assignments.map((assignment) => ({
    id: String(assignment.id),
    courseId: String(canvasCourseId),
    name: assignment.name,
    maxScore: typeof assignment.points_possible === 'number' ? assignment.points_possible : undefined,
    dueAt: assignment.due_at ?? undefined,
    raw: assignment,
  }));
}

/**
 * Reads either overall enrollment grades or assignment-specific submission
 * grades. This function never writes grades — see {@link postGrades}.
 */
export async function getGrades(client: ApiClient, options: GetGradesOptions): Promise<LmsGrade[]> {
  const courseId = String(options.courseId);
  const wantedUsers = options.userIds
    ? new Set(options.userIds.map((userId) => String(userId)))
    : null;

  if (options.gradeItemId === undefined) {
    const enrollments = await client.getAll<Enrollment>(
      `/courses/${encodeURIComponent(courseId)}/enrollments`,
      {
        type: ['StudentEnrollment'],
        state: options.enrollmentStates,
      }
    );
    return enrollments
      .filter((enrollment) => !wantedUsers || wantedUsers.has(String(enrollment.user_id)))
      .map((enrollment) => ({
        courseId,
        userId: String(enrollment.user_id),
        score: enrollment.grades?.current_score ?? undefined,
        grade: enrollment.grades?.current_grade ?? undefined,
        raw: enrollment,
      }));
  }

  const gradeItemId = String(options.gradeItemId);
  const [assignment, submissions] = await Promise.all([
    client.get<Assignment>(
      `/courses/${encodeURIComponent(courseId)}/assignments/${encodeURIComponent(gradeItemId)}`
    ),
    client.getAll<Submission>(
      `/courses/${encodeURIComponent(courseId)}/assignments/${encodeURIComponent(gradeItemId)}/submissions`
    ),
  ]);
  return submissions
    .filter((submission) => !wantedUsers || wantedUsers.has(String(submission.user_id)))
    .map((submission) => ({
      courseId,
      gradeItemId,
      userId: String(submission.user_id),
      score: submission.score ?? undefined,
      grade: submission.grade ?? undefined,
      maxScore: typeof assignment.points_possible === 'number' ? assignment.points_possible : undefined,
      submittedAt: submission.submitted_at ?? undefined,
      gradedAt: submission.graded_at ?? undefined,
      raw: submission,
    }));
}

/** One grade the application wants written, keyed the way the application knows the student. */
export interface GradeInput {
  /** The application's identifier — at UBC, the PUID. Not a Canvas user id. */
  key: string;
  /**
   * Points, percentage (`'88%'`), letter (`'A-'`), or pass/fail. Canvas parses
   * it according to the assignment's own grading type, so the application does
   * not have to know which is in use.
   */
  postedGrade?: string | number;
  /**
   * Feedback shown to the student, subject to the assignment's posting policy —
   * see {@link PostGradesResult.postManually}.
   */
  comment?: string;
  excuse?: boolean;
}

/** One grade addressed to Canvas, after translation through a match report. */
export interface CanvasGradeWrite {
  /** A Canvas user id taken from a match report — never an application key. */
  userId: string;
  postedGrade?: string | number;
  comment?: string;
  excuse?: boolean;
}

/**
 * A grade that will not be written, and why. Every one is a case where guessing
 * would put a real score on the wrong record or on no record at all.
 */
export interface UnresolvedGrade {
  key: string;
  reason: 'no-roster-match' | 'ambiguous-key' | 'duplicate-key';
}

/**
 * Grades resolved against one course's roster and aimed at one assignment,
 * carrying both so {@link postGrades} can refuse to send them anywhere else.
 *
 * Not a security token. It is an ordinary object whose `userId` values mean
 * whatever the process holding it says they mean, so never round-trip a batch
 * through a browser or any other untrusted boundary — resolve it and post it
 * within the same server-side request, and derive `courseId` and `gradeItemId`
 * from the application's own record of the linked course rather than from
 * anything the client sent.
 */
export interface CanvasGradeBatch {
  courseId: string;
  /**
   * The assignment these grades were computed for. Checked on write because a
   * score for Lab 1 posts perfectly cleanly to Lab 2 — same course, same
   * students, same ids — and neither this package nor Canvas would otherwise
   * see anything wrong with it.
   */
  gradeItemId: string;
  writes: CanvasGradeWrite[];
  unresolved: UnresolvedGrade[];
}

/**
 * Translates application-keyed grades into Canvas-keyed writes using a match
 * report, and separates out the ones that cannot be placed.
 *
 * Pure, and deliberately a separate step from sending: an instructor should be
 * able to see exactly who is about to be graded, and who is about to be skipped,
 * before anything reaches Canvas. Nothing here writes.
 *
 * Refuses outright — rather than returning everyone as unresolved — when the
 * roster exposed no `integration_id` at all. That state is produced by a token
 * without permission to read SIS data, and it is indistinguishable from a course
 * where nobody has signed up. Reporting "0 of 240 matched" invites someone to
 * conclude the application's records are wrong and act on it.
 *
 * @param report A report from `matchCourseRoster`.
 * @param gradeItemId The assignment these grades were computed for.
 * @param grades The grades to place, keyed as the application knows its users.
 * @throws {CanvasGradeExportError} `roster-coverage` when the roster carried no
 * `integration_id` on a non-empty course, or `invalid-grade` for an empty or
 * non-finite grade operation.
 */
export function resolveGradeWrites(
  report: LmsRosterMatchReport,
  gradeItemId: string | number,
  grades: GradeInput[]
): CanvasGradeBatch {
  if (report.coverage.total > 0 && report.coverage.integrationId === 0) {
    throw new CanvasGradeExportError(
      `Canvas returned no integration_id for any of the ${report.coverage.total} people on course `
        + `${report.courseId}, so no grade can be placed. This is normally a token without `
        + 'permission to read SIS data rather than an empty roster.',
      'roster-coverage'
    );
  }

  const lmsUserIdByKey = new Map<string, string>();
  for (const match of report.matched) {
    const key = foldRosterKey(match.key);
    if (key) lmsUserIdByKey.set(key, match.lmsUserId);
  }

  const ambiguousKeys = new Set<string>();
  for (const entry of report.ambiguous) {
    for (const appKey of entry.appKeys) {
      const key = foldRosterKey(appKey);
      if (key) ambiguousKeys.add(key);
    }
  }

  // Two rows for the same student mean the application does not agree with
  // itself about their score. Whichever arrived last would win in `grade_data`
  // and nobody would see the other, so neither is written.
  const occurrences = new Map<string, number>();
  for (const grade of grades) {
    const key = foldRosterKey(grade.key);
    if (key) occurrences.set(key, (occurrences.get(key) ?? 0) + 1);
  }

  const writes: CanvasGradeWrite[] = [];
  const unresolved: UnresolvedGrade[] = [];

  for (const grade of grades) {
    if (
      grade.postedGrade === undefined
      && grade.comment === undefined
      && grade.excuse === undefined
    ) {
      throw new CanvasGradeExportError(
        `Grade for application key ${grade.key || '(blank)'} contains no score, comment, or excuse operation.`,
        'invalid-grade'
      );
    }
    if (typeof grade.postedGrade === 'number' && !Number.isFinite(grade.postedGrade)) {
      throw new CanvasGradeExportError(
        `Grade for application key ${grade.key || '(blank)'} is not a finite number.`,
        'invalid-grade'
      );
    }

    const key = foldRosterKey(grade.key);
    const lmsUserId = key ? lmsUserIdByKey.get(key) : undefined;

    if (key && (occurrences.get(key) ?? 0) > 1) {
      unresolved.push({ key: grade.key, reason: 'duplicate-key' });
    } else if (key && ambiguousKeys.has(key)) {
      unresolved.push({ key: grade.key, reason: 'ambiguous-key' });
    } else if (!lmsUserId) {
      unresolved.push({ key: grade.key, reason: 'no-roster-match' });
    } else {
      writes.push({
        userId: lmsUserId,
        postedGrade: grade.postedGrade,
        comment: grade.comment,
        excuse: grade.excuse,
      });
    }
  }

  return { courseId: report.courseId, gradeItemId: String(gradeItemId), writes, unresolved };
}

/** Canvas's async job object, returned by any endpoint that queues work. */
export interface Progress {
  id: number | string;
  workflow_state?: string;
  completion?: number;
  message?: string;
  [key: string]: unknown;
}

export interface ProgressResult {
  progressId: string;
  workflowState: 'queued' | 'running' | 'completed' | 'failed';
  completion?: number;
  message?: string;
  raw: unknown;
}

export interface PostGradesResult extends ProgressResult {
  /**
   * The assignment's posting policy, read during the preflight. When `true`,
   * the grades and comments just sent stay hidden from students until an
   * instructor posts the assignment in Canvas; when `false`, they are visible
   * immediately — which for generated feedback means with no review step unless
   * the application provides one. Surface it either way: the instructor should
   * not have to guess which of the two just happened.
   */
  postManually: boolean;
}

export interface PostGradesOptions {
  /** Must match the batch's `courseId`. */
  courseId: string | number;
  /** Must match the batch's `gradeItemId`. */
  gradeItemId: string | number;
  batch: CanvasGradeBatch;
  /**
   * Permits writing a batch that has `unresolved` entries. Off by default: a
   * partial export is only visibly partial if the surrounding UI remembers to
   * render the skipped list, and "23 of 25 students graded" is not something an
   * instructor should have to notice on their own.
   */
  allowPartial?: boolean;
  /**
   * A preflight previously shown to the instructor. The assignment is always
   * read again immediately before the write; when its security-relevant state
   * no longer matches this value, the export is refused as `preflight-stale`.
   * Never accept this object back from an untrusted client as proof that review
   * happened — keep it server-side or protect it with application-level
   * integrity controls.
   */
  preflight?: GradeExportPreflight;
}

export interface GradeExportPreflight {
  courseId: string;
  gradeItemId: string;
  /**
   * The assignment's posting policy. `true` means grades and comments stay
   * hidden from students until an instructor posts the assignment in Canvas;
   * `false` means they are visible the moment they are written — which for
   * generated feedback is with no review step unless the application adds one.
   */
  postManually: boolean;
  /** Points possible, for showing the instructor what the scores are out of. */
  maxScore?: number;
  /** Canvas grading mode, e.g. `points`, `percent`, or `letter_grade`. */
  gradingType?: string;
  assignmentName: string;
  raw: unknown;
}

export interface PreflightGradeExportOptions {
  courseId: string | number;
  gradeItemId: string | number;
  batch: CanvasGradeBatch;
  allowPartial?: boolean;
}

/**
 * The checks that need no network call. Kept separate so they run on every path
 * to a write, including one supplied with an earlier instructor preflight —
 * otherwise a preflight taken with `allowPartial: true` could be handed to a
 * `postGrades` that did not ask for partial export, and quietly carry the
 * permission across with it.
 */
function assertBatchTargets(
  courseId: string,
  gradeItemId: string,
  batch: CanvasGradeBatch,
  allowPartial: boolean
): void {
  if (batch.courseId !== courseId) {
    throw new CanvasGradeExportError(
      `These grades were matched against course ${batch.courseId} but are being posted to course `
        + `${courseId}. A Canvas user id is the same in every course, so this would have written `
        + 'real scores against the wrong course.',
      'course-mismatch'
    );
  }

  if (batch.gradeItemId !== gradeItemId) {
    throw new CanvasGradeExportError(
      `These grades were computed for assignment ${batch.gradeItemId} but are being posted to `
        + `assignment ${gradeItemId}. Both belong to course ${courseId}, so neither Canvas nor the `
        + 'course check above would have caught it.',
      'assignment-mismatch'
    );
  }

  if (batch.writes.length === 0) {
    throw new CanvasGradeExportError(
      `No grades resolved to a Canvas user for assignment ${gradeItemId} (${batch.unresolved.length} `
        + 'unresolved). Canvas would accept the empty request and report success.',
      'empty-batch'
    );
  }

  if (batch.unresolved.length > 0 && !allowPartial) {
    throw new CanvasGradeExportError(
      `${batch.unresolved.length} of ${batch.writes.length + batch.unresolved.length} grades could `
        + `not be placed on the course ${courseId} roster. Review batch.unresolved and pass `
        + 'allowPartial: true to export the rest.',
      'partial-export'
    );
  }

  const seenUserIds = new Set<string>();
  for (const write of batch.writes) {
    if (!/^\d+$/.test(write.userId)) {
      throw new CanvasGradeExportError(
        `Grade batch contains invalid Canvas user id ${write.userId || '(blank)'}.`,
        'invalid-grade'
      );
    }
    if (seenUserIds.has(write.userId)) {
      throw new CanvasGradeExportError(
        `Grade batch contains more than one write for Canvas user ${write.userId}.`,
        'invalid-grade'
      );
    }
    seenUserIds.add(write.userId);

    if (
      write.postedGrade === undefined
      && write.comment === undefined
      && write.excuse === undefined
    ) {
      throw new CanvasGradeExportError(
        `Grade batch contains no score, comment, or excuse operation for Canvas user ${write.userId}.`,
        'invalid-grade'
      );
    }
    if (typeof write.postedGrade === 'number' && !Number.isFinite(write.postedGrade)) {
      throw new CanvasGradeExportError(
        `Grade batch contains a non-finite score for Canvas user ${write.userId}.`,
        'invalid-grade'
      );
    }
  }
}

/**
 * Runs every check {@link postGrades} would run, and reads the assignment's
 * posting policy, without writing anything.
 *
 * Exists because the policy has to be known *before* the write to be worth
 * anything. Under an automatic posting policy a generated comment is visible to
 * the student the instant it lands, so learning that from the response is
 * learning it too late. Call this, show the instructor what is about to happen,
 * then pass the server-held result to `postGrades` as `preflight`. `postGrades`
 * deliberately reads the assignment again so a setting changed during the
 * instructor's review cannot be hidden by a stale object.
 *
 * @throws {CanvasGradeExportError} `course-mismatch`, `assignment-mismatch`,
 * `empty-batch`, `partial-export`, `invalid-grade`, or `unsupported-grading`.
 */
export async function preflightGradeExport(
  client: ApiClient,
  options: PreflightGradeExportOptions
): Promise<GradeExportPreflight> {
  const courseId = String(options.courseId);
  const gradeItemId = String(options.gradeItemId);
  assertBatchTargets(courseId, gradeItemId, options.batch, options.allowPartial === true);

  // Doubles as a check that the assignment belongs to this course: Canvas 404s
  // here, which is a clearer failure than the one update_grades would give.
  const assignment = await client.get<Assignment>(
    `/courses/${encodeURIComponent(courseId)}/assignments/${encodeURIComponent(gradeItemId)}`
  );

  if (assignment.anonymous_grading || assignment.moderated_grading) {
    throw new CanvasGradeExportError(
      `Canvas assignment ${gradeItemId} uses ${assignment.anonymous_grading ? 'anonymous' : 'moderated'} `
        + 'grading, which does not accept grades addressed by user id.',
      'unsupported-grading'
    );
  }

  return {
    courseId,
    gradeItemId,
    postManually: assignment.post_manually === true,
    maxScore: typeof assignment.points_possible === 'number' ? assignment.points_possible : undefined,
    gradingType: typeof assignment.grading_type === 'string' ? assignment.grading_type : undefined,
    assignmentName: assignment.name,
    raw: assignment,
  };
}

const PROGRESS_STATES = ['queued', 'running', 'completed', 'failed'] as const;

function normalizeProgress(progress: Progress): ProgressResult {
  const state = String(progress.workflow_state ?? '');
  return {
    progressId: String(progress.id),
    // An unrecognized state resolves to `queued`, so a waiter times out rather
    // than reading an unknown value as success.
    workflowState: (PROGRESS_STATES as readonly string[]).includes(state)
      ? (state as ProgressResult['workflowState'])
      : 'queued',
    completion: typeof progress.completion === 'number' ? progress.completion : undefined,
    message: progress.message || undefined,
    raw: progress,
  };
}

/**
 * Writes a resolved batch of grades to one Canvas assignment, in a single
 * request, and returns the job Canvas queued to apply them.
 *
 * Canvas applies the batch asynchronously, so a successful return means
 * *accepted*, not *applied* — pass the `progressId` to {@link waitForProgress}
 * to find out which. Bulk rather than one request per student because a course
 * of 300 is one round trip instead of 300, and because Canvas reports per-student
 * failures for the batch rather than leaving a half-finished export behind.
 *
 * Everything {@link preflightGradeExport} refuses, this refuses too — it always
 * runs a fresh preflight immediately before writing. Two of those checks are
 * the ones that catch a write which would otherwise succeed while being wrong:
 * a batch resolved against a different course, and one computed for a different
 * assignment. A Canvas user id is the same in every course a student takes, and
 * every assignment in a course accepts the same ids, so nothing downstream sees
 * a problem with either.
 *
 * @param client An authenticated {@link ApiClient}.
 * @param options The target assignment and a batch from {@link resolveGradeWrites}.
 * @throws {CanvasGradeExportError} `course-mismatch`, `assignment-mismatch`,
 * `empty-batch`, `partial-export`, `invalid-grade`, `preflight-stale`, or
 * `unsupported-grading`.
 */
export async function postGrades(
  client: ApiClient,
  options: PostGradesOptions
): Promise<PostGradesResult> {
  const courseId = String(options.courseId);
  const gradeItemId = String(options.gradeItemId);
  const { batch } = options;

  assertBatchTargets(courseId, gradeItemId, batch, options.allowPartial === true);

  // Never let a structural preflight object suppress the authoritative Canvas
  // read. Besides being forgeable if an application crosses a trust boundary,
  // a legitimate preflight can go stale while an instructor reviews it.
  const preflight = await preflightGradeExport(client, options);
  if (options.preflight) {
    const reviewed = options.preflight;
    if (
      reviewed.courseId !== preflight.courseId
      || reviewed.gradeItemId !== preflight.gradeItemId
      || reviewed.postManually !== preflight.postManually
      || reviewed.maxScore !== preflight.maxScore
      || reviewed.gradingType !== preflight.gradingType
      || reviewed.assignmentName !== preflight.assignmentName
    ) {
      throw new CanvasGradeExportError(
        `Canvas assignment ${gradeItemId} changed after export preflight. Run the preflight again and review the updated assignment before writing.`,
        'preflight-stale'
      );
    }
  }

  const gradeData: Record<string, Record<string, unknown>> = Object.create(null);
  for (const write of batch.writes) {
    const entry: Record<string, unknown> = {};
    if (write.postedGrade !== undefined) entry.posted_grade = write.postedGrade;
    if (write.comment !== undefined) entry.text_comment = write.comment;
    if (write.excuse !== undefined) entry.excuse = write.excuse;
    gradeData[write.userId] = entry;
  }

  const progress = await client.post<Progress>(
    `/courses/${encodeURIComponent(courseId)}/assignments/${encodeURIComponent(gradeItemId)}/submissions/update_grades`,
    { grade_data: gradeData }
  );

  return {
    ...normalizeProgress(progress),
    postManually: preflight.postManually,
  };
}

export interface WaitForProgressOptions {
  /** Gives up after this long. Defaults to 60 seconds. */
  timeoutMs?: number;
  /** First gap between polls. Backs off from here to a 5-second ceiling. Defaults to 1 second. */
  pollIntervalMs?: number;
}

const PROGRESS_BACKOFF_FACTOR = 1.5;
const PROGRESS_MAX_INTERVAL_MS = 5_000;

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

/**
 * Polls a queued Canvas job until it finishes.
 *
 * Returns on `failed` rather than throwing, because a failed batch is a result
 * the caller needs to read: Canvas puts which students it could not grade in the
 * job's message, and that list is the point. Only running out of time throws,
 * since then there is nothing to report.
 *
 * @param client An authenticated {@link ApiClient}.
 * @param progressId From a {@link postGrades} result.
 * @param options Timeout and initial poll interval.
 */
export async function waitForProgress(
  client: ApiClient,
  progressId: string,
  options: WaitForProgressOptions = {}
): Promise<ProgressResult> {
  const timeoutMs = options.timeoutMs ?? 60_000;
  const startedAt = Date.now();
  let interval = options.pollIntervalMs ?? 1_000;

  for (;;) {
    const progress = await client.get<Progress>(`/progress/${encodeURIComponent(progressId)}`);
    const result = normalizeProgress(progress);
    if (result.workflowState === 'completed' || result.workflowState === 'failed') return result;

    if (Date.now() - startedAt + interval > timeoutMs) {
      throw new CanvasApiError(
        `Canvas grade job ${progressId} was still ${result.workflowState} after ${timeoutMs}ms`,
        504
      );
    }

    await sleep(interval);
    interval = Math.min(interval * PROGRESS_BACKOFF_FACTOR, PROGRESS_MAX_INTERVAL_MS);
  }
}
