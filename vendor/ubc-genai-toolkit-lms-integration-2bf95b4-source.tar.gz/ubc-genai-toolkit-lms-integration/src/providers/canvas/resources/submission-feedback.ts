import { createHash } from 'node:crypto';
import type { ApiClient } from '../api-client';
import type { LmsRosterMatchReport } from '../../../core/types';
import { foldRosterKey } from '../../../core/roster';
import { CanvasApiError, CanvasSubmissionFeedbackError, CanvasUploadError } from '../errors';
import type { CanvasUploadStage } from '../errors';
import type { Assignment } from './grades';
import type { SubmissionWithContent } from './submissions';

/** One approved feedback PDF, keyed the way the application knows the student. */
export interface SubmissionFeedbackPdfInput {
  /**
   * The application's own id for this feedback record. Opaque here, and used
   * only for correlation — it is what appears in results and in every error
   * message, so that logs can identify an item without naming a student.
   */
  feedbackId: string;
  /** The application's identifier — at UBC, the PUID. Not a Canvas user id. */
  key: string;
  /**
   * The imported Canvas submission attempt this feedback was written about.
   * Attempts start at 1, and the export verifies the attempt exists before
   * uploading: feedback on a first draft attached to a resubmission is wrong in
   * a way neither Canvas nor the student can detect.
   */
  attempt: number;
  /** Shown to the student in Canvas. Must end in `.pdf`. */
  filename: string;
  /**
   * The complete PDF. `Uint8Array` rather than `Buffer` so the type is not
   * Node-specific; a `Buffer` is one and satisfies this directly.
   *
   * Never modified, and never copied except into the outgoing request body.
   */
  data: Uint8Array;
  /** Optional text carried in the same Canvas comment as the attachment. */
  textComment?: string;
}

/** One feedback PDF addressed to Canvas, after translation through a match report. */
export interface CanvasSubmissionFeedbackWrite {
  feedbackId: string;
  /** A Canvas user id taken from a match report — never an application key. */
  userId: string;
  attempt: number;
  filename: string;
  data: Uint8Array;
  textComment?: string;
}

/**
 * Feedback that will not be exported, and why. Every one is a case where
 * guessing would attach a named student's written feedback to someone else.
 */
export interface UnresolvedSubmissionFeedback {
  feedbackId: string;
  key: string;
  reason: 'no-roster-match' | 'ambiguous-key' | 'duplicate-key';
}

/**
 * Feedback resolved against one course's roster and aimed at one assignment,
 * carrying both so the export can refuse to send it anywhere else.
 *
 * Not a security token, and not an authorization decision. It is an ordinary
 * mutable object whose `userId` values mean whatever the process holding it
 * says they mean, so never round-trip a batch through a browser: resolve it and
 * export it within the same server-side request, or hold it server-side behind
 * an opaque prepared-operation id while the instructor reviews it. Derive
 * `courseId`/`gradeItemId` from the application's own record of the linked
 * course rather than from anything a client sent.
 *
 * Because it is mutable, every structural check runs again at preflight and
 * again before the write — resolution being pure is not, on its own, a
 * guarantee about what is in here later.
 */
export interface CanvasSubmissionFeedbackBatch {
  courseId: string;
  /**
   * The assignment this feedback was written for. Checked on export because a
   * PDF about Lab 1 attaches perfectly cleanly to Lab 2 — same course, same
   * students, same ids — and nothing downstream would see a problem with it.
   */
  gradeItemId: string;
  /** The caller's per-file ceiling, retained so it can be enforced again later. */
  maxBytesPerFile: number;
  writes: CanvasSubmissionFeedbackWrite[];
  unresolved: UnresolvedSubmissionFeedback[];
}

export interface ResolveSubmissionFeedbackOptions {
  /**
   * Largest PDF accepted, in bytes. Required, not defaulted: every file is held
   * whole in memory and then copied into a request body, so the ceiling is a
   * decision the host makes rather than inherits.
   */
  maxBytesPerFile: number;
}

/** Filenames are shown to students and sent to storage verbatim, so they are checked, not repaired. */
const MAX_FILENAME_LENGTH = 255;

/**
 * How far into the file the `%PDF-` signature may appear. Real PDFs put it at
 * byte 0; the allowance exists because some generators emit a byte-order mark
 * or a short preamble first, and Canvas itself accepts those.
 */
const PDF_SIGNATURE_WINDOW = 1024;

const PDF_CONTENT_TYPE = 'application/pdf';

/** Default students exported in parallel. Low on purpose — see {@link postSubmissionFeedbackPdfs}. */
const DEFAULT_CONCURRENCY = 3;
const MAX_CONCURRENCY = 10;

function refuse(message: string, reason: ConstructorParameters<typeof CanvasSubmissionFeedbackError>[1]): never {
  throw new CanvasSubmissionFeedbackError(message, reason);
}

/**
 * Detects a PDF by its own bytes. The filename and the declared MIME type are
 * both supplied by the caller, so neither says anything about the content: a
 * Word document named `feedback.pdf` uploads perfectly and fails only when a
 * student tries to open it.
 */
function hasPdfSignature(data: Uint8Array): boolean {
  const head = Buffer.from(
    data.buffer,
    data.byteOffset,
    Math.min(data.byteLength, PDF_SIGNATURE_WINDOW + 5)
  );
  const at = head.indexOf('%PDF-', 0, 'latin1');
  return at >= 0 && at < PDF_SIGNATURE_WINDOW;
}

function isValidFilename(filename: string): boolean {
  if (filename.length === 0 || filename.length > MAX_FILENAME_LENGTH) return false;
  if (filename.trim().length === 0) return false;
  // A path separator or a control character in a name that reaches storage, a
  // signed upload parameter, and a Canvas download header is a problem in
  // several directions at once.
  if (/[/\\\u0000-\u001f\u007f]/.test(filename)) return false;
  if (filename === '.' || filename === '..') return false;
  return filename.toLowerCase().endsWith('.pdf');
}

function assertPositiveByteLimit(maxBytesPerFile: number): void {
  if (!Number.isSafeInteger(maxBytesPerFile) || maxBytesPerFile <= 0) {
    refuse(
      'Submission feedback maxBytesPerFile must be a positive safe integer.',
      'invalid-feedback'
    );
  }
}

/**
 * Everything about one feedback item that can be judged without Canvas.
 *
 * Runs at resolution, again at preflight, and again before the write, against
 * the batch rather than the original input — a batch is an ordinary object, and
 * a limit enforced only where the data was first read is not enforced at all.
 */
function assertValidFeedback(
  item: {
    feedbackId: string;
    attempt: number;
    filename: string;
    data: Uint8Array;
    textComment?: unknown;
  },
  maxBytesPerFile: number
): void {
  const label = item.feedbackId ? `Feedback ${item.feedbackId}` : 'Feedback with no id';

  if (typeof item.feedbackId !== 'string' || item.feedbackId.trim().length === 0) {
    refuse(
      'Submission feedback is missing its feedbackId, which is the only safe way to report its '
        + 'outcome back to the application.',
      'invalid-feedback'
    );
  }
  if (!Number.isSafeInteger(item.attempt) || item.attempt < 1) {
    refuse(
      `${label} names attempt ${String(item.attempt)}. Canvas attempts start at 1, and an attempt `
        + 'that cannot be verified would attach a draft review to a resubmission.',
      'invalid-feedback'
    );
  }
  if (typeof item.filename !== 'string' || !isValidFilename(item.filename)) {
    refuse(
      `${label} has a filename that is empty, over ${MAX_FILENAME_LENGTH} characters, contains a `
        + 'path separator or control character, or does not end in .pdf.',
      'invalid-feedback'
    );
  }
  if (!(item.data instanceof Uint8Array) || item.data.byteLength === 0) {
    refuse(`${label} carries no PDF bytes.`, 'invalid-feedback');
  }
  if (item.data.byteLength > maxBytesPerFile) {
    refuse(
      `${label} is ${item.data.byteLength} bytes, over the ${maxBytesPerFile}-byte per-file limit.`,
      'invalid-feedback'
    );
  }
  if (!hasPdfSignature(item.data)) {
    refuse(
      `${label} does not begin with a PDF signature. The filename and content type are both `
        + 'supplied by the caller, so neither is evidence that this is a PDF.',
      'invalid-feedback'
    );
  }
  if (item.textComment !== undefined && typeof item.textComment !== 'string') {
    refuse(`${label} has a text comment that is not a string.`, 'invalid-feedback');
  }
}

/**
 * Translates application-keyed feedback into Canvas-keyed writes using a match
 * report, and separates out the items that cannot be placed.
 *
 * Pure, and deliberately a separate step from exporting: an instructor should
 * see exactly which students are about to receive a file, and which are about
 * to be skipped, before anything reaches Canvas. Nothing here writes, uploads,
 * or reads from the network.
 *
 * Refuses outright — rather than returning everyone as unresolved — when the
 * roster exposed no `integration_id` at all. That state is produced by a token
 * without permission to read SIS data, and it is indistinguishable from a course
 * where nobody has signed up.
 *
 * The caller's `data` arrays are referenced, not copied, and never modified.
 * They are also not frozen: if the application changes a PDF after review, the
 * preflight fingerprint is what catches it.
 *
 * @param report A report from `matchCourseRoster`.
 * @param gradeItemId The assignment this feedback was written for.
 * @param inputs The feedback to place, keyed as the application knows its users.
 * @param options The required per-file byte ceiling.
 * @throws {CanvasSubmissionFeedbackError} `roster-coverage` when the roster
 * carried no `integration_id` on a non-empty course, or `invalid-feedback` for a
 * bad limit, id, attempt, filename, or PDF.
 */
export function resolveSubmissionFeedbackWrites(
  report: LmsRosterMatchReport,
  gradeItemId: string | number,
  inputs: SubmissionFeedbackPdfInput[],
  options: ResolveSubmissionFeedbackOptions
): CanvasSubmissionFeedbackBatch {
  assertPositiveByteLimit(options.maxBytesPerFile);

  if (report.coverage.total > 0 && report.coverage.integrationId === 0) {
    refuse(
      `Canvas returned no integration_id for any of the ${report.coverage.total} people on course `
        + `${report.courseId}, so no feedback can be placed. This is normally a token without `
        + 'permission to read SIS data rather than an empty roster.',
      'roster-coverage'
    );
  }

  const lmsUserIdByKey = new Map<string, string>();
  for (const match of report.matched) {
    const key = foldRosterKey(match.key);
    if (key) lmsUserIdByKey.set(key, match.lmsUserId);
  }

  const ambiguousKeys = new Set<string>();
  for (const entry of report.ambiguous) {
    for (const appKey of entry.appKeys) {
      const key = foldRosterKey(appKey);
      if (key) ambiguousKeys.add(key);
    }
  }

  // Two feedback records for one student mean the application does not agree
  // with itself about what that student should read. Whichever was uploaded
  // last would sit under the other in the comment thread, with nothing marking
  // either as superseded, so neither is sent.
  const occurrences = new Map<string, number>();
  for (const input of inputs) {
    const key = foldRosterKey(input.key);
    if (key) occurrences.set(key, (occurrences.get(key) ?? 0) + 1);
  }

  const seenFeedbackIds = new Set<string>();
  const writes: CanvasSubmissionFeedbackWrite[] = [];
  const unresolved: UnresolvedSubmissionFeedback[] = [];

  for (const input of inputs) {
    assertValidFeedback(input, options.maxBytesPerFile);

    // Results are reported per feedback id, so a repeated id makes the outcome
    // of both records unreadable — including "one of these was never sent".
    if (seenFeedbackIds.has(input.feedbackId)) {
      refuse(
        `Feedback id ${input.feedbackId} appears more than once. Results are reported per feedback `
          + 'id, so duplicates make the outcome of both records ambiguous.',
        'invalid-feedback'
      );
    }
    seenFeedbackIds.add(input.feedbackId);

    const key = foldRosterKey(input.key);
    const lmsUserId = key ? lmsUserIdByKey.get(key) : undefined;

    if (key && (occurrences.get(key) ?? 0) > 1) {
      unresolved.push({ feedbackId: input.feedbackId, key: input.key, reason: 'duplicate-key' });
    } else if (key && ambiguousKeys.has(key)) {
      unresolved.push({ feedbackId: input.feedbackId, key: input.key, reason: 'ambiguous-key' });
    } else if (!lmsUserId) {
      unresolved.push({ feedbackId: input.feedbackId, key: input.key, reason: 'no-roster-match' });
    } else {
      writes.push({
        feedbackId: input.feedbackId,
        userId: lmsUserId,
        attempt: input.attempt,
        filename: input.filename,
        data: input.data,
        ...(input.textComment !== undefined ? { textComment: input.textComment } : {}),
      });
    }
  }

  return {
    courseId: report.courseId,
    gradeItemId: String(gradeItemId),
    maxBytesPerFile: options.maxBytesPerFile,
    writes,
    unresolved,
  };
}

/**
 * A digest of exactly what the instructor reviewed: the target, and every
 * item's id, student, attempt, filename, comment text, and file content.
 *
 * The batch is mutable and the review is asynchronous, so without this a
 * preflight that said "24 PDFs for Lab 1" could be handed to an export carrying
 * 24 different PDFs and remain perfectly self-consistent. Every field is length-
 * prefixed so that no combination of values can be rearranged into another.
 */
function fingerprintBatch(batch: CanvasSubmissionFeedbackBatch): string {
  const digest = createHash('sha256');
  const field = (value: string): void => {
    digest.update(`${Buffer.byteLength(value)}:`);
    digest.update(value);
  };

  field(batch.courseId);
  field(batch.gradeItemId);
  field(String(batch.maxBytesPerFile));
  field(String(batch.writes.length));

  for (const write of batch.writes) {
    field(write.feedbackId);
    field(write.userId);
    field(String(write.attempt));
    field(write.filename);
    field(write.textComment === undefined ? 'absent' : 'present');
    field(write.textComment ?? '');
    field(createHash('sha256').update(write.data).digest('hex'));
  }

  return digest.digest('hex');
}

export interface SubmissionFeedbackPreflight {
  courseId: string;
  gradeItemId: string;
  assignmentName: string;
  /**
   * The assignment's posting policy. `true` means the comment and its
   * attachment stay hidden from students until an instructor posts the
   * assignment in Canvas; `false` means the PDF is downloadable by the student
   * the moment it is attached — which for generated feedback is with no review
   * step unless the application provides one. Surface it either way.
   */
  postManually: boolean;
  fileCount: number;
  totalBytes: number;
  /** Identifies the reviewed files; see {@link postSubmissionFeedbackPdfs}. */
  batchFingerprint: string;
  raw: unknown;
}

export interface PreflightSubmissionFeedbackOptions {
  /** Must match the batch's `courseId`. */
  courseId: string | number;
  /** Must match the batch's `gradeItemId`. */
  gradeItemId: string | number;
  batch: CanvasSubmissionFeedbackBatch;
  /**
   * Permits exporting a batch that has `unresolved` entries. Off by default: a
   * partial export is only visibly partial if the surrounding UI remembers to
   * render the skipped list, and "23 of 25 students received feedback" is not
   * something an instructor should have to notice on their own.
   */
  allowPartial?: boolean;
}

/**
 * The checks that need no network call. Kept separate so they run on every path
 * to an upload, including one supplied with an earlier instructor preflight —
 * otherwise a preflight taken with `allowPartial: true` could be handed to an
 * export that did not ask for partial export, and quietly carry the permission
 * across with it.
 */
function assertBatchTargets(
  courseId: string,
  gradeItemId: string,
  batch: CanvasSubmissionFeedbackBatch,
  allowPartial: boolean
): void {
  if (batch.courseId !== courseId) {
    refuse(
      `This feedback was matched against course ${batch.courseId} but is being exported to course `
        + `${courseId}. A Canvas user id is the same in every course, so this would have attached `
        + "real students' feedback under the wrong course.",
      'course-mismatch'
    );
  }

  if (batch.gradeItemId !== gradeItemId) {
    refuse(
      `This feedback was written for assignment ${batch.gradeItemId} but is being exported to `
        + `assignment ${gradeItemId}. Both belong to course ${courseId}, so neither Canvas nor the `
        + 'course check above would have caught it.',
      'assignment-mismatch'
    );
  }

  assertPositiveByteLimit(batch.maxBytesPerFile);

  if (batch.writes.length === 0) {
    refuse(
      `No feedback resolved to a Canvas user for assignment ${gradeItemId} `
        + `(${batch.unresolved.length} unresolved). An export of nothing reports as an export.`,
      'empty-batch'
    );
  }

  if (batch.unresolved.length > 0 && !allowPartial) {
    refuse(
      `${batch.unresolved.length} of ${batch.writes.length + batch.unresolved.length} feedback items `
        + `could not be placed on the course ${courseId} roster. Review batch.unresolved and pass `
        + 'allowPartial: true to export the rest.',
      'partial-export'
    );
  }

  const seenUserIds = new Set<string>();
  const seenFeedbackIds = new Set<string>();
  for (const write of batch.writes) {
    assertValidFeedback(write, batch.maxBytesPerFile);

    if (!/^\d+$/.test(write.userId)) {
      refuse(
        `Feedback ${write.feedbackId} carries the invalid Canvas user id `
          + `${write.userId || '(blank)'}.`,
        'invalid-feedback'
      );
    }
    if (seenFeedbackIds.has(write.feedbackId)) {
      refuse(
        `Feedback id ${write.feedbackId} appears more than once in this batch.`,
        'invalid-feedback'
      );
    }
    seenFeedbackIds.add(write.feedbackId);

    // One comment per student per export. Two PDFs for one person is the
    // application disagreeing with itself, and Canvas would accept both.
    if (seenUserIds.has(write.userId)) {
      refuse(
        `Feedback ${write.feedbackId} is the second file addressed to Canvas user ${write.userId} in `
          + 'this batch. Canvas would attach both and mark neither as superseded.',
        'invalid-feedback'
      );
    }
    seenUserIds.add(write.userId);
  }
}

/**
 * Runs every check {@link postSubmissionFeedbackPdfs} would run, reads the
 * assignment's posting policy, and summarizes what is about to be sent, without
 * uploading a byte or writing a comment.
 *
 * Exists because the posting policy is only useful *before* the upload. Under an
 * automatic policy the PDF is downloadable by the student the instant it is
 * attached, so learning that from the response is learning it too late. Call
 * this, show the instructor `fileCount`, `totalBytes`, `postManually`, and
 * `batch.unresolved`, then pass the server-held result to the export.
 *
 * @throws {CanvasSubmissionFeedbackError} `course-mismatch`,
 * `assignment-mismatch`, `empty-batch`, `partial-export`, `invalid-feedback`,
 * `unsupported-grading`, or `unsupported-group-assignment`.
 * @throws {CanvasApiError} If the assignment cannot be read.
 */
export async function preflightSubmissionFeedbackExport(
  client: ApiClient,
  options: PreflightSubmissionFeedbackOptions
): Promise<SubmissionFeedbackPreflight> {
  const courseId = String(options.courseId);
  const gradeItemId = String(options.gradeItemId);
  const { batch } = options;
  assertBatchTargets(courseId, gradeItemId, batch, options.allowPartial === true);

  // Doubles as a check that the assignment belongs to this course: Canvas 404s
  // here, which is a clearer failure than any the upload would give.
  const assignment = await client.get<Assignment>(
    `/courses/${encodeURIComponent(courseId)}/assignments/${encodeURIComponent(gradeItemId)}`
  );

  if (assignment.anonymous_grading || assignment.moderated_grading) {
    refuse(
      `Canvas assignment ${gradeItemId} uses `
        + `${assignment.anonymous_grading ? 'anonymous' : 'moderated'} grading, which does not accept `
        + 'feedback addressed by user id.',
      'unsupported-grading'
    );
  }

  // "One PDF for each member" and "one PDF for the group" are different
  // products, and Canvas silently picks one: a comment on a group assignment
  // can fan out to every member. Refused until that decision is made
  // deliberately rather than discovered by a student.
  if (assignment.group_category_id !== null && assignment.group_category_id !== undefined) {
    refuse(
      `Canvas assignment ${gradeItemId} is a group assignment. Whether one PDF belongs to one `
        + 'student or to a whole group is a product decision this export does not make for you.',
      'unsupported-group-assignment'
    );
  }

  let totalBytes = 0;
  for (const write of batch.writes) totalBytes += write.data.byteLength;

  return {
    courseId,
    gradeItemId,
    assignmentName: assignment.name,
    postManually: assignment.post_manually === true,
    fileCount: batch.writes.length,
    totalBytes,
    batchFingerprint: fingerprintBatch(batch),
    raw: assignment,
  };
}

/**
 * Where an item stopped. Canvas needs four requests per student, and which one
 * failed is the difference between "nothing happened" and "the file is in
 * Canvas but no student can see it".
 */
export type SubmissionFeedbackStage = 'verify-submission' | CanvasUploadStage | 'attach-comment';

export type SubmissionFeedbackItemResult =
  | {
      feedbackId: string;
      userId: string;
      attempt: number;
      status: 'attached';
      /** The Canvas file id now attached to the student's submission comment. */
      fileId: string;
      filename: string;
      raw: unknown;
    }
  | {
      feedbackId: string;
      userId: string;
      attempt: number;
      /**
       * - `failed` — this item did not attach, and Canvas was clear about it.
       * - `unknown` — the connection failed during the comment write itself.
       *   Canvas may have created the comment before it dropped. Re-running
       *   blind can leave the student with two copies; reconcile it by hand.
       * - `not-attempted` — the export stopped before reaching this item, and
       *   nothing about this student was sent to Canvas.
       */
      status: 'failed' | 'unknown' | 'not-attempted';
      stage: SubmissionFeedbackStage;
      message: string;
      statusCode?: number;
      /**
       * Present when the PDF reached Canvas but the comment did not. The file
       * exists with nothing pointing at it — this id is what makes it findable.
       */
      fileId?: string;
    };

export interface PostSubmissionFeedbackOptions extends PreflightSubmissionFeedbackOptions {
  /**
   * A preflight previously shown to the instructor. The assignment is always
   * read again immediately before the first upload; if its reviewed state or
   * the reviewed files no longer match, the export is refused as
   * `preflight-stale`. Never accept this object back from an untrusted client
   * as proof that review happened.
   */
  preflight?: SubmissionFeedbackPreflight;
  /** Students exported in parallel. Defaults to 3; 1 through 10 accepted. */
  concurrency?: number;
  /**
   * Called as each item settles, in completion order, for progress reporting.
   * Anything it throws is ignored — a reporting callback must not be able to
   * take down an export that is partway through writing to Canvas.
   */
  onItemComplete?: (result: SubmissionFeedbackItemResult) => void;
}

export interface PostSubmissionFeedbackResult {
  courseId: string;
  gradeItemId: string;
  /** The posting policy read immediately before the export — see the preflight. */
  postManually: boolean;
  /** One result per `batch.writes` entry, in that order regardless of completion order. */
  results: SubmissionFeedbackItemResult[];
}

/** An authorization failure is about the whole export, not about one student. */
function isAuthorizationFailure(statusCode: number | undefined): boolean {
  return statusCode === 401 || statusCode === 403;
}

function submissionPath(courseId: string, gradeItemId: string, userId: string): string {
  return `/courses/${encodeURIComponent(courseId)}/assignments/${encodeURIComponent(gradeItemId)}`
    + `/submissions/${encodeURIComponent(userId)}`;
}

/**
 * Confirms the attempt this feedback was written about still exists on this
 * student's submission for this assignment.
 *
 * Canvas will happily attach a comment to a submission that has been replaced
 * since the feedback was generated, and the comment carries the attempt number
 * the caller supplies. Attaching a review of a first draft to a resubmission is
 * invisible to everyone involved, so it is checked before any byte is uploaded
 * rather than reported afterwards.
 */
async function verifyAttempt(
  client: ApiClient,
  courseId: string,
  gradeItemId: string,
  write: CanvasSubmissionFeedbackWrite
): Promise<void> {
  const submission = await client.get<SubmissionWithContent>(
    submissionPath(courseId, gradeItemId, write.userId),
    { include: ['submission_history'] }
  );

  if (String(submission.user_id) !== write.userId) {
    throw new CanvasApiError(
      `Canvas returned a submission for user ${String(submission.user_id)} when asked for user `
        + `${write.userId}`,
      502
    );
  }
  if (String(submission.assignment_id) !== gradeItemId) {
    throw new CanvasApiError(
      `Canvas returned a submission for assignment ${String(submission.assignment_id)} when asked `
        + `for assignment ${gradeItemId}`,
      502
    );
  }

  const attempts = new Set<number>();
  if (typeof submission.attempt === 'number') attempts.add(submission.attempt);
  const history = Array.isArray(submission.submission_history) ? submission.submission_history : [];
  for (const entry of history) {
    if (!entry || typeof entry.attempt !== 'number') continue;
    // A submission history is scoped by the endpoint, but do not let a
    // malformed/proxy-corrupted response prove an attempt using a row that
    // explicitly names another user or assignment. Older Canvas versions may
    // omit those redundant ids, so absence is accepted; disagreement is not.
    const sameUser = entry.user_id === undefined || String(entry.user_id) === write.userId;
    const sameAssignment = entry.assignment_id === undefined
      || String(entry.assignment_id) === gradeItemId;
    if (sameUser && sameAssignment) attempts.add(entry.attempt);
  }

  if (!attempts.has(write.attempt)) {
    throw new CanvasApiError(
      `Canvas user ${write.userId} has no attempt ${write.attempt} on assignment ${gradeItemId}`
        + `${attempts.size > 0 ? ` (attempts present: ${[...attempts].sort((a, b) => a - b).join(', ')})` : ''}`,
      409
    );
  }
}

/**
 * Exports one PDF: verify, upload, confirm, attach. Never rejects — a thrown
 * error here would discard the results of every student who already succeeded.
 */
async function exportOneItem(
  client: ApiClient,
  courseId: string,
  gradeItemId: string,
  write: CanvasSubmissionFeedbackWrite
): Promise<SubmissionFeedbackItemResult> {
  const identity = { feedbackId: write.feedbackId, userId: write.userId, attempt: write.attempt };

  try {
    await verifyAttempt(client, courseId, gradeItemId, write);
  } catch (error) {
    return {
      ...identity,
      status: 'failed',
      stage: 'verify-submission',
      message: error instanceof Error ? error.message : 'Canvas submission could not be verified',
      ...(error instanceof CanvasApiError ? { statusCode: error.statusCode } : {}),
    };
  }

  let fileId: string;
  try {
    const uploaded = await client.uploadFile(
      `${submissionPath(courseId, gradeItemId, write.userId)}/comments/files`,
      { name: write.filename, contentType: PDF_CONTENT_TYPE, data: write.data }
    );
    fileId = uploaded.id;
  } catch (error) {
    return {
      ...identity,
      status: 'failed',
      // An error the upload primitive did not raise itself cannot claim the
      // bytes stayed here, so it reports the stage that admits they may not have.
      stage: error instanceof CanvasUploadError ? error.stage : 'upload-bytes',
      message: error instanceof Error ? error.message : 'Canvas file upload failed',
      ...(error instanceof CanvasApiError ? { statusCode: error.statusCode } : {}),
    };
  }

  try {
    const raw = await client.put(submissionPath(courseId, gradeItemId, write.userId), {
      // Canvas maps this to comment[file_ids][], comment[attempt], and
      // comment[text_comment] — one comment carrying both the PDF and the text,
      // rather than a second comment for the words. `group_comment` is omitted:
      // group assignments are refused at preflight.
      comment: {
        file_ids: [fileId],
        attempt: write.attempt,
        ...(write.textComment !== undefined ? { text_comment: write.textComment } : {}),
      },
    });
    return { ...identity, status: 'attached', fileId, filename: write.filename, raw };
  } catch (error) {
    if (error instanceof CanvasApiError) {
      return {
        ...identity,
        status: 'failed',
        stage: 'attach-comment',
        message: error.message,
        statusCode: error.statusCode,
        fileId,
      };
    }
    // Canvas answered nothing, which is not the same as Canvas doing nothing:
    // the comment may exist. Reported as `unknown` so a human decides, because
    // an automatic retry here is how a student ends up with two copies.
    return {
      ...identity,
      status: 'unknown',
      stage: 'attach-comment',
      message:
        `The connection failed while attaching feedback ${write.feedbackId} to Canvas user `
        + `${write.userId}. Canvas may or may not have created the comment; check the submission `
        + 'before re-running this item.',
      fileId,
    };
  }
}

/**
 * Uploads each approved PDF and attaches it to the right student's submission
 * as an instructor comment.
 *
 * Everything {@link preflightSubmissionFeedbackExport} refuses, this refuses
 * too — it always runs a fresh preflight immediately before the first upload,
 * and compares the result against the reviewed one. That comparison covers both
 * the assignment's state and, through `batchFingerprint`, the files themselves,
 * so neither a posting policy changed during review nor a swapped PDF can pass
 * as reviewed.
 *
 * There is no atomic or exactly-once behavior available here, and none is
 * claimed. Canvas exposes no idempotency key for a submission comment, so once
 * the first upload starts, per-student outcomes replace exceptions: one bad PDF
 * must not erase the record of the students who succeeded. Persist
 * `feedbackId` with each result. Re-running an `unknown` item without checking
 * Canvas first can leave a student with two copies of their feedback.
 *
 * @param client An authenticated {@link ApiClient}.
 * @param options The target assignment, a batch from
 * {@link resolveSubmissionFeedbackWrites}, and the reviewed preflight.
 * @throws {CanvasSubmissionFeedbackError} `course-mismatch`,
 * `assignment-mismatch`, `empty-batch`, `partial-export`, `invalid-feedback`,
 * `preflight-stale`, `unsupported-grading`, or `unsupported-group-assignment` —
 * all before the first upload.
 * @throws {CanvasApiError} `400` for a concurrency outside 1..10, or if the
 * pre-write assignment read fails.
 */
export async function postSubmissionFeedbackPdfs(
  client: ApiClient,
  options: PostSubmissionFeedbackOptions
): Promise<PostSubmissionFeedbackResult> {
  const courseId = String(options.courseId);
  const gradeItemId = String(options.gradeItemId);
  const { batch } = options;

  const concurrency = options.concurrency ?? DEFAULT_CONCURRENCY;
  if (!Number.isSafeInteger(concurrency) || concurrency < 1 || concurrency > MAX_CONCURRENCY) {
    throw new CanvasApiError(
      `Submission feedback concurrency must be an integer from 1 to ${MAX_CONCURRENCY}`,
      400
    );
  }

  assertBatchTargets(courseId, gradeItemId, batch, options.allowPartial === true);

  // Never let a structural preflight object suppress the authoritative Canvas
  // read. Besides being forgeable if an application crosses a trust boundary, a
  // legitimate preflight goes stale while an instructor reviews it.
  const preflight = await preflightSubmissionFeedbackExport(client, options);
  if (options.preflight) {
    const reviewed = options.preflight;
    if (
      reviewed.courseId !== preflight.courseId
      || reviewed.gradeItemId !== preflight.gradeItemId
      || reviewed.assignmentName !== preflight.assignmentName
      || reviewed.postManually !== preflight.postManually
      || reviewed.fileCount !== preflight.fileCount
      || reviewed.totalBytes !== preflight.totalBytes
      || reviewed.batchFingerprint !== preflight.batchFingerprint
    ) {
      refuse(
        `Canvas assignment ${gradeItemId} or the reviewed feedback files changed after the export `
          + 'preflight. Run the preflight again and review the updated export before uploading.',
        'preflight-stale'
      );
    }
  }

  const results = new Array<SubmissionFeedbackItemResult>(batch.writes.length);
  let nextIndex = 0;
  // Losing authorization is a fact about the export, not about one student.
  // Once it happens, every remaining item would produce the same failure, and a
  // report of 280 identical errors buries the one that mattered.
  let authorizationLost = false;

  const report = (result: SubmissionFeedbackItemResult): void => {
    if (!options.onItemComplete) return;
    try {
      options.onItemComplete(result);
    } catch {
      // A progress callback is not permitted to interrupt an export in flight.
    }
  };

  async function worker(): Promise<void> {
    for (;;) {
      const index = nextIndex;
      nextIndex += 1;
      if (index >= batch.writes.length) return;
      const write = batch.writes[index];

      if (authorizationLost) {
        results[index] = {
          feedbackId: write.feedbackId,
          userId: write.userId,
          attempt: write.attempt,
          status: 'not-attempted',
          stage: 'verify-submission',
          message:
            'The export stopped after Canvas rejected the credentials. Nothing was sent for this '
            + 'student.',
        };
        report(results[index]);
        continue;
      }

      let result: SubmissionFeedbackItemResult;
      try {
        result = await exportOneItem(client, courseId, gradeItemId, write);
      } catch (error) {
        // exportOneItem is written not to throw; if it ever does, one item's
        // surprise must still not discard everyone else's outcome.
        result = {
          feedbackId: write.feedbackId,
          userId: write.userId,
          attempt: write.attempt,
          status: 'unknown',
          stage: 'attach-comment',
          message: error instanceof Error ? error.message : 'Canvas feedback export failed',
        };
      }

      if (result.status !== 'attached' && isAuthorizationFailure(result.statusCode)) {
        authorizationLost = true;
      }
      results[index] = result;
      report(result);
    }
  }

  await Promise.all(Array.from({ length: Math.min(concurrency, batch.writes.length) }, worker));

  return {
    courseId,
    gradeItemId,
    postManually: preflight.postManually,
    results,
  };
}
