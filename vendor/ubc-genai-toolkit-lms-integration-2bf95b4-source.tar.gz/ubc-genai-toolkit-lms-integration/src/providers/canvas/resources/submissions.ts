import type { ApiClient } from '../api-client';
import type {
  LmsFileDownload,
  LmsFileDownloadOptions,
  LmsRosterMatch,
  LmsRosterMatchReport,
  LmsSubmission,
  LmsSubmissionAttachment,
} from '../../../core/types';
import type { Submission } from './grades';
import { CanvasApiError, CanvasGradeExportError } from '../errors';

/**
 * A file uploaded with a submission. Canvas serializes these inline on the
 * submission itself, so listing them costs nothing — only the bytes behind
 * `url` require a second request.
 */
export interface SubmissionAttachment {
  id: number;
  filename?: string;
  display_name?: string;
  'content-type'?: string;
  content_type?: string;
  size?: number;
  url?: string;
  [key: string]: unknown;
}

/**
 * The submission fields this module reads, beyond the score-and-grade subset
 * {@link Submission} covers for the read-only gradebook path.
 */
export interface SubmissionWithContent extends Submission {
  attempt?: number | null;
  workflow_state?: string;
  body?: string | null;
  url?: string | null;
  late?: boolean;
  missing?: boolean;
  attachments?: SubmissionAttachment[];
  /**
   * Previous versions of this submission, newest last, present only when the
   * read asked for `submission_history`. Each entry carries its own `attempt`,
   * which is how feedback written about attempt 1 is confirmed to belong on
   * attempt 1 after the student has submitted again.
   */
  submission_history?: SubmissionWithContent[];
}

export interface GetSubmissionsOptions {
  courseId: string | number;
  gradeItemId: string | number;
  /**
   * Canvas user ids — from an {@link import('../../../core/types').LmsRosterMatchReport}'s
   * `matched`, not application keys. Narrows what is returned, not what is
   * requested: Canvas's per-assignment submissions endpoint has no server-side
   * user filter, so the pages are read either way.
   */
  userIds?: Array<string | number>;
  /**
   * Canvas returns a placeholder for every student who has not submitted.
   * Excluded by default, since a caller asking for submissions usually means
   * the work that exists. Pass `true` to see the whole class.
   */
  includeUnsubmitted?: boolean;
  /** Extra Canvas `include[]` values, e.g. `submission_comments`, `submission_history`. */
  include?: string[];
}

function optionalText(value: unknown): string | undefined {
  const text = typeof value === 'string' ? value.trim() : '';
  return text || undefined;
}

function normalizeAttachment(attachment: SubmissionAttachment): LmsSubmissionAttachment | null {
  // An attachment Canvas will not give a URL for cannot be downloaded, and
  // carrying it forward would only produce a failure later, further from the
  // cause. Dropping it keeps `attachments` a list of things that can be fetched.
  const url = optionalText(attachment.url);
  if (!url) return null;
  return {
    id: String(attachment.id),
    filename: attachment.filename || attachment.display_name || `canvas-attachment-${attachment.id}`,
    displayName: attachment.display_name || attachment.filename || `Canvas attachment ${attachment.id}`,
    mimeType: attachment['content-type'] || attachment.content_type,
    size: typeof attachment.size === 'number' ? attachment.size : undefined,
    url,
  };
}

/**
 * One assignment's submissions, normalized across providers — see
 * {@link LmsSubmission}. The original Canvas response stays on each result's
 * `.raw`.
 *
 * Reads every page. A submission list truncated at Canvas's first page is worse
 * than a failed read: the students who were cut off come back looking unsubmitted
 * rather than unread, and an application acting on that marks real work missing.
 *
 * `userId` on each result is a Canvas id. Translate it through the match report
 * before it reaches an application record — see `matchCourseRoster`.
 *
 * @param client An authenticated {@link ApiClient}.
 * @param options Which assignment to read, and how much of it — see {@link GetSubmissionsOptions}.
 */
export async function getSubmissions(
  client: ApiClient,
  options: GetSubmissionsOptions
): Promise<LmsSubmission[]> {
  const courseId = String(options.courseId);
  const gradeItemId = String(options.gradeItemId);
  const wantedUsers = options.userIds
    ? new Set(options.userIds.map((userId) => String(userId)))
    : null;

  const submissions = await client.getAll<SubmissionWithContent>(
    `/courses/${encodeURIComponent(courseId)}/assignments/${encodeURIComponent(gradeItemId)}/submissions`,
    { include: options.include }
  );

  return submissions
    .filter((submission) => !wantedUsers || wantedUsers.has(String(submission.user_id)))
    .filter((submission) => options.includeUnsubmitted || submission.workflow_state !== 'unsubmitted')
    .map((submission): LmsSubmission => ({
      courseId,
      gradeItemId,
      userId: String(submission.user_id),
      attempt: typeof submission.attempt === 'number' ? submission.attempt : undefined,
      workflowState: optionalText(submission.workflow_state) ?? 'unknown',
      submittedAt: submission.submitted_at ?? undefined,
      late: typeof submission.late === 'boolean' ? submission.late : undefined,
      missing: typeof submission.missing === 'boolean' ? submission.missing : undefined,
      body: optionalText(submission.body),
      url: optionalText(submission.url),
      attachments: (submission.attachments ?? [])
        .map(normalizeAttachment)
        .filter((attachment): attachment is LmsSubmissionAttachment => attachment !== null),
      score: submission.score ?? undefined,
      grade: submission.grade ?? undefined,
      raw: submission,
    }));
}

export interface DownloadSubmissionAttachmentOptions extends LmsFileDownloadOptions {
  courseId: string | number;
  gradeItemId: string | number;
  /** The Canvas user whose submission this attachment belongs to. */
  userId: string | number;
  /** From a {@link getSubmissions} result's `attachments`. */
  attachmentId: string | number;
  /**
   * Required, unlike on course files. These bytes were uploaded by a student
   * and are buffered whole in memory, so the ceiling is a decision the host has
   * to make rather than inherit.
   */
  maxBytes: number;
}

/**
 * Downloads one attachment from one student's submission.
 *
 * Resolves the attachment through the course- and assignment-scoped submission
 * endpoint rather than taking a URL, for the same reason `downloadFile` does a
 * course-scoped metadata lookup: a URL handed in from outside proves only that
 * it points at Canvas. The origin restrictions in `client.download` stop it
 * being an SSRF primitive or leaking the bearer token off-origin, but they
 * cannot show that a file belongs to this course, this assignment, or this
 * student. Naming those four things and having Canvas produce the URL does.
 *
 * @param client An authenticated {@link ApiClient}.
 * @param options Which attachment, and the download ceiling — see
 * {@link DownloadSubmissionAttachmentOptions}.
 */
export async function downloadSubmissionAttachment(
  client: ApiClient,
  options: DownloadSubmissionAttachmentOptions
): Promise<LmsFileDownload> {
  if (!Number.isSafeInteger(options.maxBytes) || options.maxBytes <= 0) {
    throw new CanvasApiError(
      'Submission attachment maxBytes must be a positive safe integer',
      400
    );
  }

  const courseId = String(options.courseId);
  const gradeItemId = String(options.gradeItemId);
  const userId = String(options.userId);
  const attachmentId = String(options.attachmentId);

  const submission = await client.get<SubmissionWithContent>(
    `/courses/${encodeURIComponent(courseId)}/assignments/${encodeURIComponent(gradeItemId)}`
      + `/submissions/${encodeURIComponent(userId)}`
  );

  const attachment = (submission.attachments ?? []).find(
    (candidate) => String(candidate.id) === attachmentId
  );
  if (!attachment) {
    throw new CanvasApiError(
      `Attachment ${attachmentId} is not on user ${userId}'s submission for assignment ${gradeItemId}`,
      404
    );
  }

  const normalized = normalizeAttachment(attachment);
  if (!normalized) {
    throw new CanvasApiError('Submission attachment has no download URL', 502);
  }

  const result = await client.download(normalized.url, { maxBytes: options.maxBytes });
  if (typeof normalized.size === 'number' && result.size !== normalized.size) {
    throw new CanvasApiError(
      `Canvas submission attachment download was incomplete (expected ${normalized.size} bytes, received ${result.size})`,
      502
    );
  }

  return {
    ...result,
    contentType: result.contentType || normalized.mimeType,
    filename: result.filename || normalized.filename,
  };
}

/** One submission paired with the application account that owns it. */
export interface ResolvedSubmission {
  /** The application's identifier — at UBC, the PUID. */
  key: string;
  /** Present when the match report was built from account ids. */
  appUserId?: string;
  submission: LmsSubmission;
}

/** A submission whose Canvas student could not be placed in the application. */
export interface UnresolvedSubmission {
  lmsUserId: string;
  reason: 'no-app-account' | 'ambiguous-key';
}

export interface ResolvedSubmissions {
  courseId: string;
  gradeItemId: string;
  matched: ResolvedSubmission[];
  unresolved: UnresolvedSubmission[];
}

/**
 * Translates Canvas-keyed submissions into application-keyed ones through a
 * match report — the import-side counterpart to `resolveGradeWrites`.
 *
 * Without it every caller writes the same join by hand, and the failure it
 * guards against is quiet: an unresolved submission is a student whose work the
 * application will simply never see, which looks identical to a student who did
 * not submit. Returning them explicitly makes that difference visible.
 *
 * Refuses the same way the export path does when the roster exposed no
 * `integration_id` at all, since "none of these submissions belong to anyone"
 * is a permissions failure wearing the costume of an empty course.
 *
 * @param report A report from `matchCourseRoster`, for the same course.
 * @param gradeItemId The assignment these submissions were requested for. It is
 * explicit so an empty result retains its assignment and so mixed arrays cannot
 * silently take their identity from the first row.
 * @param submissions Results from {@link getSubmissions}.
 * @throws {CanvasGradeExportError} `roster-coverage`, `course-mismatch`, or
 * `assignment-mismatch` when the submissions do not belong to the expected
 * roster and assignment.
 */
export function resolveSubmissions(
  report: LmsRosterMatchReport,
  gradeItemId: string | number,
  submissions: LmsSubmission[]
): ResolvedSubmissions {
  const expectedGradeItemId = String(gradeItemId);
  if (report.coverage.total > 0 && report.coverage.integrationId === 0) {
    throw new CanvasGradeExportError(
      `Canvas returned no integration_id for any of the ${report.coverage.total} people on course `
        + `${report.courseId}, so no submission can be attributed. This is normally a token without `
        + 'permission to read SIS data rather than an empty roster.',
      'roster-coverage'
    );
  }

  const foreign = submissions.find((submission) => submission.courseId !== report.courseId);
  if (foreign) {
    throw new CanvasGradeExportError(
      `These submissions are from course ${foreign.courseId} but the match report is for course `
        + `${report.courseId}.`,
      'course-mismatch'
    );
  }

  const foreignAssignment = submissions.find(
    (submission) => submission.gradeItemId !== expectedGradeItemId
  );
  if (foreignAssignment) {
    throw new CanvasGradeExportError(
      `These submissions are from assignment ${foreignAssignment.gradeItemId} but the import is for `
        + `assignment ${expectedGradeItemId} in course ${report.courseId}.`,
      'assignment-mismatch'
    );
  }

  const byLmsUserId = new Map<string, LmsRosterMatch>();
  for (const match of report.matched) byLmsUserId.set(match.lmsUserId, match);

  const ambiguousLmsUserIds = new Set<string>();
  for (const entry of report.ambiguous) {
    for (const lmsUserId of entry.lmsUserIds) ambiguousLmsUserIds.add(lmsUserId);
  }

  const matched: ResolvedSubmission[] = [];
  const unresolved: UnresolvedSubmission[] = [];

  for (const submission of submissions) {
    const match = byLmsUserId.get(submission.userId);
    if (match) {
      matched.push({
        key: match.key,
        ...(match.appUserId !== undefined ? { appUserId: match.appUserId } : {}),
        submission,
      });
    } else {
      unresolved.push({
        lmsUserId: submission.userId,
        reason: ambiguousLmsUserIds.has(submission.userId) ? 'ambiguous-key' : 'no-app-account',
      });
    }
  }

  return {
    courseId: report.courseId,
    gradeItemId: expectedGradeItemId,
    matched,
    unresolved,
  };
}
