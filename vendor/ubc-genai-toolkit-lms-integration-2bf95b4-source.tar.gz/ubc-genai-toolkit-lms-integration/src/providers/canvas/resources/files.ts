import type { ApiClient, CanvasDownloadOptions } from '../api-client';
import type { LmsFile, LmsFileDownload, LmsFileDownloadOptions } from '../../../core/types';
import { CanvasApiError } from '../errors';

/**
 * Statuses with which Canvas can refuse `GET /api/v1/files/:id/public_url` for
 * a reason the file's own URL may not share: a Developer Key without that
 * scope (401), a permission the endpoint checks on its own (401 or 403), or a
 * Canvas that lacks the endpoint (404).
 */
const PUBLIC_URL_REFUSED = new Set([401, 403, 404]);

/**
 * How storage refuses a signed link it no longer honours, typically because
 * it expired (S3 answers 403). The remedy is a new link, not a new token.
 */
const SIGNED_LINK_REFUSED = new Set([401, 403]);

/** The Canvas fields used to normalize a Files API response. */
export interface File {
  id: number;
  display_name?: string;
  filename?: string;
  'content-type'?: string;
  content_type?: string;
  size?: number;
  created_at?: string;
  updated_at?: string;
  url?: string;
  [key: string]: unknown;
}

export interface GetCourseFilesOptions {
  contentTypes?: string[];
  excludeContentTypes?: string[];
  searchTerm?: string;
  sort?: 'name' | 'size' | 'created_at' | 'updated_at' | 'content_type' | 'user';
  order?: 'asc' | 'desc';
}

export interface DownloadFileOptions extends LmsFileDownloadOptions {
  /**
   * Where the bytes come from once the course-scoped lookup has found the file.
   *
   * - `'file-url'` (default): the file's own `url`, requested with the bearer
   *   token. That is `/files/:id/download`, not an `/api/v1` path, so no scope
   *   can cover it, and a token from a Developer Key with **Enforce Scopes** on
   *   can be refused there.
   * - `'public-url'`: asks `GET /api/v1/files/:id/public_url` for a
   *   time-limited signed link and downloads that with no Canvas credentials.
   *   On an Enforce Scopes key this needs `url:GET|/api/v1/files/:id/public_url`.
   *   If Canvas refuses that request with 401, 403, or 404 (a key without the
   *   scope, for instance), the download falls back to `'file-url'`. If storage
   *   refuses the link with 401 or 403, as it would an expired one, one new
   *   link is requested.
   */
  via?: 'file-url' | 'public-url';
}

function normalizeFile(file: File, courseId: string | number): LmsFile {
  return {
    id: String(file.id),
    courseId: String(courseId),
    name: file.display_name || file.filename || `Canvas file ${file.id}`,
    filename: file.filename || file.display_name || '',
    mimeType: file['content-type'] || file.content_type,
    size: typeof file.size === 'number' ? file.size : undefined,
    createdAt: file.created_at,
    updatedAt: file.updated_at,
    raw: file,
  };
}

/** Lists course files and maps Canvas metadata to the shared {@link LmsFile} shape. */
export async function getCourseFiles(
  client: ApiClient,
  canvasCourseId: string | number,
  options: GetCourseFilesOptions = {}
): Promise<LmsFile[]> {
  const files = await client.getAll<File>(`/courses/${encodeURIComponent(String(canvasCourseId))}/files`, {
    content_types: options.contentTypes,
    exclude_content_types: options.excludeContentTypes,
    search_term: options.searchTerm,
    sort: options.sort,
    order: options.order,
  });
  return files.map((file) => normalizeFile(file, canvasCourseId));
}

async function requestPublicUrl(client: ApiClient, fileId: string): Promise<string> {
  const response = await client.get<unknown>(`/files/${encodeURIComponent(fileId)}/public_url`);
  const link = response !== null && typeof response === 'object'
    ? (response as { public_url?: unknown }).public_url
    : undefined;
  if (typeof link !== 'string' || !link.trim()) {
    throw new CanvasApiError(`Canvas did not provide a public URL for file ${fileId}`, 502);
  }
  return link.trim();
}

/**
 * Downloads a file through a signed link from `public_url`, asking once for a
 * new link if storage refuses the first. Returns `null` without downloading
 * anything when Canvas will not issue a link, so the caller can fall back.
 */
async function downloadFromPublicUrl(
  client: ApiClient,
  fileId: string,
  downloadOptions: LmsFileDownloadOptions
): Promise<LmsFileDownload | null> {
  let link: string;
  try {
    link = await requestPublicUrl(client, fileId);
  } catch (error) {
    if (error instanceof CanvasApiError && PUBLIC_URL_REFUSED.has(error.statusCode)) return null;
    throw error;
  }

  const signed: CanvasDownloadOptions = { ...downloadOptions, credentials: 'none' };
  try {
    return await client.download(link, signed);
  } catch (error) {
    if (!(error instanceof CanvasApiError) || !SIGNED_LINK_REFUSED.has(error.statusCode)) throw error;
  }
  return client.download(await requestPublicUrl(client, fileId), signed);
}

/**
 * Resolves a file inside the given course and downloads its bytes. The
 * course-scoped metadata lookup prevents callers from using this helper as
 * an arbitrary authenticated URL fetcher. It runs first with either `via`, so
 * a public link is only ever requested for a file Canvas has just confirmed
 * belongs to the course.
 */
export async function downloadFile(
  client: ApiClient,
  canvasCourseId: string | number,
  canvasFileId: string | number,
  options: DownloadFileOptions = {}
): Promise<LmsFileDownload> {
  const via = options.via ?? 'file-url';
  if (via !== 'file-url' && via !== 'public-url') {
    throw new CanvasApiError("downloadFile via must be 'file-url' or 'public-url'", 400);
  }
  // Only the shared limit is passed on, so nothing else in `options` can
  // change how the client treats the request.
  const downloadOptions: LmsFileDownloadOptions = { maxBytes: options.maxBytes };

  const file = await client.get<File>(
    `/courses/${encodeURIComponent(String(canvasCourseId))}/files/${encodeURIComponent(String(canvasFileId))}`
  );

  let result = via === 'public-url'
    ? await downloadFromPublicUrl(client, String(file.id ?? canvasFileId), downloadOptions)
    : null;
  if (!result) {
    if (!file.url) throw new CanvasApiError('Canvas did not provide a download URL for this file', 502);
    result = await client.download(file.url, downloadOptions);
  }

  if (typeof file.size === 'number' && result.size !== file.size) {
    throw new CanvasApiError(
      `Canvas file download was incomplete (expected ${file.size} bytes, received ${result.size})`,
      502
    );
  }
  return {
    ...result,
    contentType: result.contentType || file['content-type'] || file.content_type,
    filename: result.filename || file.filename || file.display_name,
  };
}
