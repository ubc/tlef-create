import type { ApiClient } from '../api-client';
import type { LmsCourse, LmsCourseSection } from '../../../core/types';

/**
 * A Canvas course, as returned by `GET /api/v1/courses`. Only the fields
 * this package's callers rely on are typed explicitly — Canvas returns many
 * more, preserved via the index signature.
 */
export interface Course {
  id: number;
  name: string;
  course_code: string;
  [key: string]: unknown;
}

/**
 * A section within a single Canvas course, as returned by
 * `GET /api/v1/courses/:id/sections`. Every Canvas course has at least one
 * (auto-created); a course has more than one when it's been cross-listed.
 */
export interface CourseSection {
  id: number;
  name: string;
  course_id: number;
  sis_section_id?: string | null;
  [key: string]: unknown;
}

/**
 * The courses the authenticated user has access to, normalized across
 * providers — see {@link LmsCourse}. The original Canvas response (typed
 * {@link Course}) is available on each result's `.raw`.
 *
 * @param client An authenticated {@link ApiClient} (e.g. `req.canvasApi`, attached by `ensureAuth`/`requireAuth`).
 * @param query Optional query params, e.g. `{ enrollment_type: 'teacher' }` to restrict to courses the user teaches.
 */
export async function getCourses(client: ApiClient, query?: Record<string, unknown>): Promise<LmsCourse[]> {
  const courses = await client.getAll<Course>('/courses', query);
  return courses.map(
    (course): LmsCourse => ({
      id: String(course.id),
      name: course.name,
      code: course.course_code,
      raw: course,
    })
  );
}

/**
 * The sections within a single Canvas course, normalized across providers —
 * see {@link LmsCourseSection}. The original Canvas response (typed
 * {@link CourseSection}, including `sis_section_id`, which has no Moodle
 * equivalent) is available on each result's `.raw`.
 *
 * @param client An authenticated {@link ApiClient}.
 * @param canvasCourseId The Canvas course's id (from a {@link getCourses} result's `.id`, or the
 * raw numeric id from `.raw.id` if you have it).
 */
export async function getCourseSections(
  client: ApiClient,
  canvasCourseId: string | number
): Promise<LmsCourseSection[]> {
  const sections = await client.getAll<CourseSection>(`/courses/${canvasCourseId}/sections`);
  return sections.map(
    (section): LmsCourseSection => ({
      id: String(section.id),
      name: section.name,
      courseId: String(section.course_id),
      raw: section,
    })
  );
}
