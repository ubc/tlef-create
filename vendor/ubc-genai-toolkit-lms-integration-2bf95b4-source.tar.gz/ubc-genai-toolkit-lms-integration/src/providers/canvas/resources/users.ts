import type { ApiClient } from '../api-client';
import type {
  LmsAppOnlyUser,
  LmsAppUserKey,
  LmsRosterMatchReport,
  LmsRosterUser,
} from '../../../core/types';
import { foldRosterKey, matchRosterByIntegrationId } from '../../../core/roster';
import { CanvasApiError } from '../errors';

/**
 * A user on a Canvas course roster, as returned by
 * `GET /api/v1/courses/:course_id/users`. Only the fields this package's
 * callers rely on are typed explicitly — Canvas returns many more, preserved
 * via the index signature.
 *
 * `integration_id`, `sis_user_id`, and `login_id` are serialized only for
 * callers permitted to read SIS data. Identity fields are absent rather than
 * null when withheld.
 */
export interface CourseUser {
  id: number;
  name?: string;
  sortable_name?: string;
  short_name?: string;
  email?: string | null;
  login_id?: string | null;
  sis_user_id?: string | null;
  integration_id?: string | null;
  /** Only present when the read asked for `include[]=enrollments`. */
  enrollments?: Array<{ enrollment_state?: string; [key: string]: unknown }>;
  [key: string]: unknown;
}

export interface GetCourseUsersOptions {
  /**
   * Canvas enrollment types to include. Defaults to `['student']` — a roster
   * read, not every person attached to the course. Pass e.g.
   * `['student', 'ta']` to widen it.
   */
  enrollmentTypes?: string[];
  /**
   * Canvas enrollment states to include. Defaults to `['active', 'invited']`,
   * which is everyone currently on the roster including those who have not yet
   * accepted. Concluded and deleted enrollments are excluded unless asked for.
   */
  enrollmentStates?: string[];
  /** Extra documented Canvas `include[]` values, e.g. `enrollments`. */
  include?: string[];
}

function optionalText(value: unknown): string | undefined {
  const text = typeof value === 'string' ? value.trim() : '';
  return text || undefined;
}

/**
 * The people enrolled in a single Canvas course, normalized across providers —
 * see {@link LmsRosterUser}. The original Canvas response (typed
 * {@link CourseUser}) is available on each result's `.raw`.
 *
 * This reads every page. A roster truncated at Canvas's first page is worse
 * than a failed read, because the people who were cut off come back from a
 * later match as "not found" and look like a data problem rather than a
 * missing page.
 *
 * Which identity fields come back depends on the token's permissions — see
 * {@link LmsRosterUser.integrationId} and `rosterFieldCoverage`.
 *
 * @param client An authenticated {@link ApiClient} (e.g. `req.canvasApi`, attached by `ensureAuth`/`requireAuth`).
 * @param canvasCourseId The Canvas course's id (from a `getCourses` result's `.id`, or the
 * raw numeric id from `.raw.id` if you have it).
 * @param options Roster filters — see {@link GetCourseUsersOptions}.
 */
export async function getCourseUsers(
  client: ApiClient,
  canvasCourseId: string | number,
  options: GetCourseUsersOptions = {}
): Promise<LmsRosterUser[]> {
  const users = await client.getAll<CourseUser>(
    `/courses/${encodeURIComponent(String(canvasCourseId))}/users`,
    {
      enrollment_type: options.enrollmentTypes ?? ['student'],
      enrollment_state: options.enrollmentStates ?? ['active', 'invited'],
      include: options.include ? [...new Set(options.include)] : undefined,
    }
  );

  return users.map(
    (user): LmsRosterUser => ({
      id: String(user.id),
      name: optionalText(user.name) ?? optionalText(user.sortable_name) ?? `Canvas user ${user.id}`,
      email: optionalText(user.email),
      integrationId: optionalText(user.integration_id),
      sisId: optionalText(user.sis_user_id),
      loginId: optionalText(user.login_id),
      raw: user,
    })
  );
}

/**
 * Reads one course's roster and pairs it with the application's own users on
 * `integration_id` — at UBC, the PUID.
 *
 * The preferred way to build a match report, because the course id stamped onto
 * the result is taken from the read that produced it. Calling `getCourseUsers`
 * and `matchRosterByIntegrationId` separately leaves room for the two to
 * disagree, and a report carrying the wrong course id is precisely what lets a
 * grade computed for one course be posted against another.
 *
 * @param client An authenticated {@link ApiClient}.
 * @param canvasCourseId The course to read — normally the one the application has linked.
 * @param appUserKeys The application's identifiers for the people it wants matched.
 * @param options Roster filters, passed through to {@link getCourseUsers}.
 */
export async function matchCourseRoster(
  client: ApiClient,
  canvasCourseId: string | number,
  appUsers: Iterable<LmsAppUserKey>,
  options: GetCourseUsersOptions = {}
): Promise<LmsRosterMatchReport> {
  const roster = await getCourseUsers(client, canvasCourseId, options);
  return matchRosterByIntegrationId(canvasCourseId, roster, appUsers);
}

/**
 * Canvas's terminal enrollment states. Read separately from the active roster
 * because `getCourseUsers` deliberately excludes them — a concluded student is
 * not on the roster, and treating them as though they were would quietly widen
 * every other read in the package.
 *
 * `deleted` is not among them: Canvas's course-users endpoint documents
 * `active`, `invited`, `rejected`, `completed`, and `inactive` as the accepted
 * filter values, and a deleted enrollment reads as never-enrolled anyway.
 */
const CONCLUDED_ENROLLMENT_STATES = ['completed', 'inactive', 'rejected'];

export interface ExplainUnmatchedOptions {
  /**
   * Should mirror the enrollment types used for the original roster read, so
   * the two passes are asking about the same population. Defaults to
   * `['student']`, matching {@link getCourseUsers}.
   */
  enrollmentTypes?: string[];
}

function enrollmentStateOf(user: LmsRosterUser): string {
  const enrollments = (user.raw as CourseUser | undefined)?.enrollments;
  if (!Array.isArray(enrollments)) return 'unknown';
  for (const enrollment of enrollments) {
    const state = optionalText(enrollment?.enrollment_state);
    if (state) return state;
  }
  return 'unknown';
}

/**
 * Resolves each unmatched application user against the course's *concluded*
 * enrollments, and returns a new report with their `reason` filled in.
 *
 * Worth the extra request because the active roster cannot tell the two cases
 * apart. `getCourseUsers` returns only active and invited enrollments, so a
 * student who dropped in week 8 is simply absent — identical, from the caller's
 * side, to someone who was never in the course at all. One is a person whose
 * grade no longer has anywhere to go; the other is usually a linked-course
 * mistake. An instructor can act on the first and needs to investigate the
 * second, so the difference is worth a round trip.
 *
 * Optional: skip it and every `appOnly` entry stays `unknown`, which is honest
 * rather than wrong. Throws if the report was built from a different course,
 * since answering with another course's enrollments would be worse than not
 * answering.
 *
 * @param client An authenticated {@link ApiClient}.
 * @param canvasCourseId Must match the report's `courseId`.
 * @param report A report from {@link matchCourseRoster}.
 */
export async function explainUnmatched(
  client: ApiClient,
  canvasCourseId: string | number,
  report: LmsRosterMatchReport,
  options: ExplainUnmatchedOptions = {}
): Promise<LmsRosterMatchReport> {
  if (String(canvasCourseId) !== report.courseId) {
    throw new CanvasApiError(
      `Match report was built from course ${report.courseId}, not ${canvasCourseId}`,
      400
    );
  }
  if (report.appOnly.length === 0) return report;

  const formerlyEnrolled = await getCourseUsers(client, canvasCourseId, {
    enrollmentTypes: options.enrollmentTypes,
    enrollmentStates: CONCLUDED_ENROLLMENT_STATES,
    include: ['enrollments'],
  });

  const byKey = new Map<string, LmsRosterUser>();
  for (const user of formerlyEnrolled) {
    const key = foldRosterKey(user.integrationId);
    // First writer wins: a second concluded enrollment for the same person is
    // a re-registration, and either row supports the same conclusion.
    if (key && !byKey.has(key)) byKey.set(key, user);
  }

  return {
    ...report,
    appOnly: report.appOnly.map((entry): LmsAppOnlyUser => {
      if (entry.reason !== 'unknown') return entry;
      const former = byKey.get(foldRosterKey(entry.key) ?? '');
      if (!former) return { ...entry, reason: 'not-enrolled' };
      return {
        ...entry,
        reason: 'enrollment-ended',
        formerEnrollment: {
          lmsUserId: former.id,
          name: former.name,
          state: enrollmentStateOf(former),
        },
      };
    }),
  };
}
