import { Request, Response, NextFunction, RequestHandler } from 'express';
import { Config, Tokens } from './types';
import { refreshTokens } from './oauth-client';
import { createApiClient, ApiClient } from './api-client';

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      /** Attached by {@link ensureAuth}/{@link requireAuth} once a valid Canvas token is available. */
      canvasApi?: ApiClient;
    }
  }
}

const DEFAULT_BASE_PATH = '/canvas/auth';
/** Refresh proactively if the access token expires within this window. */
const REFRESH_BUFFER_MS = 60_000;

/**
 * Loads the current user's tokens, transparently refreshing them if the
 * access token is expired (or close to it). Returns `null` if the user has
 * no stored tokens, or if refreshing failed (e.g. the refresh token was
 * revoked) — in which case the stale entry has already been deleted from
 * the store.
 */
async function resolveTokens(config: Config, userKey: string): Promise<Tokens | null> {
  let tokens = await config.tokenStore.get(userKey);
  if (!tokens) return null;

  if (tokens.expiresAt <= Date.now() + REFRESH_BUFFER_MS) {
    try {
      const refreshed = await refreshTokens(config, tokens.refreshToken);
      tokens = {
        accessToken: refreshed.accessToken,
        refreshToken: refreshed.refreshToken ?? tokens.refreshToken,
        expiresAt: refreshed.expiresAt,
        canvasUserId: tokens.canvasUserId,
      };
      await config.tokenStore.set(userKey, tokens);
    } catch {
      await config.tokenStore.delete(userKey);
      return null;
    }
  }

  return tokens;
}

/** Attaches `req.canvasApi`, wired to refresh-and-persist on a 401 from Canvas. */
function attachCanvasApi(
  req: Request,
  config: Config,
  userKey: string,
  tokens: Tokens
): void {
  req.canvasApi = createApiClient({
    canvasDomain: config.canvasDomain,
    accessToken: tokens.accessToken,
    allowedDownloadHostSuffixes: config.allowedDownloadHostSuffixes,
    allowedUploadHostSuffixes: config.allowedUploadHostSuffixes,
    onUnauthorized: async () => {
      try {
        const refreshed = await refreshTokens(config, tokens.refreshToken);
        await config.tokenStore.set(userKey, {
          accessToken: refreshed.accessToken,
          refreshToken: refreshed.refreshToken ?? tokens.refreshToken,
          expiresAt: refreshed.expiresAt,
          canvasUserId: tokens.canvasUserId,
        });
        return refreshed.accessToken;
      } catch {
        await config.tokenStore.delete(userKey);
        return null;
      }
    },
  });
}

function loginUrl(req: Request, basePath: string): string {
  return `${basePath}/login?returnTo=${encodeURIComponent(req.originalUrl)}`;
}

/**
 * Express middleware for **page routes**: guarantees `req.canvasApi` is set
 * before calling `next()`. If the current user has no usable Canvas tokens
 * (none stored, or refresh failed), it redirects the browser to the auth
 * router's `/login` route, preserving the original URL to return to
 * afterwards.
 *
 * For JSON/API routes, use {@link requireAuth} instead — a redirect
 * response to an XHR/fetch call is not something the caller can act on.
 */
export function ensureAuth(config: Config): RequestHandler {
  const basePath = config.basePath ?? DEFAULT_BASE_PATH;

  return async function ensureCanvasAuthMiddleware(req: Request, res: Response, next: NextFunction) {
    try {
      const userKey = await config.getUserKey(req);
      const tokens = await resolveTokens(config, userKey);

      if (!tokens) {
        return res.redirect(loginUrl(req, basePath));
      }

      attachCanvasApi(req, config, userKey, tokens);
      next();
    } catch (err) {
      next(err);
    }
  };
}

/**
 * Express middleware for **JSON/API routes**: guarantees `req.canvasApi` is
 * set before calling `next()`. If the current user has no usable Canvas
 * tokens, it responds `401` with `{ success: false, connected: false,
 * connectUrl }` instead of redirecting — `connectUrl` is the `/login` URL
 * the frontend can send the user to (e.g. via a "Connect Canvas" button)
 * to complete the OAuth flow before retrying.
 */
export function requireAuth(config: Config): RequestHandler {
  const basePath = config.basePath ?? DEFAULT_BASE_PATH;

  return async function requireCanvasAuthMiddleware(req: Request, res: Response, next: NextFunction) {
    try {
      const userKey = await config.getUserKey(req);
      const tokens = await resolveTokens(config, userKey);

      if (!tokens) {
        return res.status(401).json({
          success: false,
          connected: false,
          connectUrl: loginUrl(req, basePath),
        });
      }

      attachCanvasApi(req, config, userKey, tokens);
      next();
    } catch (err) {
      next(err);
    }
  };
}
