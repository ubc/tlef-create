import type { Request } from 'express';
import type { TokenStore } from '../../core/types';

/** Tokens issued by Canvas for a single user's authorization. */
export interface Tokens {
  accessToken: string;
  refreshToken: string;
  /** Epoch milliseconds when {@link Tokens.accessToken} expires. */
  expiresAt: number;
  /** The Canvas user id (`user.id` from the token response) the tokens belong to. */
  canvasUserId: string;
}

/**
 * Configuration shared by every entry point in this namespace (the OAuth
 * client functions, the Express router, and the auth middleware).
 */
export interface Config {
  /** Canvas domain, no protocol, e.g. `'ubc.instructure.com'`. */
  canvasDomain: string;
  /** Client ID from the Canvas Developer Key. */
  clientId: string;
  /** Client secret from the Canvas Developer Key. */
  clientSecret: string;
  /** Must exactly match the redirect URI whitelisted on the Developer Key. */
  redirectUri: string;
  /** Where authorized tokens are persisted. */
  tokenStore: TokenStore<Tokens>;
  /**
   * Derives the {@link TokenStore} lookup key from the request (e.g. the
   * app's own session user id). May return a `Promise<string>` for apps
   * whose identity resolution needs I/O.
   */
  getUserKey: (req: Request) => string | Promise<string>;
  /** Optional Canvas API scopes to request. Omit to use whatever the Developer Key allows. */
  scopes?: string[];
  /**
   * Additional HTTPS hostname suffixes that Canvas may redirect file downloads
   * to. Instructure's hosted file gateway and S3 object hosts are supported by
   * default. Canvas credentials are never forwarded to these external hosts.
   *
   * A value such as `files.example.edu` matches that host and its subdomains.
   */
  allowedDownloadHostSuffixes?: string[];
  /**
   * Additional HTTPS hostname suffixes that Canvas may name as the destination
   * for an outgoing file upload, such as a feedback PDF attached to a
   * submission comment. Instructure's hosted file storage is supported by
   * default. Canvas credentials are never forwarded to these external hosts.
   *
   * Kept separate from {@link Config.allowedDownloadHostSuffixes}: allowing a
   * host to serve a file back is a smaller decision than allowing student
   * feedback to be sent to it.
   */
  allowedUploadHostSuffixes?: string[];
  /**
   * The path {@link import('./router').createAuthRouter} is mounted at, e.g. `'/canvas/auth'`.
   * {@link import('./middleware').ensureAuth} uses this to build the login redirect.
   * Defaults to `'/canvas/auth'`.
   */
  basePath?: string;
}
