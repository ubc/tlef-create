import { CanvasApiError, CanvasUploadError } from './errors';
import type { CanvasUploadStage } from './errors';
import { baseUrl } from './canvas-url';
import { parseLinkHeader } from './link-header';
import type { LmsFileDownload, LmsFileDownloadOptions } from '../../core/types';
import http from 'node:http';
import https from 'node:https';

/**
 * Canvas "will be paginated to 10 items by default", which is small enough that
 * a single unpaginated `get` looks like it worked on a demo course and silently
 * drops rows on a real one.
 *
 * 100 is a request, not a guarantee: Canvas documents "an unspecified limit to
 * how big you can set `per_page` to" and tells callers to "always check for the
 * `Link` header" instead of assuming the value was honoured. This client does
 * exactly that, so a server that quietly caps the page size lower costs an extra
 * round trip and nothing else.
 *
 * @see https://canvas.instructure.com/doc/api/file.pagination.html
 */
const DEFAULT_PER_PAGE = 100;

/**
 * Backstop for a `next` chain that advances but never ends. Deliberately not
 * the same value as {@link DEFAULT_PER_PAGE} — this counts requests, not rows,
 * and the two are unrelated.
 *
 * Sized for the worst case that is still legitimate: a server that ignores
 * `per_page` entirely and returns Canvas's default 10 rows a page. 500 requests
 * covers a 5,000-person course even then, and 50,000 rows when `per_page=100`
 * is honoured — past any real roster, file list, or gradebook. A server that
 * repeats a page is caught immediately by the cycle check in `getAll` rather
 * than by this ceiling.
 */
const DEFAULT_MAX_PAGES = 500;

export interface ApiClientOptions {
  canvasDomain: string;
  accessToken: string;
  /**
   * Called when a request comes back `401 Unauthorized`. Should obtain a
   * fresh access token (e.g. via {@link import('./oauth-client').refreshTokens})
   * and return it so the client can retry once. Return `null`/`undefined` to
   * give up and throw. Omit entirely to never retry on 401.
   */
  onUnauthorized?: () => Promise<string | null | undefined>;
  /**
   * Page-follow ceiling for {@link ApiClient.getAll} — a count of REQUESTS, not
   * rows, and not {@link DEFAULT_PER_PAGE}. Defaults to 500, so 50,000 rows at
   * the default `per_page`. `getAll` throws rather than returning a partial
   * list once reached.
   */
  maxPages?: number;
  /**
   * Additional HTTPS hostname suffixes permitted after a same-origin Canvas
   * file URL redirects. Canvas credentials are never sent to these hosts.
   */
  allowedDownloadHostSuffixes?: string[];
  /**
   * Additional HTTPS hostname suffixes permitted as the destination Canvas
   * negotiates for an outgoing file upload — see {@link ApiClient.uploadFile}.
   * Instructure's hosted file gateway, its user-content hosts, and signed
   * Amazon S3 object hosts are permitted already.
   *
   * Separate from {@link ApiClientOptions.allowedDownloadHostSuffixes} on
   * purpose. The two lists happen to hold the same values on most deployments,
   * but permitting a host to serve a file back is a smaller decision than
   * permitting student feedback to be sent to it, and a deployment should be
   * able to make the first without silently making the second.
   */
  allowedUploadHostSuffixes?: string[];
}

/** Options for {@link ApiClient.download}. */
export interface CanvasDownloadOptions extends LmsFileDownloadOptions {
  /**
   * What the download may send.
   *
   * - `'canvas'` (default): the bearer token and Canvas's own cookies, to the
   *   Canvas origin only. The URL must start on Canvas; a redirect to an
   *   approved storage host is followed with nothing attached, for the rest of
   *   the chain.
   * - `'none'`: nothing, on any request or redirect. For a signed link that
   *   carries its own authorization, such as the one
   *   `GET /api/v1/files/:id/public_url` returns. With no credential at stake
   *   the link may start on an approved storage host as well as on Canvas; the
   *   protocol, host, redirect, size, and HTML checks are unchanged. A `401` is
   *   thrown rather than answered with a token refresh, because the token played
   *   no part in it.
   */
  credentials?: 'canvas' | 'none';
}

/** One file's bytes and the metadata Canvas is told about them. */
export interface CanvasUploadRequest {
  /** Filename declared to Canvas. Validate it before calling — this is verbatim. */
  name: string;
  /** MIME type declared to Canvas, e.g. `application/pdf`. */
  contentType: string;
  data: Uint8Array;
}

/** A file that exists in Canvas and can be referenced by id. */
export interface CanvasUploadedFile {
  /** Canvas attachment id, from the confirmation response. Never empty. */
  id: string;
  /** The confirmation response, for the caller's audit record. */
  raw: unknown;
}

export interface GetAllOptions {
  /** Overrides the client-level `maxPages` for this call. */
  maxPages?: number;
}

export interface ApiClient {
  /**
   * Fetches a single response. For a Canvas endpoint that paginates this is
   * the FIRST PAGE ONLY — use {@link ApiClient.getAll} for list endpoints.
   */
  get<T = unknown>(path: string, query?: Record<string, unknown>): Promise<T>;
  /**
   * Fetches every page of a Canvas list endpoint by following the `Link`
   * header's `rel="next"`, and returns the concatenated rows. Defaults to
   * `per_page=100`; pass your own `per_page` in `query` to override.
   */
  getAll<T = unknown>(path: string, query?: Record<string, unknown>, options?: GetAllOptions): Promise<T[]>;
  post<T = unknown>(path: string, body?: unknown): Promise<T>;
  put<T = unknown>(path: string, body?: unknown): Promise<T>;
  delete<T = unknown>(path: string): Promise<T>;
  /**
   * Downloads a Canvas-owned file URL without exposing the bearer token. Pass
   * `credentials: 'none'` for a signed link — see {@link CanvasDownloadOptions}.
   */
  download(url: string, options?: CanvasDownloadOptions): Promise<LmsFileDownload>;
  /**
   * Runs Canvas's three-request file upload and returns the finished Canvas
   * file: `path` is the authenticated `/api/v1/*` endpoint that negotiates the
   * upload (e.g. a submission comment's `.../comments/files`), Canvas names the
   * destination, the bytes go there, and Canvas confirms the result on its own
   * origin.
   *
   * Deliberately not a general-purpose uploader. The destination is never a
   * caller argument — it comes from the authenticated response to `path` and
   * must be the Canvas origin or an approved storage host, so this cannot be
   * turned into "POST these bytes anywhere". The Canvas bearer token and cookie
   * jar are never sent to the destination; Canvas documents that "the access
   * token is not sent with this request".
   *
   * @throws {import('./errors').CanvasUploadError} With `stage` identifying
   * whether the upload was refused before starting, failed while sending bytes,
   * or failed while being confirmed. A `confirm-upload` failure means bytes may
   * already be in Canvas with nothing referencing them.
   * @see https://developerdocs.instructure.com/services/canvas/basics/file.file_uploads
   */
  uploadFile(path: string, file: CanvasUploadRequest): Promise<CanvasUploadedFile>;
}

interface RawHttpResponse {
  ok: boolean;
  status: number;
  headers: {
    get(name: string): string | null;
    getSetCookie?(): string[];
  };
  arrayBuffer(): Promise<ArrayBuffer>;
}

const REDIRECT_STATUSES = new Set([301, 302, 303, 307, 308]);
const MAX_DOWNLOAD_REDIRECTS = 5;

/**
 * Ceiling on the hops between "storage accepted the bytes" and "Canvas says the
 * file exists". One hop is the documented case; more than one happens when
 * storage bounces the confirmation back through another host. Every hop is
 * re-validated against the upload allowlist, so this bounds work, not trust.
 */
const MAX_UPLOAD_CONFIRM_HOPS = 5;

function hostnameMatchesSuffix(hostname: string, suffix: string): boolean {
  const normalizedHostname = hostname.toLowerCase().replace(/\.$/, '');
  const normalizedSuffix = suffix.trim().toLowerCase().replace(/^\.+|\.$/g, '');
  return normalizedSuffix.length > 0
    && (normalizedHostname === normalizedSuffix || normalizedHostname.endsWith(`.${normalizedSuffix}`));
}

function isAmazonS3Hostname(hostname: string): boolean {
  const normalized = hostname.toLowerCase().replace(/\.$/, '');
  if (!hostnameMatchesSuffix(normalized, 'amazonaws.com')) return false;
  return normalized.split('.').some((label) => label === 's3' || label.startsWith('s3-'));
}

/**
 * The file-storage hosts Canvas is allowed to send bytes to or fetch them from.
 * Hosted Canvas serves and accepts files on Instructure's own gateway, its
 * per-account user-content hosts, and signed Amazon S3 object URLs, none of
 * which are the Canvas origin.
 *
 * Matching is on label boundaries, so `canvas-user-content.com.attacker.test`
 * is not a match. `additionalSuffixes` is the escape hatch for a self-hosted
 * deployment with its own storage, and it is per-direction: the caller passes
 * the download list or the upload list, never both.
 */
function isAllowedExternalStorageUrl(url: URL, additionalSuffixes: string[]): boolean {
  if (url.protocol !== 'https:' || url.username || url.password || (url.port && url.port !== '443')) {
    return false;
  }
  return hostnameMatchesSuffix(url.hostname, 'inscloudgate.net')
    || hostnameMatchesSuffix(url.hostname, 'canvas-user-content.com')
    || isAmazonS3Hostname(url.hostname)
    || additionalSuffixes.some((suffix) => hostnameMatchesSuffix(url.hostname, suffix));
}

/**
 * Names a URL in an error message without exposing its path, signed query, or
 * embedded credentials. HTTP(S) origins retain the port because a nonstandard
 * external port is itself a useful rejection reason.
 */
function targetOrigin(url: URL): string {
  return ['http:', 'https:'].includes(url.protocol) ? url.origin : url.protocol;
}

function contentDispositionFilename(value: string | null): string | undefined {
  if (!value) return undefined;
  const utf8 = value.match(/filename\*=UTF-8''([^;]+)/i);
  if (utf8) {
    try {
      return decodeURIComponent(utf8[1]);
    } catch {
      return utf8[1];
    }
  }
  return value.match(/filename="?([^";]+)"?/i)?.[1];
}

async function responseBytes(response: RawHttpResponse, maxBytes?: number): Promise<Uint8Array> {
  const declaredLength = Number(response.headers.get('content-length'));
  if (maxBytes !== undefined && Number.isFinite(declaredLength) && declaredLength > maxBytes) {
    throw new CanvasApiError(`Canvas file exceeds the ${maxBytes}-byte download limit`, 413);
  }

  const data = new Uint8Array(await response.arrayBuffer());
  if (maxBytes !== undefined && data.byteLength > maxBytes) {
    throw new CanvasApiError(`Canvas file exceeds the ${maxBytes}-byte download limit`, 413);
  }
  return data;
}

interface LocalAliasRequest {
  method: string;
  headers: Record<string, string>;
  body?: Buffer;
  maxBytes?: number;
}

/**
 * Sends one request through `node:http(s)` rather than `fetch`, for the single
 * case that needs it: a local Canvas that answers on `localhost` but hands out
 * URLs on a docker alias. Reaching it means requesting the configured origin
 * while presenting the alias in the `Host` header, and Node's `fetch` silently
 * overwrites `Host` with the connected authority.
 */
function requestLocalAlias(url: URL, init: LocalAliasRequest): Promise<RawHttpResponse> {
  const { method, headers, body, maxBytes } = init;
  return new Promise((resolve, reject) => {
    const transport = url.protocol === 'https:' ? https : http;
    const request = transport.request(url, { method, headers }, (response) => {
      const declaredLength = Number(response.headers['content-length']);
      if (maxBytes !== undefined && Number.isFinite(declaredLength) && declaredLength > maxBytes) {
        response.resume();
        reject(new CanvasApiError(`Canvas file exceeds the ${maxBytes}-byte download limit`, 413));
        return;
      }

      const chunks: Buffer[] = [];
      let size = 0;
      response.on('data', (chunk: Buffer) => {
        size += chunk.length;
        if (maxBytes !== undefined && size > maxBytes) {
          response.destroy(new CanvasApiError(`Canvas file exceeds the ${maxBytes}-byte download limit`, 413));
          return;
        }
        chunks.push(chunk);
      });
      response.on('error', reject);
      response.on('end', () => {
        const body = Buffer.concat(chunks);
        resolve({
          ok: response.statusCode !== undefined && response.statusCode >= 200 && response.statusCode < 300,
          status: response.statusCode ?? 500,
          headers: {
            get(name: string) {
              const value = response.headers[name.toLowerCase()];
              return Array.isArray(value) ? value.join(', ') : value ?? null;
            },
            getSetCookie() {
              return response.headers['set-cookie'] ?? [];
            },
          },
          arrayBuffer: async () => body.buffer.slice(body.byteOffset, body.byteOffset + body.byteLength),
        });
      });
    });
    request.on('error', reject);
    request.end(body);
  });
}

function rememberResponseCookies(response: RawHttpResponse, cookieJar: Map<string, string>): void {
  for (const header of response.headers.getSetCookie?.() ?? []) {
    const pair = String(header).split(';', 1)[0];
    const separator = pair.indexOf('=');
    if (separator > 0) cookieJar.set(pair.slice(0, separator), pair.slice(separator + 1));
  }
}

function resolvePath(path: string): string {
  const withoutLeadingSlash = path.startsWith('/') ? path.slice(1) : path;
  return withoutLeadingSlash.startsWith('api/v1/') ? `/${withoutLeadingSlash}` : `/api/v1/${withoutLeadingSlash}`;
}

/**
 * Thin authenticated-fetch wrapper for `/api/v1/*` Canvas endpoints. Deals
 * only with attaching the bearer token, serializing request/response JSON,
 * and retrying once on 401 — it has no Canvas-resource-specific methods
 * (courses, assignments, etc.).
 */
export function createApiClient(options: ApiClientOptions): ApiClient {
  let accessToken = options.accessToken;
  const configuredCanvasUrl = new URL(baseUrl(options.canvasDomain));
  const isLocalCanvas = ['localhost', '127.0.0.1', '::1'].includes(configuredCanvasUrl.hostname);

  /**
   * A local Canvas answers on `localhost` but hands out URLs on its docker
   * hostname, which does not resolve from outside the compose network. Treated
   * as the Canvas origin, and only when Canvas itself is configured as local —
   * never on a hosted deployment.
   */
  function isLocalCanvasAlias(url: URL): boolean {
    return isLocalCanvas && url.hostname === 'canvas.docker';
  }

  function buildUrl(path: string, query?: Record<string, unknown>): URL {
    const url = new URL(resolvePath(path), baseUrl(options.canvasDomain));
    if (query) {
      for (const [key, value] of Object.entries(query)) {
        if (value === undefined || value === null) continue;
        if (Array.isArray(value)) {
          // Canvas's array-valued params (e.g. include[]=syllabus_body&include[]=term)
          // need the Rails-style repeated-bracket-key form, not a comma-joined string.
          for (const item of value) {
            if (item === undefined || item === null) continue;
            url.searchParams.append(`${key}[]`, String(item));
          }
        } else {
          url.searchParams.set(key, String(value));
        }
      }
    }
    return url;
  }

  /** Sends one authenticated request, refreshing and retrying once on 401. */
  async function send(method: string, url: URL, body?: unknown): Promise<Response> {
    const doFetch = () =>
      fetch(url, {
        method,
        headers: {
          Authorization: `Bearer ${accessToken}`,
          ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
        },
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });

    let response = await doFetch();

    if (response.status === 401 && options.onUnauthorized) {
      const newToken = await options.onUnauthorized();
      if (newToken) {
        accessToken = newToken;
        response = await doFetch();
      }
    }

    if (!response.ok) {
      throw new CanvasApiError(`Canvas API request to ${url.pathname} returned ${response.status}`, response.status);
    }
    return response;
  }

  async function request<T>(method: string, path: string, init: { query?: Record<string, unknown>; body?: unknown } = {}): Promise<T> {
    const response = await send(method, buildUrl(path, init.query), init.body);
    if (response.status === 204) return undefined as T;
    return (await response.json()) as T;
  }

  async function getAll<T>(
    path: string,
    query?: Record<string, unknown>,
    getAllOptions: GetAllOptions = {}
  ): Promise<T[]> {
    const maxPages = getAllOptions.maxPages ?? options.maxPages ?? DEFAULT_MAX_PAGES;
    const firstUrl = buildUrl(path, query);
    if (!firstUrl.searchParams.has('per_page')) {
      firstUrl.searchParams.set('per_page', String(DEFAULT_PER_PAGE));
    }

    const expectedOrigin = new URL(baseUrl(options.canvasDomain)).origin;
    const rows: T[] = [];
    // A `next` that points back at a page already fetched would loop until the
    // ceiling, re-appending the same rows on every pass. Catch it on the first
    // repeat instead of after `maxPages` round trips of duplicated data.
    const visited = new Set<string>();
    let nextUrl: URL | null = firstUrl;

    for (let page = 0; page < maxPages; page += 1) {
      visited.add(nextUrl.href);
      const response: Response = await send('GET', nextUrl);
      const body: unknown = response.status === 204 ? [] : await response.json();
      if (!Array.isArray(body)) {
        throw new CanvasApiError(
          `Canvas API request to ${nextUrl.pathname} returned a non-list body; use get() instead of getAll()`,
          response.status
        );
      }
      rows.push(...(body as T[]));

      const next = parseLinkHeader(response.headers.get('link')).next;
      if (!next) return rows;

      // The Link header travels with the response, so a compromised or
      // misconfigured host could point `next` elsewhere. Never send the bearer
      // token to an origin other than the configured Canvas.
      const candidate = new URL(next, firstUrl);
      if (candidate.origin !== expectedOrigin) {
        throw new CanvasApiError('Canvas pagination link pointed to an unexpected origin', 502);
      }
      if (visited.has(candidate.href)) {
        throw new CanvasApiError(
          `Canvas pagination looped back to a page already fetched for ${firstUrl.pathname}`,
          502
        );
      }
      nextUrl = candidate;
    }

    // Returning what we have would reintroduce exactly the silent truncation
    // this method exists to prevent, so refuse instead.
    throw new CanvasApiError(
      `Canvas pagination exceeded ${maxPages} pages for ${firstUrl.pathname}; raise maxPages if this course really is that large`,
      502
    );
  }

  /**
   * Requests one download URL and follows its redirects. With a `token`, the
   * bearer token and cookie jar go to the Canvas origin only, and never again
   * once the chain has left it. With `null`, the URL is a signed link and
   * nothing is attached to any hop.
   */
  async function downloadOnce(
    url: string,
    token: string | null,
    downloadOptions: LmsFileDownloadOptions
  ): Promise<RawHttpResponse> {
    const expectedOrigin = configuredCanvasUrl.origin;
    let currentUrl = new URL(url, configuredCanvasUrl);
    const cookieJar = new Map<string, string>();
    let canvasCredentialsAllowed = token !== null;

    for (let redirectCount = 0; redirectCount <= MAX_DOWNLOAD_REDIRECTS; redirectCount += 1) {
      const sameCanvasOrigin = currentUrl.origin === expectedOrigin;
      const isLocalDockerAlias = isLocalCanvasAlias(currentUrl);
      // A credentialed download starts on Canvas and reaches storage only
      // through a redirect Canvas issued. A signed link names storage itself.
      const isAllowedExternal = (redirectCount > 0 || token === null)
        && isAllowedExternalStorageUrl(currentUrl, options.allowedDownloadHostSuffixes ?? []);
      if (!['http:', 'https:'].includes(currentUrl.protocol)
        || (!sameCanvasOrigin && !isLocalDockerAlias && !isAllowedExternal)) {
        throw new CanvasApiError(
          `Canvas returned an unexpected file download URL (rejected ${targetOrigin(currentUrl)})`,
          502
        );
      }

      if (!sameCanvasOrigin && !isLocalDockerAlias) canvasCredentialsAllowed = false;

      const wireUrl = isLocalDockerAlias
        ? new URL(`${currentUrl.pathname}${currentUrl.search}`, configuredCanvasUrl)
        : currentUrl;
      const sendCanvasCredentials = canvasCredentialsAllowed && (sameCanvasOrigin || isLocalDockerAlias);
      const headers: Record<string, string> = sendCanvasCredentials
        ? {
            Authorization: `Bearer ${token}`,
            ...(isLocalDockerAlias ? { Host: currentUrl.host } : {}),
            ...(cookieJar.size
              ? { Cookie: Array.from(cookieJar, ([name, value]) => `${name}=${value}`).join('; ') }
              : {}),
          }
        : {};
      // `Host` only addresses the docker alias; it is not a credential. A local
      // Canvas issues its signed links on that alias, so they keep it.
      if (token === null && isLocalDockerAlias) headers.Host = currentUrl.host;

      const response: RawHttpResponse = isLocalDockerAlias
        ? await requestLocalAlias(wireUrl, { method: 'GET', headers, maxBytes: downloadOptions.maxBytes })
        : await fetch(wireUrl, {
            redirect: 'manual',
            // Some fetch implementations maintain an ambient cookie store.
            // The download flow owns its intentionally narrow Canvas cookie
            // jar, so never let fetch attach cookies implicitly — especially
            // after an off-origin hop permanently disables credentials.
            credentials: 'omit',
            headers,
          });
      if (sendCanvasCredentials) rememberResponseCookies(response, cookieJar);

      if (!REDIRECT_STATUSES.has(response.status)) return response;
      const location = response.headers.get('location');
      if (!location) throw new CanvasApiError('Canvas file download redirected without a destination', 502);
      if (redirectCount === MAX_DOWNLOAD_REDIRECTS) {
        throw new CanvasApiError('Canvas file download exceeded the redirect limit', 502);
      }
      currentUrl = new URL(location, currentUrl);
    }

    throw new CanvasApiError('Canvas file download exceeded the redirect limit', 502);
  }

  async function download(url: string, downloadOptions: CanvasDownloadOptions = {}): Promise<LmsFileDownload> {
    const credentials = downloadOptions.credentials ?? 'canvas';
    if (credentials !== 'canvas' && credentials !== 'none') {
      throw new CanvasApiError("Canvas download credentials must be 'canvas' or 'none'", 400);
    }
    const signedLink = credentials === 'none';

    let response = await downloadOnce(url, signedLink ? null : accessToken, downloadOptions);
    // A signed link never carried the token, so a 401 means storage refused the
    // link itself, typically because it expired. A new token cannot fix that;
    // only whoever issued the link can issue another.
    if (response.status === 401 && !signedLink && options.onUnauthorized) {
      const newToken = await options.onUnauthorized();
      if (newToken) {
        accessToken = newToken;
        response = await downloadOnce(url, accessToken, downloadOptions);
      }
    }
    if (!response.ok) {
      throw new CanvasApiError(`Canvas file download returned ${response.status}`, response.status);
    }

    const data = await responseBytes(response, downloadOptions.maxBytes);
    const contentType = response.headers.get('content-type') ?? undefined;
    const startsWithHtml = /^\s*(?:<!doctype\s+html|<html\b)/i.test(
      Buffer.from(data.subarray(0, 512)).toString('utf8')
    );
    if (contentType?.toLowerCase().includes('text/html') || startsWithHtml) {
      throw new CanvasApiError('Canvas returned an HTML page instead of the requested file', 502);
    }

    return {
      data,
      contentType,
      filename: contentDispositionFilename(response.headers.get('content-disposition')),
      size: data.byteLength,
    };
  }

  /**
   * Validates one hop of an upload and reports how to address it. `hostHeader`
   * is set only for the local-Canvas docker alias, where the request goes to
   * the configured origin while presenting the alias.
   *
   * Every hop is checked, including the first: `upload_url` is the one Canvas
   * response value that legitimately points off-origin, so a compromised or
   * misconfigured Canvas naming `attacker.example` there would otherwise be
   * handed student feedback with no further checks.
   */
  function resolveUploadHop(
    url: URL,
    stage: CanvasUploadStage
  ): { wireUrl: URL; hostHeader?: string; canvasOrigin: boolean } {
    const hasEmbeddedCredentials = Boolean(url.username || url.password);
    const sameCanvasOrigin = url.origin === configuredCanvasUrl.origin && !hasEmbeddedCredentials;
    const localAlias = isLocalCanvasAlias(url) && !hasEmbeddedCredentials;
    const allowedExternal = isAllowedExternalStorageUrl(url, options.allowedUploadHostSuffixes ?? []);

    if (!['http:', 'https:'].includes(url.protocol)
      || (!sameCanvasOrigin && !localAlias && !allowedExternal)) {
      throw new CanvasUploadError(
        `Canvas returned an unapproved file upload destination (rejected ${targetOrigin(url)})`,
        502,
        stage
      );
    }

    return localAlias
      ? {
          wireUrl: new URL(`${url.pathname}${url.search}`, configuredCanvasUrl),
          hostHeader: url.host,
          canvasOrigin: true,
        }
      : { wireUrl: url, canvasOrigin: sameCanvasOrigin };
  }

  /**
   * Resolves a `Location` Canvas or its storage returned. Untrusted input, so a
   * value that is not a URL at all must fail as an upload error at a known
   * stage rather than escape as a raw `TypeError` with no stage attached.
   */
  function nextUploadUrl(location: string, base: URL, stage: CanvasUploadStage): URL {
    try {
      return new URL(location, base);
    } catch {
      throw new CanvasUploadError(
        'Canvas named an unusable file upload confirmation URL',
        502,
        stage
      );
    }
  }

  async function readJsonBody(response: RawHttpResponse): Promise<unknown> {
    const text = Buffer.from(await response.arrayBuffer()).toString('utf8').trim();
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch {
      return null;
    }
  }

  /**
   * Reads the finished file out of a confirmation body. A response that carries
   * no id is a failure even though the bytes were accepted: without an id there
   * is nothing to attach the file to, and reporting success would leave the
   * caller believing a student received something.
   */
  function finishedUpload(body: unknown, stage: CanvasUploadStage): CanvasUploadedFile {
    const record = body !== null && typeof body === 'object' ? (body as Record<string, unknown>) : {};
    const nested = record.attachment !== null && typeof record.attachment === 'object'
      ? (record.attachment as Record<string, unknown>)
      : {};
    const candidate = record.id ?? nested.id;
    const id = typeof candidate === 'string' || typeof candidate === 'number'
      ? String(candidate).trim()
      : '';
    if (!id) {
      throw new CanvasUploadError('Canvas completed the file upload without returning a file id', 502, stage);
    }
    return { id, raw: body };
  }

  /** Stage 1: ask Canvas where the bytes go. The only source of a destination. */
  async function initializeUpload(
    path: string,
    file: CanvasUploadRequest
  ): Promise<{ url: URL; params: Array<[string, string]> }> {
    let ticket: unknown;
    try {
      ticket = await request<unknown>('POST', path, {
        body: {
          name: file.name,
          // Exact, not approximate: storage backends sign the declared size
          // into the upload parameters and reject anything else at the far end,
          // where the diagnostic is far worse than this one.
          size: file.data.byteLength,
          content_type: file.contentType,
        },
      });
    } catch (error) {
      if (error instanceof CanvasApiError) {
        throw new CanvasUploadError(error.message, error.statusCode, 'initialize-upload');
      }
      throw new CanvasUploadError(
        `Canvas could not be reached to start the file upload at ${resolvePath(path)}`,
        502,
        'initialize-upload'
      );
    }

    const response = ticket !== null && typeof ticket === 'object'
      ? (ticket as Record<string, unknown>)
      : {};
    const declaredUrl = typeof response.upload_url === 'string' ? response.upload_url.trim() : '';
    if (!declaredUrl) {
      throw new CanvasUploadError(
        `Canvas returned no upload URL for ${resolvePath(path)}`,
        502,
        'initialize-upload'
      );
    }

    let url: URL;
    try {
      url = new URL(declaredUrl, configuredCanvasUrl);
    } catch {
      throw new CanvasUploadError(
        `Canvas returned an unusable upload URL for ${resolvePath(path)}`,
        502,
        'initialize-upload'
      );
    }

    const declaredParams = response.upload_params;
    if (declaredParams === null || typeof declaredParams !== 'object' || Array.isArray(declaredParams)) {
      throw new CanvasUploadError(
        `Canvas returned no upload parameters for ${resolvePath(path)}`,
        502,
        'initialize-upload'
      );
    }

    // Copied verbatim and in order. These are the storage provider's own signed
    // fields; renaming, normalizing, reordering, or inventing one invalidates
    // the signature, and dropping one silently changes what was authorized.
    const params: Array<[string, string]> = [];
    for (const [name, value] of Object.entries(declaredParams as Record<string, unknown>)) {
      if (typeof value !== 'string' && typeof value !== 'number' && typeof value !== 'boolean') {
        throw new CanvasUploadError(
          `Canvas upload parameter ${name} is not a value a multipart field can carry`,
          502,
          'initialize-upload'
        );
      }
      params.push([name, String(value)]);
    }

    return { url, params };
  }

  /** Stage 2: send the bytes to the destination Canvas named. No credentials. */
  async function sendUploadBytes(
    destination: { url: URL; params: Array<[string, string]> },
    file: CanvasUploadRequest
  ): Promise<RawHttpResponse> {
    // Checked before the body is built, so a rejected destination costs nothing
    // and — more to the point — reports `initialize-upload`, which is the caller's
    // proof that no byte of student feedback left this process.
    const hop = resolveUploadHop(destination.url, 'initialize-upload');

    const form = new FormData();
    for (const [name, value] of destination.params) form.append(name, value);
    // Last, always. S3 ignores every field that follows the file, and Canvas
    // documents the same ordering for its own storage.
    form.append('file', new Blob([file.data], { type: file.contentType }), file.name);

    try {
      if (hop.hostHeader) {
        // Encoding through Response keeps the runtime's multipart writer — and
        // its generated boundary — on the one path that cannot use fetch.
        const encoded = new Response(form);
        const body = Buffer.from(await encoded.arrayBuffer());
        return await requestLocalAlias(hop.wireUrl, {
          method: 'POST',
          headers: {
            'Content-Type': encoded.headers.get('content-type') ?? 'multipart/form-data',
            'Content-Length': String(body.byteLength),
            Host: hop.hostHeader,
          },
          body,
        });
      }

      return await fetch(hop.wireUrl, {
        method: 'POST',
        // No Authorization header, and never an ambient cookie: Canvas
        // documents that "the access token is not sent with this request", and
        // this destination is frequently not Canvas at all.
        credentials: 'omit',
        // The 3xx here is the completion signal, not a redirect to chase
        // automatically — it has to be validated before it is followed.
        redirect: 'manual',
        body: form,
      });
    } catch (error) {
      if (error instanceof CanvasUploadError) throw error;
      throw new CanvasUploadError(
        `Canvas file upload to ${targetOrigin(destination.url)} did not complete`,
        502,
        'upload-bytes'
      );
    }
  }

  /**
   * Stage 3: confirm the upload so Canvas marks the file available, and read
   * back its id.
   *
   * A GET, in both the 3xx and 201 forms. Canvas's own example shows a POST but
   * its prose requires "a GET ... for forwards compatibility with the 201
   * Created response" — and a GET is the only one of the two that is safe to
   * have retried by anything in the path.
   */
  async function confirmUpload(startUrl: URL): Promise<CanvasUploadedFile> {
    let currentUrl = startUrl;
    let refreshed = false;

    for (let hop = 0; hop < MAX_UPLOAD_CONFIRM_HOPS; hop += 1) {
      const target = resolveUploadHop(currentUrl, 'confirm-upload');
      // "This request is back against Canvas again, and needs to be
      // authenticated using the normal API access token authentication." Only
      // the Canvas origin gets the token — a confirmation that stays on storage,
      // or bounces through another storage host first, does not.
      const headers: Record<string, string> = {
        ...(target.canvasOrigin ? { Authorization: `Bearer ${accessToken}` } : {}),
        ...(target.hostHeader ? { Host: target.hostHeader } : {}),
      };

      let response: RawHttpResponse;
      try {
        response = target.hostHeader
          ? await requestLocalAlias(target.wireUrl, { method: 'GET', headers })
          : await fetch(target.wireUrl, {
              method: 'GET',
              redirect: 'manual',
              credentials: 'omit',
              headers,
            });
      } catch {
        throw new CanvasUploadError(
          `Canvas file upload could not be confirmed at ${targetOrigin(currentUrl)}`,
          502,
          'confirm-upload'
        );
      }

      // Upload confirmation is an authenticated Canvas API read just like
      // `get()`. The access token can expire while the bytes are in flight; a
      // single refresh/retry here is safe because confirmation is a GET and it
      // avoids leaving an otherwise successful upload orphaned solely because
      // this method bypasses the ordinary JSON request helper.
      if (response.status === 401 && target.canvasOrigin && options.onUnauthorized && !refreshed) {
        let newToken: string | null | undefined;
        try {
          newToken = await options.onUnauthorized();
        } catch {
          newToken = null;
        }
        if (newToken) {
          accessToken = newToken;
          refreshed = true;
          continue;
        }
      }

      if (REDIRECT_STATUSES.has(response.status)) {
        const location = response.headers.get('location');
        if (!location) {
          throw new CanvasUploadError(
            'Canvas redirected the file upload confirmation without a destination',
            502,
            'confirm-upload'
          );
        }
        currentUrl = nextUploadUrl(location, currentUrl, 'confirm-upload');
        continue;
      }

      if (!response.ok) {
        throw new CanvasUploadError(
          `Canvas file upload confirmation returned ${response.status}`,
          response.status,
          'confirm-upload'
        );
      }

      return finishedUpload(await readJsonBody(response), 'confirm-upload');
    }

    throw new CanvasUploadError(
      `Canvas file upload confirmation exceeded ${MAX_UPLOAD_CONFIRM_HOPS} hops`,
      502,
      'confirm-upload'
    );
  }

  async function uploadFile(path: string, file: CanvasUploadRequest): Promise<CanvasUploadedFile> {
    const destination = await initializeUpload(path, file);
    const response = await sendUploadBytes(destination, file);
    const location = response.headers.get('location');

    if (REDIRECT_STATUSES.has(response.status)) {
      if (!location) {
        throw new CanvasUploadError(
          `Canvas file upload to ${targetOrigin(destination.url)} redirected without a confirmation URL`,
          502,
          'upload-bytes'
        );
      }
      return confirmUpload(nextUploadUrl(location, destination.url, 'upload-bytes'));
    }

    if (!response.ok) {
      throw new CanvasUploadError(
        `Canvas file upload to ${targetOrigin(destination.url)} returned ${response.status}`,
        response.status,
        'upload-bytes'
      );
    }

    // A 201 Created names the finished file in its Location header; some
    // storage backends answer with the attachment inline instead. The Location
    // is the authoritative form, so it wins when both are present. Accepting
    // bytes is not the same as the file existing, so neither path returns
    // before something reports an id.
    if (location) return confirmUpload(nextUploadUrl(location, destination.url, 'upload-bytes'));
    return finishedUpload(await readJsonBody(response), 'confirm-upload');
  }

  return {
    get: (path, query) => request('GET', path, { query }),
    getAll,
    post: (path, body) => request('POST', path, { body }),
    put: (path, body) => request('PUT', path, { body }),
    delete: (path) => request('DELETE', path),
    download,
    uploadFile,
  };
}
