import { Router, Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
// Type-only: augments express-session's SessionData below without creating a
// runtime dependency on the package (not every consumer uses express-session
// literally — some populate req.session another way). `import type` is
// always erased from compiled output, unlike a bare `import 'express-session'`.
import type {} from 'express-session';
import { Config } from './types';
import { buildAuthorizeUrl, exchangeCodeForTokens, revokeToken } from './oauth-client';
import { CanvasOAuthError } from './errors';

declare module 'express-session' {
  interface SessionData {
    canvasOAuthState?: string;
    canvasOAuthReturnTo?: string;
  }
}

/**
 * Constrains `?returnTo=` to a same-site path. `/login` is a public GET, so
 * this value is attacker-controllable and would otherwise make the
 * post-authorization redirect an open redirect. The lookahead rejects
 * `//evil.com` and `/\evil.com`, which browsers resolve as absolute URLs.
 */
function safeReturnTo(value: unknown): string {
  return typeof value === 'string' && /^\/(?![/\\])/.test(value) ? value : '/';
}

/**
 * Builds the `/login`, `/callback`, and `/logout` endpoints for the Canvas
 * OAuth2 authorization-code flow. Mount it at {@link Config.basePath}
 * (default `/canvas/auth`) so {@link import('./middleware').ensureAuth}'s
 * login redirect lines up with it.
 *
 * Requires `express-session` (or an equivalent `req.session`) to already be
 * configured on the app — used to hold the CSRF `state` and the post-login
 * return URL across the redirect to Canvas and back.
 */
export function createAuthRouter(config: Config): Router {
  const router = Router();

  router.get('/login', (req: Request, res: Response) => {
    const state = crypto.randomBytes(16).toString('hex');
    req.session.canvasOAuthState = state;
    req.session.canvasOAuthReturnTo = safeReturnTo(req.query.returnTo);

    res.redirect(buildAuthorizeUrl(config, { state, scopes: config.scopes }));
  });

  router.get('/callback', async (req: Request, res: Response, next: NextFunction) => {
    const { code, state } = req.query;
    const expectedState = req.session.canvasOAuthState;
    const returnTo = req.session.canvasOAuthReturnTo || '/';
    delete req.session.canvasOAuthState;
    delete req.session.canvasOAuthReturnTo;

    if (!expectedState || state !== expectedState) {
      return res.status(400).send('Invalid or expired Canvas OAuth state.');
    }
    if (typeof code !== 'string') {
      return res.status(400).send('Canvas OAuth callback is missing an authorization code.');
    }

    try {
      const exchanged = await exchangeCodeForTokens(config, code);
      const userKey = await config.getUserKey(req);

      // Canvas doesn't always issue a fresh refresh_token on re-authorization
      // (see exchangeCodeForTokens's docs) — fall back to whatever is already
      // on file for this user rather than losing their refresh token.
      const existing = await config.tokenStore.get(userKey);
      const refreshToken = exchanged.refreshToken ?? existing?.refreshToken;
      if (!refreshToken) {
        throw new CanvasOAuthError(
          'Canvas did not issue a refresh_token and no previous one is on file for this user'
        );
      }

      await config.tokenStore.set(userKey, {
        accessToken: exchanged.accessToken,
        refreshToken,
        expiresAt: exchanged.expiresAt,
        canvasUserId: exchanged.canvasUserId,
      });
      res.redirect(returnTo);
    } catch (err) {
      next(err);
    }
  });

  router.post('/logout', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userKey = await config.getUserKey(req);
      const tokens = await config.tokenStore.get(userKey);
      if (tokens) {
        // Best-effort: Canvas rejects a revoke of an already-dead token, which
        // is the state of the user most likely to be disconnecting. Letting it
        // throw would skip the delete and make disconnecting impossible. The
        // delete is the step the response status reflects.
        try {
          await revokeToken(config, tokens.accessToken);
        } catch {
          // Intentionally ignored.
        }
        await config.tokenStore.delete(userKey);
      }
      res.status(204).end();
    } catch (err) {
      next(err);
    }
  });

  return router;
}
