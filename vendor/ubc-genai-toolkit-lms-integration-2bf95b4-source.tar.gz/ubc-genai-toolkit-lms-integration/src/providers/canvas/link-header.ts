/**
 * Canvas paginates with an RFC 5988 `Link` header rather than a page count in
 * the body:
 *
 * ```
 * Link: <https://host/api/v1/courses?page=2&per_page=100>; rel="next",
 *       <https://host/api/v1/courses?page=1&per_page=100>; rel="first",
 *       <https://host/api/v1/courses?page=9&per_page=100>; rel="last"
 * ```
 *
 * Some Canvas endpoints use opaque bookmark cursors (`page=bookmark:WyIxMC...`)
 * instead of ordinal page numbers, so a caller must follow the `next` URL
 * verbatim — incrementing a `page` parameter silently returns the wrong rows.
 */

// One entry is `<url>; param; param`, with entries separated by commas. The
// params run up to the next comma, which is where the following entry starts.
const LINK_ENTRY = /<([^>]+)>\s*;\s*([^,]+)/g;
const REL_PARAM = /\brel\s*=\s*"?([^";]+)"?/i;

/**
 * Maps each `rel` in a `Link` header to its URL. Returns an empty object for a
 * missing or unparseable header — an absent `next` simply means the last page,
 * which is the correct reading of a response Canvas did not paginate.
 */
export function parseLinkHeader(header: string | null | undefined): Record<string, string> {
  const links: Record<string, string> = {};
  if (!header) return links;

  for (const match of header.matchAll(LINK_ENTRY)) {
    const rel = match[2].match(REL_PARAM)?.[1]?.trim().toLowerCase();
    // Canvas sends each rel once; keep the first if a proxy ever duplicates one.
    if (rel && !(rel in links)) links[rel] = match[1].trim();
  }
  return links;
}
