import { LmsError } from '../../core/errors';

/**
 * Thrown when a Canvas `/login/oauth2/*` request fails — code exchange,
 * refresh, or revoke. Carries Canvas's own `error`/`error_description` when
 * the response body included them.
 */
export class CanvasOAuthError extends LmsError {
  constructor(
    message: string,
    public readonly canvasError?: string,
    public readonly canvasErrorDescription?: string
  ) {
    super(message, 'canvas');
    this.name = 'CanvasOAuthError';
  }
}

/**
 * Thrown when a Canvas `/api/v1/*` request returns a non-2xx response.
 */
export class CanvasApiError extends LmsError {
  constructor(message: string, public readonly statusCode: number) {
    super(message, 'canvas');
    this.name = 'CanvasApiError';
  }
}

/**
 * Why a grade export was refused. Each of these is checked before anything is
 * sent, because every one of them describes a write that would succeed against
 * Canvas while being wrong:
 *
 * - `roster-coverage` — the roster came back with no `integration_id` on anyone,
 *   so nothing could match. Indistinguishable from a class that all dropped out,
 *   and almost always a missing SIS-read permission on the token.
 * - `course-mismatch` — the batch was resolved against a different course's
 *   roster than the one being written to. The same person is the same Canvas
 *   user id in every course they take, so nothing downstream would catch this.
 * - `assignment-mismatch` — the batch was computed for a different assignment in
 *   the same course. Canvas checks only that the assignment belongs to the
 *   course, so Lab 1's scores land on Lab 2 without complaint.
 * - `empty-batch` — nothing resolved to a write. Canvas accepts an empty
 *   `grade_data` and reports success, which reads as "grades exported".
 * - `partial-export` — some grades could not be placed and the caller did not
 *   pass `allowPartial`. A partial export is only visibly partial if the UI
 *   renders the skipped list.
 * - `invalid-grade` — at least one grade contains no operation, or contains a
 *   numeric value JSON cannot represent safely.
 * - `preflight-stale` — the assignment changed after the instructor-facing
 *   preflight. Writing anyway could expose feedback under a different posting
 *   policy or apply scores against a changed maximum.
 * - `unsupported-grading` — the assignment is anonymously or moderately graded,
 *   where Canvas does not accept grades addressed by user id.
 */
export type CanvasGradeExportRefusal =
  | 'roster-coverage'
  | 'course-mismatch'
  | 'assignment-mismatch'
  | 'empty-batch'
  | 'partial-export'
  | 'invalid-grade'
  | 'preflight-stale'
  | 'unsupported-grading';

/**
 * Thrown when a grade export is refused before any request reaches Canvas.
 * Distinct from {@link CanvasApiError} because nothing failed — the export was
 * stopped on purpose, and `reason` says which check stopped it.
 */
export class CanvasGradeExportError extends LmsError {
  constructor(message: string, public readonly reason: CanvasGradeExportRefusal) {
    super(message, 'canvas');
    this.name = 'CanvasGradeExportError';
  }
}

/**
 * Which stage of Canvas's three-request file upload failed. Canvas negotiates
 * an upload destination, takes the bytes at that destination, and then confirms
 * the result back on its own origin, so "the upload failed" on its own does not
 * say whether any bytes left the server or whether a file now exists in Canvas
 * with nothing pointing at it.
 *
 * @see https://developerdocs.instructure.com/services/canvas/basics/file.file_uploads
 */
export type CanvasUploadStage = 'initialize-upload' | 'upload-bytes' | 'confirm-upload';

/**
 * Thrown when a Canvas file upload fails, refuses to start, or is stopped
 * before bytes are sent because Canvas named a destination that is not on the
 * approved storage allowlist.
 *
 * Extends {@link CanvasApiError} so existing handling of Canvas HTTP failures
 * still catches it; `stage` is the addition, and is what a caller needs to tell
 * "nothing was sent" from "the bytes are in Canvas but unattached".
 *
 * Never carries the signed upload URL, the signed upload parameters, or any
 * file content — only the stage, the status, and the rejected origin.
 */
export class CanvasUploadError extends CanvasApiError {
  constructor(
    message: string,
    statusCode: number,
    public readonly stage: CanvasUploadStage
  ) {
    super(message, statusCode);
    this.name = 'CanvasUploadError';
  }
}

/**
 * Why a submission-feedback export was refused. Kept separate from
 * {@link CanvasGradeExportRefusal} because the two exports fail in different
 * ways: a grade is a value, while feedback is a file that lands on one specific
 * student's one specific attempt.
 *
 * - `roster-coverage` — the roster came back with no `integration_id` on anyone,
 *   so nothing could be matched. Almost always a token without permission to
 *   read SIS data rather than an empty course.
 * - `course-mismatch` — the batch was resolved against a different course's
 *   roster than the one being exported to. A Canvas user id is the same in every
 *   course, so nothing downstream would catch it.
 * - `assignment-mismatch` — the batch was built for a different assignment in
 *   the same course. Lab 1's feedback attaches perfectly cleanly to Lab 2.
 * - `empty-batch` — nothing resolved to a write, which would otherwise report as
 *   a successful export of nothing.
 * - `partial-export` — some feedback could not be placed and the caller did not
 *   pass `allowPartial`. Students who receive nothing are only visibly missing
 *   if the UI renders the skipped list.
 * - `invalid-feedback` — a PDF, filename, attempt, or feedback id failed
 *   validation. Checked again before the write, since resolution is pure and its
 *   result is an ordinary mutable object.
 * - `preflight-stale` — the assignment or the reviewed files changed after the
 *   instructor-facing preflight. Uploading anyway could publish different files
 *   than the ones approved, or publish them under a different posting policy.
 * - `unsupported-grading` — anonymous or moderated grading, where feedback
 *   addressed by user id is not accepted.
 * - `unsupported-group-assignment` — a group assignment, where "one PDF per
 *   student" and "one PDF per group" are different products and Canvas would
 *   silently pick one.
 */
export type CanvasSubmissionFeedbackRefusal =
  | 'roster-coverage'
  | 'course-mismatch'
  | 'assignment-mismatch'
  | 'empty-batch'
  | 'partial-export'
  | 'invalid-feedback'
  | 'preflight-stale'
  | 'unsupported-grading'
  | 'unsupported-group-assignment';

/**
 * Thrown when a submission-feedback export is refused before any PDF byte
 * leaves the server. Distinct from {@link CanvasApiError} because nothing
 * failed — the export was stopped on purpose, and `reason` says which check
 * stopped it.
 *
 * Messages name the stage and the safe ids needed to diagnose the refusal. They
 * never contain access tokens, signed upload parameters, signed URLs, PDF bytes,
 * feedback text, or PUIDs.
 */
export class CanvasSubmissionFeedbackError extends LmsError {
  constructor(
    message: string,
    public readonly reason: CanvasSubmissionFeedbackRefusal
  ) {
    super(message, 'canvas');
    this.name = 'CanvasSubmissionFeedbackError';
  }
}
