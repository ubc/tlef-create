export { buildAuthorizeUrl, exchangeCodeForTokens, refreshTokens, revokeToken } from './oauth-client';
export type { OAuthClientConfig, RefreshResult, ExchangeResult } from './oauth-client';

export { baseUrl } from './canvas-url';

export { createApiClient } from './api-client';
export type {
  ApiClient,
  ApiClientOptions,
  GetAllOptions,
  CanvasDownloadOptions,
  CanvasUploadRequest,
  CanvasUploadedFile,
} from './api-client';

export { parseLinkHeader } from './link-header';

export { getCourses, getCourseSections } from './resources/courses';
export type { Course, CourseSection } from './resources/courses';

export { getCourseUsers, matchCourseRoster, explainUnmatched } from './resources/users';
export type { CourseUser, GetCourseUsersOptions, ExplainUnmatchedOptions } from './resources/users';

export { getCourseFiles, downloadFile } from './resources/files';
export type { File, GetCourseFilesOptions, DownloadFileOptions } from './resources/files';

export {
  getSubmissions,
  downloadSubmissionAttachment,
  resolveSubmissions,
} from './resources/submissions';
export type {
  SubmissionAttachment,
  SubmissionWithContent,
  GetSubmissionsOptions,
  DownloadSubmissionAttachmentOptions,
  ResolvedSubmission,
  UnresolvedSubmission,
  ResolvedSubmissions,
} from './resources/submissions';

export {
  getGradeItems,
  getGrades,
  resolveGradeWrites,
  preflightGradeExport,
  postGrades,
  waitForProgress,
} from './resources/grades';
export type {
  Assignment,
  Submission,
  Enrollment,
  GetGradeItemsOptions,
  GetGradesOptions,
  GradeInput,
  CanvasGradeWrite,
  UnresolvedGrade,
  CanvasGradeBatch,
  GradeExportPreflight,
  PreflightGradeExportOptions,
  Progress,
  ProgressResult,
  PostGradesResult,
  PostGradesOptions,
  WaitForProgressOptions,
} from './resources/grades';

export {
  resolveSubmissionFeedbackWrites,
  preflightSubmissionFeedbackExport,
  postSubmissionFeedbackPdfs,
} from './resources/submission-feedback';
export type {
  SubmissionFeedbackPdfInput,
  CanvasSubmissionFeedbackWrite,
  UnresolvedSubmissionFeedback,
  CanvasSubmissionFeedbackBatch,
  ResolveSubmissionFeedbackOptions,
  SubmissionFeedbackPreflight,
  PreflightSubmissionFeedbackOptions,
  SubmissionFeedbackStage,
  SubmissionFeedbackItemResult,
  PostSubmissionFeedbackOptions,
  PostSubmissionFeedbackResult,
} from './resources/submission-feedback';

export { createAuthRouter } from './router';
export { ensureAuth, requireAuth } from './middleware';

export { loadConfigFromEnv } from './env-config';
export type { EnvOverrides } from './env-config';

export {
  CanvasOAuthError,
  CanvasApiError,
  CanvasGradeExportError,
  CanvasUploadError,
  CanvasSubmissionFeedbackError,
} from './errors';
export type {
  CanvasGradeExportRefusal,
  CanvasUploadStage,
  CanvasSubmissionFeedbackRefusal,
} from './errors';

export type { Tokens, Config } from './types';
