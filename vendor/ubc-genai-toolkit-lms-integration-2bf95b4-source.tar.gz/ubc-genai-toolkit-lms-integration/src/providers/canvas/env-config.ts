import type { Config } from './types';

const REQUIRED_ENV_VARS = [
  'CANVAS_DOMAIN',
  'CANVAS_CLIENT_ID',
  'CANVAS_CLIENT_SECRET',
  'CANVAS_REDIRECT_URI',
] as const;

/** The fields {@link loadConfigFromEnv} cannot derive from the environment. */
export type EnvOverrides = Omit<
  Config,
  'canvasDomain' | 'clientId' | 'clientSecret' | 'redirectUri'
>;

/**
 * Reads `canvasDomain`/`clientId`/`clientSecret`/`redirectUri` from
 * `process.env` (`CANVAS_DOMAIN`, `CANVAS_CLIENT_ID`, `CANVAS_CLIENT_SECRET`,
 * `CANVAS_REDIRECT_URI`) and merges in the host-specific fields that can't
 * come from the environment (`tokenStore`, `getUserKey`, and optionally
 * `scopes`/`basePath`).
 *
 * @throws {Error} Listing, by name, any of the four required env vars that are unset.
 */
export function loadConfigFromEnv(overrides: EnvOverrides): Config {
  const missing = REQUIRED_ENV_VARS.filter((name) => !process.env[name]);
  if (missing.length > 0) {
    throw new Error(`Missing required Canvas environment variable(s): ${missing.join(', ')}`);
  }

  return {
    canvasDomain: process.env.CANVAS_DOMAIN as string,
    clientId: process.env.CANVAS_CLIENT_ID as string,
    clientSecret: process.env.CANVAS_CLIENT_SECRET as string,
    redirectUri: process.env.CANVAS_REDIRECT_URI as string,
    ...overrides,
  };
}
