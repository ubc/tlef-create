import { CanvasOAuthError } from './errors';
import { baseUrl } from './canvas-url';

/** Subset of {@link CanvasIntegrationConfig} the OAuth client functions need. */
export interface OAuthClientConfig {
  canvasDomain: string;
  clientId: string;
  clientSecret: string;
  redirectUri: string;
}

/** Result of a successful `refresh_token` grant. Canvas does not always return a new `refresh_token`. */
export interface RefreshResult {
  accessToken: string;
  expiresAt: number;
  refreshToken?: string;
}

interface CanvasTokenResponseBody {
  access_token: string;
  refresh_token?: string;
  expires_in?: number;
  user?: { id: number | string };
  error?: string;
  error_description?: string;
}

function tokenEndpoint(config: Pick<OAuthClientConfig, 'canvasDomain'>): string {
  return `${baseUrl(config.canvasDomain)}/login/oauth2/token`;
}

async function parseTokenErrorBody(response: Response): Promise<{ error?: string; description?: string }> {
  try {
    const body = (await response.json()) as CanvasTokenResponseBody;
    return { error: body.error, description: body.error_description };
  } catch {
    return {};
  }
}

/**
 * Builds the Canvas authorize URL to redirect the user's browser to, kicking
 * off the three-legged OAuth2 flow.
 *
 * @param config Domain and Developer Key client id.
 * @param options `state` should be a per-request random value the caller
 * verifies on callback (CSRF protection). `scopes`, if provided, are sent as
 * a single space-delimited `scope` param.
 */
export function buildAuthorizeUrl(
  config: Pick<OAuthClientConfig, 'canvasDomain' | 'clientId' | 'redirectUri'>,
  options: { state: string; scopes?: string[] }
): string {
  const url = new URL(`${baseUrl(config.canvasDomain)}/login/oauth2/auth`);
  url.searchParams.set('client_id', config.clientId);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('redirect_uri', config.redirectUri);
  url.searchParams.set('state', options.state);
  const scopes = options.scopes ?? [];
  if (scopes.length > 0) {
    url.searchParams.set('scope', scopes.join(' '));
  }
  return url.toString();
}

/** Result of a successful `authorization_code` exchange. */
export interface ExchangeResult {
  accessToken: string;
  /**
   * Canvas only reliably issues a fresh `refresh_token` the *first* time a
   * user authorizes a given Developer Key — a re-authorization (e.g. after
   * the host app's stored token was lost without the user revoking access
   * in Canvas) can omit it. Callers should fall back to a previously-stored
   * refresh token when this is `undefined`, the same way {@link refreshTokens}'s
   * result is already handled.
   */
  refreshToken?: string;
  expiresAt: number;
  canvasUserId: string;
}

/**
 * Exchanges an authorization `code` (from the callback query string) for an
 * access token (and, usually, a refresh token — see {@link ExchangeResult.refreshToken}).
 *
 * @throws {CanvasOAuthError} On a non-2xx response from Canvas.
 */
export async function exchangeCodeForTokens(config: OAuthClientConfig, code: string): Promise<ExchangeResult> {
  const response = await fetch(tokenEndpoint(config), {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'authorization_code',
      client_id: config.clientId,
      client_secret: config.clientSecret,
      redirect_uri: config.redirectUri,
      code,
    }),
  });

  if (!response.ok) {
    const { error, description } = await parseTokenErrorBody(response);
    throw new CanvasOAuthError(
      `Canvas token exchange failed with status ${response.status}`,
      error,
      description
    );
  }

  const body = (await response.json()) as CanvasTokenResponseBody;

  return {
    accessToken: body.access_token,
    refreshToken: body.refresh_token,
    expiresAt: Date.now() + (body.expires_in ?? 3600) * 1000,
    canvasUserId: String(body.user?.id ?? ''),
  };
}

/**
 * Exchanges a stored refresh token for a new access token. Canvas does not
 * rotate the refresh token on every call — the response's `refreshToken` is
 * only set when Canvas actually issued a new one; callers should keep using
 * the previous refresh token otherwise.
 *
 * @throws {CanvasOAuthError} On a non-2xx response from Canvas (e.g. the refresh token was revoked).
 */
export async function refreshTokens(config: OAuthClientConfig, refreshToken: string): Promise<RefreshResult> {
  const response = await fetch(tokenEndpoint(config), {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'refresh_token',
      client_id: config.clientId,
      client_secret: config.clientSecret,
      refresh_token: refreshToken,
    }),
  });

  if (!response.ok) {
    const { error, description } = await parseTokenErrorBody(response);
    throw new CanvasOAuthError(
      `Canvas token refresh failed with status ${response.status}`,
      error,
      description
    );
  }

  const body = (await response.json()) as CanvasTokenResponseBody;
  return {
    accessToken: body.access_token,
    expiresAt: Date.now() + (body.expires_in ?? 3600) * 1000,
    refreshToken: body.refresh_token,
  };
}

/**
 * Revokes an access token, invalidating both it and its associated refresh
 * token. Use for a "disconnect Canvas" action.
 *
 * @throws {CanvasOAuthError} On a non-2xx response from Canvas.
 */
export async function revokeToken(
  config: Pick<OAuthClientConfig, 'canvasDomain'>,
  accessToken: string
): Promise<void> {
  const response = await fetch(tokenEndpoint(config), {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!response.ok) {
    const { error, description } = await parseTokenErrorBody(response);
    throw new CanvasOAuthError(
      `Canvas token revoke failed with status ${response.status}`,
      error,
      description
    );
  }
}
