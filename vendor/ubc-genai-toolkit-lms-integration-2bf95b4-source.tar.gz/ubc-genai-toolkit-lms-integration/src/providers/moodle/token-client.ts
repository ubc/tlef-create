import { createApiClient } from './api-client';

/** Response shape of Moodle's `core_webservice_get_site_info` function. */
export interface SiteInfo {
  sitename: string;
  username: string;
  /** The Moodle user id the token belongs to. */
  userid: number;
  [key: string]: unknown;
}

/**
 * Validates a pasted `wstoken` by calling Moodle's
 * `core_webservice_get_site_info` — the lightest-weight function available
 * on every Moodle install, used here purely to confirm the token works and
 * to learn which Moodle user it belongs to.
 *
 * @throws {MoodleApiError} If the token is invalid or the call is otherwise rejected.
 */
export function validateToken(moodleDomain: string, token: string): Promise<SiteInfo> {
  const client = createApiClient({ moodleDomain, token, userId: '' });
  return client.call<SiteInfo>('core_webservice_get_site_info');
}
