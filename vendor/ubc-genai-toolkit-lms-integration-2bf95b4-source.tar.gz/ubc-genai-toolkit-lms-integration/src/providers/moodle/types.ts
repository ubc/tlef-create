import type { Request } from 'express';
import type { TokenStore } from '../../core/types';

/**
 * A self-generated Moodle Web Services token. Unlike Canvas's OAuth tokens,
 * this has no expiry and no refresh token — it's valid until revoked from
 * Moodle's own "Security keys" page.
 */
export interface Tokens {
  /** The pasted `wstoken`. */
  token: string;
  /** The Moodle user id (`userid` from `core_webservice_get_site_info`) the token belongs to. */
  moodleUserId: string;
}

/**
 * Configuration shared by every entry point in this namespace.
 */
export interface Config {
  /** Moodle domain, no protocol, e.g. `'moodle.example.ubc.ca'`. */
  moodleDomain: string;
  /** Where authorized tokens are persisted. */
  tokenStore: TokenStore<Tokens>;
  /**
   * Derives the {@link TokenStore} lookup key from the request (e.g. the
   * app's own session user id). May return a `Promise<string>` for apps
   * whose identity resolution needs I/O.
   */
  getUserKey: (req: Request) => string | Promise<string>;
  /**
   * The path {@link import('./router').createAuthRouter} is mounted at, e.g. `'/moodle/auth'`.
   * Defaults to `'/moodle/auth'`.
   */
  basePath?: string;
}
