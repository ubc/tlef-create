import { createHash } from 'node:crypto';
import type { ApiClient } from '../api-client';
import type { LmsFile, LmsFileDownload, LmsFileDownloadOptions } from '../../../core/types';
import { MoodleApiError } from '../errors';

export interface CourseContentFile {
  type: string;
  filename: string;
  filepath?: string;
  filesize?: number;
  fileurl?: string;
  timecreated?: number;
  timemodified?: number;
  mimetype?: string;
  isexternalfile?: boolean;
  [key: string]: unknown;
}

export interface CourseModule {
  id: number;
  name: string;
  modname?: string;
  contents?: CourseContentFile[];
  [key: string]: unknown;
}

export interface CourseSection {
  id: number;
  name: string;
  modules?: CourseModule[];
  [key: string]: unknown;
}

export interface GetCourseFilesOptions {
  /** Native `core_course_get_contents` filters, expressed as Moodle name/value pairs. */
  filters?: Array<{ name: string; value: string | number | boolean }>;
}

function fileId(fileUrl: string): string {
  return createHash('sha256').update(fileUrl).digest('base64url');
}

function timestamp(value?: number): string | undefined {
  return typeof value === 'number' && value > 0 ? new Date(value * 1000).toISOString() : undefined;
}

/** Lists downloadable files exposed by Moodle course modules. */
export async function getCourseFiles(
  client: ApiClient,
  moodleCourseId: string | number,
  options: GetCourseFilesOptions = {}
): Promise<LmsFile[]> {
  const sections = await client.call<CourseSection[]>('core_course_get_contents', {
    courseid: moodleCourseId,
    options: options.filters,
  });
  const files: LmsFile[] = [];

  for (const section of sections) {
    for (const module of section.modules ?? []) {
      for (const content of module.contents ?? []) {
        if (content.type !== 'file' || !content.fileurl) continue;
        files.push({
          id: fileId(content.fileurl),
          courseId: String(moodleCourseId),
          name: content.filename || module.name,
          filename: content.filename || '',
          mimeType: content.mimetype,
          size: typeof content.filesize === 'number' ? content.filesize : undefined,
          createdAt: timestamp(content.timecreated),
          updatedAt: timestamp(content.timemodified),
          raw: { section, module, content },
        });
      }
    }
  }
  return files;
}

/** Resolves a course-scoped Moodle file id and downloads its bytes. */
export async function downloadFile(
  client: ApiClient,
  moodleCourseId: string | number,
  moodleFileId: string,
  options: LmsFileDownloadOptions = {}
): Promise<LmsFileDownload> {
  const files = await getCourseFiles(client, moodleCourseId);
  const file = files.find((candidate) => candidate.id === moodleFileId);
  if (!file) throw new MoodleApiError('Moodle course file was not found', 'filenotfound');

  const raw = file.raw as { content: CourseContentFile };
  const result = await client.download(raw.content.fileurl as string, options);
  if (file.size !== undefined && result.size !== file.size) {
    throw new MoodleApiError(
      `Moodle file download was incomplete (expected ${file.size} bytes, received ${result.size})`,
      'filesizemismatch'
    );
  }
  return {
    ...result,
    contentType: result.contentType || file.mimeType,
    filename: result.filename || file.filename,
  };
}
