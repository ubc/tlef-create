import type { ApiClient } from '../api-client';
import type { LmsRosterUser } from '../../../core/types';

/** A role assignment on an enrolled user, as returned within {@link EnrolledUser}. */
export interface UserRole {
  roleid?: number;
  name?: string;
  shortname?: string;
  [key: string]: unknown;
}

/**
 * A user enrolled in a Moodle course, as returned by
 * `core_enrol_get_enrolled_users`. Only the fields this package's callers rely
 * on are typed explicitly — Moodle returns many more, preserved via the index
 * signature.
 *
 * `email` and `idnumber` are populated only when the token's account holds
 * `moodle/site:viewuseridentity`, and `roles` only when it can see role
 * assignments.
 */
export interface EnrolledUser {
  id: number;
  username?: string;
  fullname?: string;
  email?: string | null;
  idnumber?: string | null;
  roles?: UserRole[];
  [key: string]: unknown;
}

export interface GetCourseUsersOptions {
  /**
   * Moodle role shortnames to keep. Defaults to `['student']`.
   *
   * Moodle has no server-side equivalent of Canvas's enrollment-type filter —
   * the web service returns everyone enrolled, so the filter is applied here.
   * Users carrying no roles at all are kept regardless, because an empty
   * `roles` array means the token could not see role assignments rather than
   * that the person holds none; dropping them would silently shrink the roster
   * on a permission problem.
   */
  roleShortnames?: string[];
}

function optionalText(value: unknown): string | undefined {
  const text = typeof value === 'string' ? value.trim() : '';
  return text || undefined;
}

/**
 * The people enrolled in a single Moodle course, normalized across providers —
 * see {@link LmsRosterUser}. The original Moodle response (typed
 * {@link EnrolledUser}) is available on each result's `.raw`.
 *
 * Moodle exposes no counterpart to Canvas's `integration_id`, so
 * {@link LmsRosterUser.integrationId} is always undefined here. Where a Canvas
 * roster at UBC can be matched on PUID, a Moodle one falls back to student
 * number, email, or username — see `rosterFieldCoverage` for which of those a
 * given token actually returned.
 *
 * @param client An authenticated {@link ApiClient} (e.g. `req.moodleApi`, attached by `requireAuth`).
 * @param moodleCourseId The Moodle course's id (from a `getCourses` result's `.id`, or the
 * raw numeric id from `.raw.id` if you have it).
 * @param options Role filter — see {@link GetCourseUsersOptions}.
 */
export async function getCourseUsers(
  client: ApiClient,
  moodleCourseId: string | number,
  options: GetCourseUsersOptions = {}
): Promise<LmsRosterUser[]> {
  const wantedRoles = new Set(options.roleShortnames ?? ['student']);
  const users = await client.call<EnrolledUser[]>('core_enrol_get_enrolled_users', {
    courseid: moodleCourseId,
  });

  return users
    .filter((user) => {
      const roles = user.roles ?? [];
      return roles.length === 0 || roles.some((role) => role.shortname && wantedRoles.has(role.shortname));
    })
    .map(
      (user): LmsRosterUser => ({
        id: String(user.id),
        name: optionalText(user.fullname) ?? `Moodle user ${user.id}`,
        email: optionalText(user.email),
        integrationId: undefined,
        sisId: optionalText(user.idnumber),
        loginId: optionalText(user.username),
        raw: user,
      })
    );
}
