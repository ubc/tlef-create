import type { ApiClient } from '../api-client';
import type { LmsCourse, LmsCourseSection } from '../../../core/types';

/**
 * A course the connected user is enrolled in, as returned by
 * `core_enrol_get_users_courses`. Only the fields this package's callers
 * rely on are typed explicitly — Moodle returns many more, preserved via
 * the index signature.
 */
export interface Course {
  id: number;
  shortname: string;
  fullname: string;
  [key: string]: unknown;
}

/**
 * A group within a single Moodle course, as returned by
 * `core_group_get_course_groups`. This is NOT the same concept as Canvas's
 * cross-listed sections — Moodle's own "sections" mean something unrelated
 * (topic/week blocks). Groups are the closest functional equivalent for
 * splitting a course's enrolled students, but membership is many-to-many
 * and a course can have zero groups (unlike Canvas's strict section
 * partition).
 */
export interface CourseGroup {
  id: number;
  name: string;
  courseid: number;
  [key: string]: unknown;
}

/**
 * The courses the connected user is enrolled in, normalized across
 * providers — see {@link LmsCourse}. The original Moodle response (typed
 * {@link Course}) is available on each result's `.raw`.
 *
 * @param client An authenticated {@link ApiClient} (e.g. `req.moodleApi`, attached by `requireAuth`).
 */
export async function getCourses(client: ApiClient): Promise<LmsCourse[]> {
  const courses = await client.call<Course[]>('core_enrol_get_users_courses', { userid: client.userId });
  return courses.map(
    (course): LmsCourse => ({
      id: String(course.id),
      name: course.fullname,
      code: course.shortname,
      raw: course,
    })
  );
}

/**
 * The sections within a single Moodle course, normalized across providers —
 * see {@link LmsCourseSection}. Internally this calls Moodle's **Groups**
 * feature (`core_group_get_course_groups`), not anything Moodle itself
 * calls "sections" — Moodle's own UI term for that is unrelated (topic/week
 * blocks on a course page). Groups are the closest functional equivalent to
 * Canvas's cross-listed sections, though it's a looser many-to-many model
 * where a course can have zero groups. The original Moodle response (typed
 * {@link CourseGroup}) is available on each result's `.raw`.
 *
 * @param client An authenticated {@link ApiClient}.
 * @param moodleCourseId The Moodle course's id (from a {@link getCourses} result's `.id`, or the
 * raw numeric id from `.raw.id` if you have it).
 */
export async function getCourseSections(
  client: ApiClient,
  moodleCourseId: string | number
): Promise<LmsCourseSection[]> {
  const groups = await client.call<CourseGroup[]>('core_group_get_course_groups', { courseid: moodleCourseId });
  return groups.map(
    (group): LmsCourseSection => ({
      id: String(group.id),
      name: group.name,
      courseId: String(group.courseid),
      raw: group,
    })
  );
}
