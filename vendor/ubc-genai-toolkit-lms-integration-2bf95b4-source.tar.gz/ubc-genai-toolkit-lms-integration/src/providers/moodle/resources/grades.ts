import type { ApiClient } from '../api-client';
import type { LmsGrade, LmsGradeItem } from '../../../core/types';

export interface GradeItem {
  id: number;
  itemname: string;
  itemtype: string;
  graderaw?: number;
  gradeformatted?: string;
  grademax?: number;
  gradedatesubmitted?: number;
  gradedategraded?: number;
  [key: string]: unknown;
}

export interface UserGrade {
  courseid: number;
  userid: number;
  gradeitems: GradeItem[];
  [key: string]: unknown;
}

export interface GradeItemsResponse {
  usergrades: UserGrade[];
  warnings?: unknown[];
}

export interface GetGradeItemsOptions {
  /** Zero means all users and requires Moodle's grade:viewall capability. */
  userId?: string | number;
  groupId?: string | number;
}

export interface GetGradesOptions {
  courseId: string | number;
  /** Omit to request all users; this requires Moodle's grade:viewall capability. */
  userIds?: Array<string | number>;
  groupId?: string | number;
}

function timestamp(value?: number): string | undefined {
  return typeof value === 'number' && value > 0 ? new Date(value * 1000).toISOString() : undefined;
}

async function requestGradeItems(
  client: ApiClient,
  courseId: string | number,
  userId: string | number,
  groupId: string | number = 0
): Promise<GradeItemsResponse> {
  return client.call<GradeItemsResponse>('gradereport_user_get_grade_items', {
    courseid: courseId,
    userid: userId,
    groupid: groupId,
  });
}

/** Lists Moodle manual/module gradebook items, deduplicated across users. */
export async function getGradeItems(
  client: ApiClient,
  moodleCourseId: string | number,
  options: GetGradeItemsOptions = {}
): Promise<LmsGradeItem[]> {
  const response = await requestGradeItems(
    client,
    moodleCourseId,
    options.userId ?? 0,
    options.groupId ?? 0
  );
  const byId = new Map<string, GradeItem>();
  for (const userGrade of response.usergrades ?? []) {
    for (const item of userGrade.gradeitems ?? []) {
      if (item.itemtype === 'course' || item.itemtype === 'category') continue;
      byId.set(String(item.id), item);
    }
  }
  return Array.from(byId.values(), (item) => ({
    id: String(item.id),
    courseId: String(moodleCourseId),
    name: item.itemname,
    maxScore: typeof item.grademax === 'number' ? item.grademax : undefined,
    raw: item,
  }));
}

/** Reads Moodle course totals and item scores. This function never writes grades. */
export async function getGrades(client: ApiClient, options: GetGradesOptions): Promise<LmsGrade[]> {
  const userIds = options.userIds?.length ? options.userIds : [0];
  const responses = await Promise.all(
    userIds.map((userId) => requestGradeItems(client, options.courseId, userId, options.groupId ?? 0))
  );
  const grades: LmsGrade[] = [];
  for (const response of responses) {
    for (const userGrade of response.usergrades ?? []) {
      for (const item of userGrade.gradeitems ?? []) {
        if (item.itemtype === 'category') continue;
        grades.push({
          courseId: String(options.courseId),
          gradeItemId: item.itemtype === 'course' ? undefined : String(item.id),
          userId: String(userGrade.userid),
          score: typeof item.graderaw === 'number' ? item.graderaw : undefined,
          grade: item.gradeformatted,
          maxScore: typeof item.grademax === 'number' ? item.grademax : undefined,
          submittedAt: timestamp(item.gradedatesubmitted),
          gradedAt: timestamp(item.gradedategraded),
          raw: item,
        });
      }
    }
  }
  return grades;
}
