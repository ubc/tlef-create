import type { Config } from './types';

const REQUIRED_ENV_VARS = ['MOODLE_DOMAIN'] as const;

/** The fields {@link loadConfigFromEnv} cannot derive from the environment. */
export type EnvOverrides = Omit<Config, 'moodleDomain'>;

/**
 * Reads `moodleDomain` from `process.env.MOODLE_DOMAIN` and merges in the
 * host-specific fields that can't come from the environment (`tokenStore`,
 * `getUserKey`, and optionally `basePath`).
 *
 * @throws {Error} If `MOODLE_DOMAIN` is unset.
 */
export function loadConfigFromEnv(overrides: EnvOverrides): Config {
  const missing = REQUIRED_ENV_VARS.filter((name) => !process.env[name]);
  if (missing.length > 0) {
    throw new Error(`Missing required Moodle environment variable(s): ${missing.join(', ')}`);
  }

  return {
    moodleDomain: process.env.MOODLE_DOMAIN as string,
    ...overrides,
  };
}
