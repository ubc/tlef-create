import { LmsError } from '../../core/errors';

/**
 * Thrown when a Moodle `webservice/rest/server.php` call fails. Moodle
 * returns HTTP 200 even on failure — the only reliable signal is the
 * response body's `exception`/`errorcode` fields, which this carries.
 */
export class MoodleApiError extends LmsError {
  constructor(message: string, public readonly errorcode?: string) {
    super(message, 'moodle');
    this.name = 'MoodleApiError';
  }
}
