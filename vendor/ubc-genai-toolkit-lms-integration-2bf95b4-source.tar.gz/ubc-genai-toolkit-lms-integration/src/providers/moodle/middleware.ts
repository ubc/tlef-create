import { Request, Response, NextFunction, RequestHandler } from 'express';
import type { Config } from './types';
import { createApiClient, ApiClient } from './api-client';

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      /** Attached by {@link requireAuth} once a stored Moodle token is available. */
      moodleApi?: ApiClient;
    }
  }
}

const DEFAULT_BASE_PATH = '/moodle/auth';

/**
 * Express middleware for JSON/API routes: guarantees `req.moodleApi` is set
 * before calling `next()`. If the current user has no stored Moodle token,
 * responds `401` with `{ success: false, connected: false, connectUrl }` —
 * `connectUrl` is the `/connect` endpoint the frontend should POST a pasted
 * token to. There is no page-redirect variant (unlike Canvas's
 * `ensureAuth`) because Moodle's connect flow has no browser-navigable URL
 * to redirect to — it's always an in-app paste-token form.
 */
export function requireAuth(config: Config): RequestHandler {
  const basePath = config.basePath ?? DEFAULT_BASE_PATH;

  return async function requireMoodleAuthMiddleware(req: Request, res: Response, next: NextFunction) {
    try {
      const userKey = await config.getUserKey(req);
      const tokens = await config.tokenStore.get(userKey);

      if (!tokens) {
        return res.status(401).json({
          success: false,
          connected: false,
          connectUrl: `${basePath}/connect`,
        });
      }

      req.moodleApi = createApiClient({
        moodleDomain: config.moodleDomain,
        token: tokens.token,
        userId: tokens.moodleUserId,
        onInvalidToken: async () => {
          await config.tokenStore.delete(userKey);
        },
      });
      next();
    } catch (err) {
      next(err);
    }
  };
}
