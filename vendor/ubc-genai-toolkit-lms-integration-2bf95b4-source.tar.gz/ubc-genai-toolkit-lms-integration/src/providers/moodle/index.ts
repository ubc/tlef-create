export { createApiClient } from './api-client';
export type { ApiClient, ApiClientOptions } from './api-client';

export { baseUrl } from './moodle-url';

export { validateToken } from './token-client';
export type { SiteInfo } from './token-client';

export { createAuthRouter } from './router';
export { requireAuth } from './middleware';

export { getCourses, getCourseSections } from './resources/courses';
export type { Course, CourseGroup } from './resources/courses';

export { getCourseUsers } from './resources/users';
export type { EnrolledUser, UserRole, GetCourseUsersOptions } from './resources/users';

export { getCourseFiles, downloadFile } from './resources/files';
export type {
  CourseContentFile,
  CourseModule,
  CourseSection,
  GetCourseFilesOptions,
} from './resources/files';

export { getGradeItems, getGrades } from './resources/grades';
export type {
  GradeItem,
  UserGrade,
  GradeItemsResponse,
  GetGradeItemsOptions,
  GetGradesOptions,
} from './resources/grades';

export { loadConfigFromEnv } from './env-config';
export type { EnvOverrides } from './env-config';

export { MoodleApiError } from './errors';

export type { Tokens, Config } from './types';
