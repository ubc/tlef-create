import { normalizeBaseUrl } from '../../core/http';

export function baseUrl(moodleDomain: string): string {
  return normalizeBaseUrl(moodleDomain);
}
