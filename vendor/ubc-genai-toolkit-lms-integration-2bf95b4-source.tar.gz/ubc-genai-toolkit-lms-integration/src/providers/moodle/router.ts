import { Router, Request, Response, NextFunction } from 'express';
import type { Config } from './types';
import { validateToken } from './token-client';
import { MoodleApiError } from './errors';

/**
 * Builds the `/connect` and `/disconnect` endpoints for Moodle's
 * paste-a-token flow. Unlike Canvas's OAuth router, there's no
 * redirect/consent screen — the user generates their own `wstoken` from
 * Moodle's own "Security keys" page and POSTs it here directly.
 */
export function createAuthRouter(config: Config): Router {
  const router = Router();

  router.post('/connect', async (req: Request, res: Response, next: NextFunction) => {
    const token = typeof req.body?.token === 'string' ? req.body.token.trim() : '';
    if (!token) {
      return res.status(400).json({ success: false, error: 'A Moodle token is required.' });
    }

    try {
      const siteInfo = await validateToken(config.moodleDomain, token);
      const userKey = await config.getUserKey(req);
      await config.tokenStore.set(userKey, { token, moodleUserId: String(siteInfo.userid) });
      res.json({ success: true, sitename: siteInfo.sitename, username: siteInfo.username });
    } catch (err) {
      if (err instanceof MoodleApiError) {
        if (err.errorcode === 'invalidtoken') {
          return res.status(400).json({
            success: false,
            error: "That token isn't valid — check you copied the whole key from Moodle's Security keys page.",
          });
        }
        return res.status(400).json({
          success: false,
          error:
            "Your Moodle site rejected this request — ask your Moodle admin to check the web service configuration (REST protocol enabled, required functions whitelisted).",
        });
      }
      next(err);
    }
  });

  router.post('/disconnect', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userKey = await config.getUserKey(req);
      await config.tokenStore.delete(userKey);
      res.status(204).end();
    } catch (err) {
      next(err);
    }
  });

  return router;
}
