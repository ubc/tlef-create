import { MoodleApiError } from './errors';
import { baseUrl } from './moodle-url';
import type { LmsFileDownload, LmsFileDownloadOptions } from '../../core/types';

export interface ApiClientOptions {
  moodleDomain: string;
  token: string;
  userId: string;
  /**
   * Called when a call comes back with `errorcode === 'invalidtoken'` (the
   * token was revoked from Moodle's own Security keys page after it was
   * stored). Should delete the stored token so the next request prompts
   * reconnect instead of failing silently forever. Omit to skip this.
   */
  onInvalidToken?: () => Promise<void>;
}

export interface ApiClient {
  /** The Moodle user id this client's token belongs to, captured at connect time. */
  readonly userId: string;
  call<T = unknown>(wsfunction: string, params?: Record<string, unknown>): Promise<T>;
  /** Downloads a URL returned by a Moodle web-service function. */
  download(fileUrl: string, options?: LmsFileDownloadOptions): Promise<LmsFileDownload>;
}

interface MoodleErrorBody {
  exception?: string;
  errorcode?: string;
  message?: string;
}

/**
 * Recursively serializes a params object into Moodle's PHP-style
 * bracket-index/bracket-key form (`value[0]=12&value[1]=34`,
 * `members[groupid]=5`), the encoding Moodle's Web Services REST protocol
 * expects for array/object-valued params.
 *
 * Supported value types: arrays, plain objects, primitives, and booleans.
 * Anything else (e.g. a `Date`, a class instance) is the caller's
 * responsibility to pre-serialize into one of the above first.
 */
function appendParam(body: URLSearchParams, key: string, value: unknown): void {
  if (value === undefined || value === null) return;
  if (typeof value === 'boolean') {
    // Moodle's PARAM_BOOL cleaning expects '1'/'0', not the string
    // "true"/"false" that the generic String(value) path below would produce.
    body.set(key, value ? '1' : '0');
  } else if (Array.isArray(value)) {
    value.forEach((item, index) => appendParam(body, `${key}[${index}]`, item));
  } else if (typeof value === 'object') {
    for (const [childKey, childValue] of Object.entries(value as Record<string, unknown>)) {
      appendParam(body, `${key}[${childKey}]`, childValue);
    }
  } else {
    body.set(key, String(value));
  }
}

/**
 * RPC-style client for Moodle's Web Services REST protocol
 * (`webservice/rest/server.php`) — every call is "invoke this named
 * function with these params," not a REST verb/path, so unlike Canvas's
 * client there's a single `call()` method rather than get/post/put/delete.
 *
 * Moodle returns HTTP 200 even on failure — the only reliable failure
 * signal is an `exception`/`errorcode` field in the JSON body, which this
 * checks on every response.
 */
export function createApiClient(options: ApiClientOptions): ApiClient {
  const configuredMoodleUrl = new URL(baseUrl(options.moodleDomain));

  async function call<T>(wsfunction: string, params: Record<string, unknown> = {}): Promise<T> {
    const body = new URLSearchParams();
    // Append the caller's params first, then set the reserved fields — this
    // way a params object that happens to contain a key literally named
    // wstoken/wsfunction/moodlewsrestformat can't silently overwrite the
    // client's own reserved fields.
    for (const [key, value] of Object.entries(params)) {
      appendParam(body, key, value);
    }
    body.set('wstoken', options.token);
    body.set('wsfunction', wsfunction);
    body.set('moodlewsrestformat', 'json');

    const response = await fetch(`${baseUrl(options.moodleDomain)}/webservice/rest/server.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
    });

    if (!response.ok) {
      throw new MoodleApiError(`Moodle request failed with HTTP ${response.status}`);
    }

    let data: MoodleErrorBody & T;
    try {
      data = (await response.json()) as MoodleErrorBody & T;
    } catch {
      throw new MoodleApiError(
        'Moodle returned a non-JSON response — check that the REST protocol is enabled and MOODLE_DOMAIN is correct'
      );
    }

    if (data && typeof data === 'object' && ('exception' in data || 'errorcode' in data)) {
      if (data.errorcode === 'invalidtoken' && options.onInvalidToken) {
        await options.onInvalidToken();
      }
      throw new MoodleApiError(data.message ?? `Moodle web service call to ${wsfunction} failed`, data.errorcode);
    }

    return data as T;
  }

  async function download(fileUrl: string, downloadOptions: LmsFileDownloadOptions = {}): Promise<LmsFileDownload> {
    let currentUrl = new URL(fileUrl, configuredMoodleUrl);
    for (let redirectCount = 0; redirectCount <= 5; redirectCount += 1) {
      if (!['http:', 'https:'].includes(currentUrl.protocol) || currentUrl.origin !== configuredMoodleUrl.origin) {
        throw new MoodleApiError('Moodle returned an unexpected file download URL', 'invalidfileurl');
      }
      if (!/\/(?:webservice\/pluginfile|tokenpluginfile)\.php(?:\/|$)/.test(currentUrl.pathname)) {
        throw new MoodleApiError('Moodle returned an unsupported file download path', 'invalidfileurl');
      }

      currentUrl.searchParams.set('token', options.token);
      const response = await fetch(currentUrl, { redirect: 'manual' });
      if ([301, 302, 303, 307, 308].includes(response.status)) {
        const location = response.headers.get('location');
        if (!location) throw new MoodleApiError('Moodle file download redirected without a destination', 'invalidfileurl');
        if (redirectCount === 5) throw new MoodleApiError('Moodle file download exceeded the redirect limit', 'invalidfileurl');
        currentUrl = new URL(location, currentUrl);
        continue;
      }
      if (!response.ok) {
        throw new MoodleApiError(`Moodle file download returned HTTP ${response.status}`, 'filedownloadfailed');
      }

      const declaredLength = Number(response.headers.get('content-length'));
      if (
        downloadOptions.maxBytes !== undefined &&
        Number.isFinite(declaredLength) &&
        declaredLength > downloadOptions.maxBytes
      ) {
        throw new MoodleApiError(
          `Moodle file exceeds the ${downloadOptions.maxBytes}-byte download limit`,
          'filetoolarge'
        );
      }
      const data = new Uint8Array(await response.arrayBuffer());
      if (downloadOptions.maxBytes !== undefined && data.byteLength > downloadOptions.maxBytes) {
        throw new MoodleApiError(
          `Moodle file exceeds the ${downloadOptions.maxBytes}-byte download limit`,
          'filetoolarge'
        );
      }

      const contentType = response.headers.get('content-type') ?? undefined;
      const startsWithHtml = /^\s*(?:<!doctype\s+html|<html\b)/i.test(
        Buffer.from(data.subarray(0, 512)).toString('utf8')
      );
      if (contentType?.toLowerCase().includes('text/html') || startsWithHtml) {
        throw new MoodleApiError('Moodle returned an HTML page instead of the requested file', 'filedownloadfailed');
      }
      return { data, contentType, size: data.byteLength };
    }

    throw new MoodleApiError('Moodle file download exceeded the redirect limit', 'invalidfileurl');
  }

  return { userId: options.userId, call, download };
}
