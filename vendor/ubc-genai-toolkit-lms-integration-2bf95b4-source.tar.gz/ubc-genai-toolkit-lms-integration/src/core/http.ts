/**
 * Resolves a bare domain to a base URL. Real hosted LMS instances are always
 * HTTPS, so a bare domain (`'ubc.instructure.com'`) defaults to `https://`.
 * A local/dev instance often runs plain HTTP on a non-standard port — pass
 * an explicit scheme (`'http://localhost:9100'`) to use that instead.
 */
export function normalizeBaseUrl(domain: string): string {
  const trimmed = domain.replace(/\/+$/, '');
  return /^https?:\/\//.test(trimmed) ? trimmed : `https://${trimmed}`;
}
