/**
 * Base class for every error this package throws. Carries the provider name so
 * a host app can catch all providers generically (`err instanceof LmsError`)
 * and still log or branch on `err.provider` — typically in one error handler
 * far from the call site, where the alternative is an `instanceof` chain that
 * must be extended for every new subclass.
 *
 * Typed `string`, not a union of today's providers: this module is the
 * abstraction the provider implementations depend on, so it doesn't enumerate
 * them.
 */
export class LmsError extends Error {
  constructor(message: string, public readonly provider: string) {
    super(message);
    this.name = 'LmsError';
  }
}
