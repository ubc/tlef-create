import type {
  LmsAmbiguousKey,
  LmsAppOnlyUser,
  LmsAppUserKey,
  LmsRosterFieldCoverage,
  LmsRosterMatch,
  LmsRosterMatchReport,
  LmsRosterOnlyUser,
  LmsRosterUser,
} from './types';

/**
 * Counts how many roster entries carried each identity field.
 *
 * A roster match that fails tells you nothing on its own about *why*: the
 * people may genuinely have no application account, or the field the match
 * relies on may never have been visible to the token that read the roster.
 * Canvas gates `integration_id`, `sis_user_id`, and `login_id` behind
 * permission to read SIS data, so an instructor token can return a complete,
 * correct roster in which every one of those fields is empty.
 *
 * The difference matters most when acting on absence. Removing the people who
 * did not match is reasonable after a roster that resolved nearly everyone; it
 * is destructive after one that resolved nobody because a permission was
 * missing. Compare the count against `total` before offering that kind of
 * action.
 *
 * @param users A roster from either provider's `getCourseUsers`.
 */
export function rosterFieldCoverage(users: LmsRosterUser[]): LmsRosterFieldCoverage {
  const coverage: LmsRosterFieldCoverage = {
    total: users.length,
    integrationId: 0,
    sisId: 0,
    email: 0,
    loginId: 0,
  };

  for (const user of users) {
    if (user.integrationId) coverage.integrationId += 1;
    if (user.sisId) coverage.sisId += 1;
    if (user.email) coverage.email += 1;
    if (user.loginId) coverage.loginId += 1;
  }

  return coverage;
}

/**
 * Compares against the roster case-insensitively. This is not a looser match —
 * it is the same field on both sides, and the two systems can disagree on
 * casing for reasons that have nothing to do with identity. Two application
 * keys that differ only by case therefore collide, which the ambiguity check
 * below catches and reports rather than resolving arbitrarily.
 */
export function foldRosterKey(value: unknown): string | undefined {
  const text = typeof value === 'string' ? value.trim().toLowerCase() : '';
  return text || undefined;
}

/**
 * Pairs an application's users against one course's roster on the institutional
 * identifier alone — Canvas `integration_id`, which at UBC holds the PUID.
 *
 * Deliberately has no fallback key. Email and student number are each a
 * plausible match rather than a certain one, and the cost of being wrong is not
 * symmetric: an unmatched student is a line in a report someone reads, while a
 * mis-matched one is a grade filed against the wrong person. Everything the
 * caller needs to handle the misses is in the returned report.
 *
 * Pure, so a host can build the report once, show it to an instructor, and act
 * on the same object it displayed. `courseId` is stamped onto the result — see
 * {@link LmsRosterMatchReport} for why that matters on export. Prefer a
 * provider's own wrapper (Canvas's `matchCourseRoster`) where one exists, since
 * it takes the id from the read rather than from a second argument that could
 * disagree with it.
 *
 * @param courseId The course the roster was read from.
 * @param roster A roster from either provider's `getCourseUsers`.
 * @param appUsers The application's own users — see {@link LmsAppUserKey}. Bare
 * strings are keys, and two identical strings are one person; pass
 * `{ appUserId, key }` records if the application can hold the same key on two
 * accounts, which is itself an ambiguity. Two keys differing only by case are
 * ambiguous either way.
 */
export function matchRosterByIntegrationId(
  courseId: string | number,
  roster: LmsRosterUser[],
  appUsers: Iterable<LmsAppUserKey>
): LmsRosterMatchReport {
  const rosterByKey = new Map<string, LmsRosterUser[]>();
  for (const user of roster) {
    const key = foldRosterKey(user.integrationId);
    // A roster entry with no integrationId cannot match anything, and falls
    // through to `rosterOnly` below alongside the ones that simply went
    // unclaimed. Whether that is a permission problem or a genuinely empty
    // field is what `coverage` on the report exists to answer.
    if (!key) continue;
    const existing = rosterByKey.get(key);
    if (existing) existing.push(user);
    else rosterByKey.set(key, [user]);
  }

  // Insertion-ordered so the report comes back in the order the caller supplied
  // its users, which keeps a rendered match table stable between runs.
  //
  // "Owners" are counted separately from spellings. Without account ids the two
  // are the same thing and an identical string repeated is one person; with
  // them, two accounts holding one key is a duplicate in the application, and
  // resolving it to either account would file a grade against a coin toss.
  const appByKey = new Map<string, { keys: Set<string>; owners: Map<string, string | undefined> }>();
  for (const appUser of appUsers) {
    const rawKey = typeof appUser === 'string' ? appUser : appUser.key;
    const appUserId = typeof appUser === 'string' ? undefined : appUser.appUserId;
    const key = foldRosterKey(rawKey);
    if (!key) continue;

    const entry = appByKey.get(key) ?? { keys: new Set<string>(), owners: new Map() };
    entry.keys.add(rawKey.trim());
    entry.owners.set(appUserId ?? rawKey.trim(), appUserId);
    appByKey.set(key, entry);
  }

  const matched: LmsRosterMatch[] = [];
  const appOnly: LmsAppOnlyUser[] = [];
  const ambiguous: LmsAmbiguousKey[] = [];

  for (const [key, entry] of appByKey) {
    const rosterUsers = rosterByKey.get(key) ?? [];
    const appKeys = [...entry.keys];
    const appUserIds = [...entry.owners.values()].filter(
      (id): id is string => id !== undefined
    );
    const identity = appUserIds.length > 0 ? { appUserId: appUserIds[0] } : {};

    if (entry.owners.size > 1 || appKeys.length > 1 || rosterUsers.length > 1) {
      ambiguous.push({
        key: appKeys[0],
        lmsUserIds: rosterUsers.map((user) => user.id),
        appKeys,
        ...(appUserIds.length > 0 ? { appUserIds } : {}),
      });
      continue;
    }

    if (rosterUsers.length === 1) {
      matched.push({
        key: appKeys[0],
        ...identity,
        lmsUserId: rosterUsers[0].id,
        name: rosterUsers[0].name,
        matchedBy: 'integrationId',
      });
    } else {
      appOnly.push({ key: appKeys[0], ...identity, reason: 'unknown' });
    }
  }

  const rosterOnly: LmsRosterOnlyUser[] = [];
  for (const user of roster) {
    const key = foldRosterKey(user.integrationId);
    if (key && appByKey.has(key)) continue;
    rosterOnly.push({ lmsUserId: user.id, name: user.name, key: user.integrationId });
  }

  return {
    courseId: String(courseId),
    matched,
    appOnly,
    rosterOnly,
    coverage: rosterFieldCoverage(roster),
    ambiguous,
  };
}
