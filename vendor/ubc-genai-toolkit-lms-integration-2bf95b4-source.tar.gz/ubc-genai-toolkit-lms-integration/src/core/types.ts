/**
 * Persists provider-specific tokens between requests, keyed by an
 * app-defined `userKey`. The package has no storage of its own — the host
 * application supplies an implementation (database, cache, etc.).
 */
export interface TokenStore<T> {
  get(userKey: string): Promise<T | null>;
  set(userKey: string, tokens: T): Promise<void>;
  delete(userKey: string): Promise<void>;
}

/**
 * A course, normalized across providers. Every provider's `getCourses`
 * maps its native course shape into this before returning — see `raw` for
 * anything provider-specific not captured in the fields below.
 *
 * `id` is only unique within its LMS. Nothing here is tagged with a provider,
 * since you reach every resource through a provider-specific namespace; a
 * caller that persists these records the provider itself.
 */
export interface LmsCourse {
  id: string;
  name: string;
  code: string;
  raw: unknown;
}

/**
 * A section (Canvas) or group (Moodle) within a single course, normalized
 * across providers. See `raw` for anything provider-specific, e.g. Canvas's
 * `sis_section_id`, which has no Moodle equivalent. `id`/`courseId` are scoped
 * to their LMS — see {@link LmsCourse}.
 */
export interface LmsCourseSection {
  id: string;
  name: string;
  courseId: string;
  raw: unknown;
}

/**
 * A person on a course roster, normalized across providers. Every provider's
 * `getCourseUsers` maps its native user shape into this before returning — see
 * `raw` for anything provider-specific not captured below.
 *
 * The identity fields are the ones worth matching on. Which are populated
 * depends on both the provider and the permissions of the token that read the
 * roster, so treat every one of them as optional and use
 * {@link LmsRosterFieldCoverage} to tell "this deployment does not expose the
 * field" apart from "this person has no value for it".
 *
 * `id` is provider-scoped — never join it against an application user id.
 */
export interface LmsRosterUser {
  id: string;
  name: string;
  email?: string;
  /**
   * Canvas `integration_id` — a second SIS identifier independent of
   * {@link LmsRosterUser.sisId}. **At UBC this holds the student's PUID**, the
   * identifier CWL authenticates against, which makes it the strongest
   * available key for matching a Canvas roster to CWL-authenticated accounts.
   * Moodle has no equivalent and always leaves this undefined.
   *
   * Canvas only serializes this (along with `sisId` and `loginId`) for callers
   * permitted to read SIS data. An instructor token may come back without it.
   */
  integrationId?: string;
  /**
   * Canvas `sis_user_id` / Moodle `idnumber` — at UBC, the student number.
   * Authoritative when present, but not every account has one, so it cannot
   * carry a roster match on its own.
   */
  sisId?: string;
  /** Canvas `login_id` / Moodle `username` — the institutional login, e.g. a CWL. */
  loginId?: string;
  raw: unknown;
}

/**
 * How many roster entries carried each identity field, from
 * `rosterFieldCoverage`. Zero coverage of a field across a non-empty roster
 * usually means the reading token lacks permission to see it rather than that
 * every person is missing a value — a distinction worth making before acting
 * on who failed to match.
 */
export interface LmsRosterFieldCoverage {
  total: number;
  integrationId: number;
  sisId: number;
  email: number;
  loginId: number;
}

/**
 * How a caller identifies one of its own users to the matcher.
 *
 * A bare string is the key alone, and two identical strings are taken to be one
 * person. Pass the record form wherever the application can have two accounts
 * holding the same key: only an account id makes "one person listed twice" and
 * "two accounts claiming the same student" distinguishable, and the second is
 * an ambiguity that must not resolve to a grade.
 */
export type LmsAppUserKey = string | { appUserId: string; key: string };

/** One application account paired with the roster entry carrying the same key. */
export interface LmsRosterMatch {
  /**
   * The application-side identifier that matched, in the application's own
   * casing. At UBC this is the student's PUID.
   */
  key: string;
  /** Present when the caller supplied account ids rather than bare keys. */
  appUserId?: string;
  /**
   * Provider-scoped LMS user id. Safe to send back to the same LMS; never
   * persist it as though it were an application user id, and never compare it
   * across providers.
   */
  lmsUserId: string;
  name: string;
  /**
   * Which rule produced the match. Only ever `integrationId` today — recorded
   * anyway so that an instructor looking at an unexpected grade can see the
   * evidence behind the link, and so adding a weaker fallback key later cannot
   * silently change what an existing match meant.
   */
  matchedBy: 'integrationId';
}

/**
 * Someone on the LMS roster with no application account. Informational: on a
 * partially adopted course this is most of the class, so it is never on its own
 * a reason to warn anyone.
 */
export interface LmsRosterOnlyUser {
  lmsUserId: string;
  name: string;
  /** The roster entry's `integrationId`, when it exposed one. */
  key?: string;
}

/**
 * An application account with no active entry on the LMS roster. On export this
 * is the list that matters — a grade with nowhere to go.
 *
 * `reason` starts as `unknown` because the active roster cannot distinguish
 * "dropped the course" from "was never in it"; a provider's `explainUnmatched`
 * resolves it against concluded enrollments.
 */
export interface LmsAppOnlyUser {
  key: string;
  /** Present when the caller supplied account ids rather than bare keys. */
  appUserId?: string;
  reason: 'unknown' | 'not-enrolled' | 'enrollment-ended';
  /** Set when `reason` is `enrollment-ended`. */
  formerEnrollment?: { lmsUserId: string; name: string; state: string };
}

/**
 * A key claimed by more than one account on one side or the other, which
 * therefore matches nothing. Both id lists are reported because they mean
 * different things: two `lmsUserIds` is a duplicate account in the LMS, two
 * `appKeys` is a duplicate in the application, and the fix differs.
 */
export interface LmsAmbiguousKey {
  key: string;
  lmsUserIds: string[];
  appKeys: string[];
  /** Present when the caller supplied account ids; two or more is a duplicate in the application. */
  appUserIds?: string[];
}

/**
 * The result of matching an application's users against one course's roster.
 *
 * `matched`, `appOnly`, and the application-side keys in `ambiguous` are
 * disjoint and together account for every distinct key supplied — an ambiguous
 * key is reported only as ambiguous, never also as unmatched, so the counts can
 * be shown to a human without double-counting anyone.
 *
 * `courseId` is what makes this safe to act on. A grade written from a report
 * carries the course whose roster produced it, so a score computed for one
 * course cannot be posted against another — the same person is the same LMS
 * user id in both, and nothing else would catch it.
 */
export interface LmsRosterMatchReport {
  /**
   * The course whose roster produced this report. Stamped from the read itself
   * rather than supplied alongside it, so it cannot disagree with the data.
   */
  courseId: string;
  matched: LmsRosterMatch[];
  appOnly: LmsAppOnlyUser[];
  rosterOnly: LmsRosterOnlyUser[];
  /**
   * Field coverage for the roster this report was built from. Check it before
   * acting on `appOnly`: zero `integrationId` coverage across a non-empty
   * roster is a missing permission, not a class that all dropped out.
   */
  coverage: LmsRosterFieldCoverage;
  ambiguous: LmsAmbiguousKey[];
}

/** Metadata for a downloadable file belonging to an LMS course. */
export interface LmsFile {
  id: string;
  courseId: string;
  name: string;
  filename: string;
  mimeType?: string;
  size?: number;
  createdAt?: string;
  updatedAt?: string;
  raw: unknown;
}

/** The bytes and response metadata returned by an LMS file download. */
export interface LmsFileDownload {
  data: Uint8Array;
  contentType?: string;
  filename?: string;
  size: number;
}

/** Optional safety controls for an LMS file download. */
export interface LmsFileDownloadOptions {
  /** Reject before or during download if the response exceeds this many bytes. */
  maxBytes?: number;
}

/** A gradable item such as a Canvas assignment or Moodle gradebook item. */
export interface LmsGradeItem {
  id: string;
  courseId: string;
  name: string;
  maxScore?: number;
  dueAt?: string;
  raw: unknown;
}

/** A user's score or grade for either a course total or one grade item. */
export interface LmsGrade {
  courseId: string;
  gradeItemId?: string;
  userId: string;
  score?: number;
  grade?: string;
  maxScore?: number;
  submittedAt?: string;
  gradedAt?: string;
  raw: unknown;
}

/**
 * A file attached to a student's submission. Listed with the submission but
 * downloaded separately — a course-wide submission read would otherwise pull
 * every attachment in the class to answer "who submitted?".
 */
export interface LmsSubmissionAttachment {
  id: string;
  filename: string;
  displayName: string;
  mimeType?: string;
  size?: number;
  /**
   * The LMS-owned URL the bytes live behind. Metadata only: do not fetch or
   * trust this value directly. The Canvas attachment downloader accepts scoped
   * course/assignment/user/attachment ids and re-resolves the URL before use.
   */
  url: string;
}

/**
 * One student's work on one grade item, normalized across providers.
 *
 * `userId` is provider-scoped, like every other id here — translate it through
 * an {@link LmsRosterMatchReport} before it touches an application record.
 */
export interface LmsSubmission {
  courseId: string;
  gradeItemId: string;
  userId: string;
  /** Which attempt this is. Absent when nothing was ever submitted. */
  attempt?: number;
  /** Provider's own state, e.g. Canvas `submitted` / `graded` / `unsubmitted`. */
  workflowState: string;
  submittedAt?: string;
  late?: boolean;
  missing?: boolean;
  /**
   * Text-entry submissions, as the raw HTML the LMS stores. Not sanitized
   * here — treat it as untrusted markup, because a student wrote it.
   */
  body?: string;
  /** URL submissions. */
  url?: string;
  attachments: LmsSubmissionAttachment[];
  score?: number;
  grade?: string;
  raw: unknown;
}
